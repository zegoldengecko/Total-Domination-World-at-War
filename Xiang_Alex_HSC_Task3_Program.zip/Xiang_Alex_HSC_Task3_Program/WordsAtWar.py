import pygame, math, random
from pygame.locals import *
pygame.init()

#defining screen dimensions
screen = pygame.display.set_mode((1540, 800))
screenwidth, screenheight = screen.get_size()

#font and background colour
TitleFont1 = pygame.font.Font('Assets\startingtext.ttf', 25)
fontUnderline = TitleFont1
fontUnderline.set_underline(True)
TitleFont = pygame.font.SysFont('Impact', 105)
atFont = pygame.font.SysFont('Impact', 35)
ButtonFont = pygame.font.SysFont('arialblack',35) 
COLOR_INACTIVE = pygame.Color('lightskyblue3')#textbox colours
COLOR_ACTIVE = pygame.Color('dodgerblue2')#textbox colours
display_surface = pygame.display.set_mode((screenwidth, screenheight))

def custom_text(value, size, R, G, B, x, y): #defining function for custom text
    customFont = pygame.font.SysFont('arialblack', size)
    Text = customFont.render(value, True, (R, G, B))
    Text_rect = Text.get_rect()
    Text_rect.center = (x, y)
    display_surface.blit(Text, Text_rect)

#other definitions, these are mainly used as flags
clock = pygame.time.Clock()
selected = False
country_selected = False
player_country = ''
menu_open = True
display_screen = 0
initialindex = 0
citylistdisplaycounter = 0
diplomacy_screen = False
BuildingUpdaterOpen = False
nomoney = False
city_screen_running = False
shortcut = False
ViewStationedArmy = False
historicalmode = True
playerwin = False
building_click_time = pygame.time.get_ticks()
completionscreen = False
TurnButtonclicktime = pygame.time.get_ticks()

#which screen is on
Menu_screen = 1

#Music
music_running = False
run_music = True
Music_list = ["Assets\TitleMusic.mp3", "Assets\Mic.mp3", "Assets\EndTurnAudio.mp3"]
Month = 1
def music(index): #defining music function for easier music/sfx playing
    pygame.mixer.music.load(Music_list[index])
    pygame.mixer.music.play()

#GeneralImages 
bg = pygame.transform.scale(pygame.image.load("GeneralImages\worldmapv2.PNG"), (screenwidth, screenheight))
EuropeMap = pygame.transform.scale(pygame.image.load("GeneralImages\EuropeMap.png"), (screenwidth, screenheight))
Options_image = pygame.transform.scale(pygame.image.load('GeneralImages\Options image.PNG'), (screenwidth-120, screenheight-60))
BritainImage = pygame.transform.scale(pygame.image.load("GeneralImages\Britain_Image.png"), (170, 170))
GermanyImage = pygame.transform.scale(pygame.image.load('GeneralImages\Germany_Image.png'), (170,170))
FranceImage = pygame.transform.scale(pygame.image.load('GeneralImages\France_image.jpg'), (170,170))
RussiaImage = pygame.transform.scale(pygame.image.load('GeneralImages\Russia_Image.png'), (170,170))

def gamesetter(): #runs to reset the textfiles at the beginning of each game
    citysavefile = (open('TextFiles\CityUnchanged.txt', 'r')).read()
    (open('TextFiles\CityNames.txt', 'w')).write(citysavefile)
    (open('TextFiles\CitySave.txt', 'w')).write(citysavefile)
    countrysavefile = (open('TextFiles\CountriesUnchanged.txt', 'r')).read()
    (open('TextFiles\Countries.txt', 'w')).write(countrysavefile)
    (open('TextFiles\Countries Save.txt', 'w')).write(countrysavefile)
    armysavefile = (open('ArmyInfo\ArmyLocationSaveFile.txt', 'r')).read()
    (open('ArmyInfo\ArmyLocation.txt', 'w')).write(armysavefile)
    countrywarsavefile = (open('TextFiles\CountryWarFileUnchanged.txt', 'r')).read()
    (open('TextFiles\CountryWarFile.txt', 'w')).write(countrywarsavefile)
    Factionssavefile = (open('TextFiles\FactionsSave.txt', 'r')).read()
    (open('TextFiles\Factions.txt', 'w')).write(Factionssavefile)
    #open('TextFiles\WorldEvents.txt', 'w')
    open('TextFiles\CasualtyFile.txt', 'w')

def gameend(wincondition): #End of game screen that shows stats and ability to restart
    global selected, country_selected, Month, Menu_screen, display_screen
    screen.blit(bg,(0,0))
    countryinfotoblit = []
    countrycounter = 0
    Casualties = 0
    Kills = 0
    UKtestcas = 0
    UKtestkil = 0
    CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
    CasualtyFile = ((open('TextFiles\CasualtyFile.txt', 'r')).read()).split("\n")
    for item in CasualtyFile: #checking casualty/kill numbers
        if item != '':
            country, Cas, Kil = item.split()
            if country == player_country:
                Casualties += int(Cas)
                Kills += int(Kil)
            if country == 'UK':
                UKtestcas += int(Cas)
                UKtestkil += int(Kil)
    
    pygame.draw.rect(screen, (255,253,208), [100, 50, 1340, 700]) #mainbox
    pygame.draw.rect(screen, (92, 64,52), [100, 50, 1340, 700], 6) #border
    pygame.draw.line(screen, (92, 64,52), [100, 110], [1437, 110], 6) #divider
    pygame.draw.line(screen, (92, 64,52), [100, 680], [1437, 680], 6) #bottom divider
    pygame.draw.line(screen, (92, 64,52), [1200, 50], [1200, 680], 6) #vertical divider

    rankscores = []
    rankassigner = {}
    for item in CountryData: #calculating rank and assigning data to each country
        country, treasury, GDP, military, manpower, population, focus = item.split()
        countryinfotoblit.append(f"{country} {treasury} {GDP} {military} {manpower} {population}")
        countrycounter += 1
        rankscore = int(GDP)*0.5 + int(military)*0.3 + int(manpower)*0.05
        rankscores.append(rankscore)
        rankassigner[country] = rankscore
    rankscores.sort(reverse = True)
    y = 85
    size = 12
    custom_text('Country', 30, 0, 0, 0, 180, y)
    custom_text('Treasury', 30, 0, 0, 0, 340, y)
    custom_text('GDP', 30, 0, 0, 0, 480, y)
    custom_text('Military', 30, 0, 0, 0, 620, y)
    custom_text('Manpower', 30, 0, 0, 0, 800, y)
    custom_text('Population', 30, 0, 0, 0, 1000, y)
    custom_text('Rank', 30, 0, 0, 0, 1150, y)
    y = 120
    for item in countryinfotoblit: #displaying information for each country
        country, treasury, GDP, military, manpower, population = item.split()
        y += 17
        for rankitem in rankscores:
            if rankassigner[country] == rankitem:
                rank = rankscores.index(rankitem) + 1
        custom_text(country, size, 0, 0, 0, 180, y)
        custom_text(CitiesListStatShortener(treasury), size, 0, 0, 0, 340, y)
        custom_text(CitiesListStatShortener(GDP), size, 0, 0, 0, 480, y)
        custom_text(CitiesListStatShortener(military), size, 0, 0, 0, 620, y)
        custom_text(CitiesListStatShortener(manpower), size, 0, 0, 0, 800, y)
        custom_text(CitiesListStatShortener(population), size, 0, 0, 0, 1000, y)
        custom_text(f"{rank}", size, 0, 0, 0, 1150, y)
    
    if wincondition: #checking if you won or lost + display for your country
        custom_text('YOU WON', 30, 15, 252, 3, 1315, 80)
    else:
        custom_text('YOU LOST', 30, 252, 69, 3, 1315, 80)
    screen.blit(pygame.transform.scale(pygame.image.load(f'FlagImages\{player_country}.PNG'), (190, 120)), (1220, 130)) #display the flag
    pygame.draw.rect(screen, (92, 64, 51), [1214, 124, 196, 126 ], 6) #border
    screen.blit(pygame.transform.scale(pygame.image.load(f"LeaderImages\{player_country}_Leader.jfif"), (190, 170)), (1220, 270)) #portrait
    pygame.draw.rect(screen, (92, 64, 51), [1214, 264, 196, 176 ], 6) #border
    custom_text(f'#{rank}', 35, 0, 0, 0, 1310, 470)
    custom_text(f'Casualties', 28, 0, 0, 0, 1313, 520)
    custom_text(f'{CitiesListStatShortener(str(Casualties))}', 17, 0, 0, 0, 1310, 550) #Casulaties

    custom_text(f'Kills', 28, 0, 0, 0, 1310, 600)
    custom_text(f'{CitiesListStatShortener(str(Kills))}', 17, 0, 0, 0, 1310, 630)#Kills

    textbutton((173, 216, 230), (30, 30, 255), 1060, 1410, 690, 730, 350, 40, 'RESTART', 0, 0, 0, 35) #restart button

    if pygame.mouse.get_pressed()[0]:
        if 1060 <= mouse[0] <= 1410 and 690 <= mouse[1] <= 730:
            music(1)
            country_selected = False
            Month = 0
            Menu_screen = 1
            selected = False
            display_screen = 0
            gamesetter()
            BuildingBonusApplier()
            open('TextFiles\CasualtyFile.txt', 'w')


class MainMenu: #main menu
    global starting_screen, Titletext, Othertext, title_inactive_colour, title_active_colour, buttons, circlebuttons,textbutton
    #colours
    title_inactive_colour = (30, 30, 255)
    title_active_colour = (173, 216, 230)

    def Titletext(value, x, y, z, a, b): #The title text
        Text = TitleFont.render(value, True, (x, y, z))
        Text_rect = Text.get_rect()
        Text_rect.center = (a, b)
        display_surface.blit(Text, Text_rect)

    def Othertext(value, R, G, B, x, y): #other text on the main menu
        Text = ButtonFont.render(value, True, (R,G, B))
        Text_rect = Text.get_rect()
        Text_rect.center = (x, y)
        display_surface.blit(Text, Text_rect)
    
    def buttons(colour1, colour2, xpos1, xpos2, ypos1, ypos2, width, height): #button template
        if xpos1 <= mouse[0] <= xpos2 and ypos1 <= mouse[1] <= ypos2:
            button = pygame.draw.rect(screen,colour1,[xpos1, ypos1, width, height])
        else:
            button = pygame.draw.rect(screen,colour2,[xpos1, ypos1, width, height])
    
    def textbutton(colour1, colour2, xpos1, xpos2, ypos1, ypos2, width, height, value, R, G, B, size): #buttons with text template
        click = pygame.mouse.get_pressed()
        if xpos1 <= mouse[0] <= xpos2 and ypos1 <= mouse[1] <= ypos2:
            if click[0] ==1:
                pass
            button = pygame.draw.rect(screen,colour1,[xpos1, ypos1, width, height])
        else:
            button = pygame.draw.rect(screen,colour2,[xpos1, ypos1, width, height])
        customFont = pygame.font.SysFont('arialblack', size)
        Text = customFont.render(value, True, (R,G, B))
        Text_rect = Text.get_rect()
        Text_rect.center = (xpos1 + 0.5*(width), ypos1 + 0.5*(height))
        display_surface.blit(Text, Text_rect)

    
    def circlebuttons(bordercolour, colour1, colour2, xpos1, xpos2, ypos1, ypos2, radius, x, y): #circle button template
        Border = pygame.draw.circle(screen, bordercolour, [x, y], radius+4)
        if xpos1 <= mouse[0] <= xpos2 and ypos1 <= mouse[1] <= ypos2:
            button = pygame.draw.circle(screen,colour1,[x, y], radius)
        else:
            button = pygame.draw.circle(screen,colour2,[x, y], radius)
        

    def starting_screen(): #main menu screen
        global music_running
        if Menu_screen == 1 or Menu_screen == 2: #Music_Runner
            if run_music == True:
                if music_running == False:
                    pygame.mixer.music.set_volume(1)
                    music(0)
                    music_running = True
    
    
        if Menu_screen == 1: #TItle screen design
            screen.blit(bg,(0,0))
            pygame.draw.rect(screen,(0, 0, 0),[270,0, 400, screenheight])
            textbutton(title_active_colour, title_inactive_colour, 295, 645, 400, 440, 350, 40, 'PLAY', 0, 0, 0, 35) #play button     
            textbutton(title_active_colour, title_inactive_colour, 295, 645, 460, 500, 350, 40, 'OPTIONS', 0,0,0 , 35) #options button
            textbutton(title_active_colour, title_inactive_colour, 295, 645, 520, 560, 350, 40, 'TUTORIAL', 0, 0, 0, 35)  #tutorial button
            textbutton(title_active_colour, title_inactive_colour, 295, 645, 580, 620, 350, 40, 'QUIT', 0, 0, 0, 35)  #quit button
            
            #definingthetext
            OtherTitleText = fontUnderline.render('TOTAL DOMINATION', True, (235, 30, 30))
            OtherTitleText_rect = OtherTitleText.get_rect()
            OtherTitleText_rect.center = (475, 105)
            
            atTitleText = atFont.render('AT', True, (90, 90, 90))
            atTitleText_rect = atTitleText.get_rect()
            atTitleText_rect.center = (365, 255)
            
            #blitting it
            display_surface.blit(OtherTitleText, OtherTitleText_rect)
            Titletext('WORLDS', 90, 90, 90, 475, 170) #Title
            display_surface.blit(atTitleText, atTitleText_rect)
            Titletext('WAR', 90, 90, 90, 500, 260)

def Options(): #Options screen
    global historicalmode
    if Menu_screen == 2:
        screen.fill((0, 0, 0))
        screen.blit(bg,(0,0))
        screen.blit(Options_image, (60, 30))
        buttons(title_active_colour, title_inactive_colour, 63, 173, 667, 767, 110, 100) #back button
        Titletext('←', 0,0,0,115,705) #back arrow
        Titletext('Options', 90, 90, 90, 770, 100)
        Othertext('Music:', 0, 0, 0, 700, 300)
        buttons(title_active_colour, title_inactive_colour, 850, 900, 275, 325, 50, 50) #options button
        if music_running == True: #music on/off button
            Othertext('X', 0, 0, 0, 875, 300) #checkmark
        else:
            buttons(title_active_colour, title_inactive_colour, 850, 900, 275, 325, 50, 50)

        Othertext('Historical Mode:', 0, 0, 0, 610, 400) #checks if you want to play with historical events or not
        buttons(title_active_colour, title_inactive_colour, 850, 900, 375, 425, 50, 50) #Historical Mode Button
        if historicalmode == True: #music on/off button
            Othertext('X', 0, 0, 0, 875, 400) #checkmark
        else:
            buttons(title_active_colour, title_inactive_colour, 850, 900, 375, 425, 50, 50)
        buttons(title_active_colour, title_inactive_colour, 675, 875, 500, 560, 200, 60) #restart button, allows you to bick a different nation
        Othertext('RESTART', 0, 0, 0, 775, 527) #restartbutton text

def Tutorial(): #Tutorial screen, basic information about the game
    global Menu_screen, Tutorialdisplayscreen
    if Menu_screen == 3:
        screen.fill((0, 0, 0))
        screen.blit(bg,(0,0))
        screen.blit(Options_image, (60, 30))
        buttons(title_active_colour, title_inactive_colour, 63, 173, 667, 767, 110, 100) #back button
        Titletext('←', 0,0,0,115,705) #back arrow
        buttons(title_active_colour, title_inactive_colour, 1367, 1477, 667, 767, 110, 100) #Next Page button
        Titletext('→', 0,0,0,1423,705) #Next arrow
        Titletext('Tutorial', 90, 90, 90, 770, 100)
        if pygame.mouse.get_pressed()[0] and 63 <= mouse[0] <= 173 and 667 <= mouse[1] <= 767: #back arrow
            pygame.time.wait(200)
            if Tutorialdisplayscreen != 1:
                Tutorialdisplayscreen -= 1
                
            else:
                Menu_screen = 1
        if pygame.mouse.get_pressed()[0] and 1367 <= mouse[0] <= 1477 and 667 <= mouse[1] <= 767: #forward arrow
            pygame.time.wait(200)
            if Tutorialdisplayscreen <= 19:
                Tutorialdisplayscreen += 1
            if Tutorialdisplayscreen == 20:
                Menu_screen = 1
        
        if pygame.key.get_pressed()[pygame.K_ESCAPE]:
            Tutorialdisplayscreen = 1
            Menu_screen = 1
            
        if Tutorialdisplayscreen == 1: #brief icon tutorial
            colours = [(128, 128, 128),(255, 0, 0),(212, 255, 166),(124,252,0)]
            xvalue = 250 
            index = 0
            custom_text('These are the symbols for the capital cities. In order from left to right they represent:', 18, 0, 0, 0, 1000, 200)
            custom_text('Neutral Capitals, Enemy Capitals, Allied Capitals, Capitals You Control', 18, 0, 0, 0, 1000, 225)
            custom_text('Click on these to reveal information about the capital.', 18, 0, 0, 0, 1000, 250)
            for i in range(0,4): #Capitals
                colour = colours[index]
                pygame.draw.rect(screen, colour, [xvalue, 200, 50, 50]) 
                pygame.draw.rect(screen, (0,0,0), [xvalue, 200, 50, 50], 4)
                xvalue += 60
                index += 1
            
            custom_text('These are the symbols for the regular cities. In order from left to right they represent:', 18, 0, 0, 0, 1000, 400)
            custom_text('Neutral Cities, Enemy Cities, Allied Cities, Cities You Control', 18, 0, 0, 0, 1000, 425)
            custom_text('Click on these to reveal information about the city.', 18, 0, 0, 0, 1000, 450)
            xvalue = 275
            index = 0
            for i in range(0, 4): #Regular Cities
                colour = colours[index]
                pygame.draw.circle(screen, (0,0,0), [xvalue, 400], 25) 
                pygame.draw.circle(screen, colour, [xvalue, 400], 21)
                xvalue += 60
                index += 1

            custom_text('These are the symbols for the armies. In order from left to right they represent:', 18, 0, 0, 0, 1000, 550)
            custom_text('Neutral Armies, Enemy Armies, Allied Armies, Armies You Control', 18, 0, 0, 0, 1000, 575)
            custom_text('Click on these to reveal information about the army.', 18, 0, 0, 0, 1000, 600)
            xvalue = 275
            index = 0
            for i in range(0, 4): #Armies
                colour = colours[index]
                pygame.draw.polygon(screen, colour, ((xvalue,600), (xvalue-25,550), (xvalue+25, 550))) #Army
                pygame.draw.polygon(screen, (0,0,0), ((xvalue,600), (xvalue-25,550), (xvalue+25, 550)), 3)
                xvalue += 60
                index += 1
        if Tutorialdisplayscreen == 2: #country selection
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\CountrySelectionImage.PNG"), (900, 400)), (300, 170))
            custom_text('This is the country selection screen. It gives you a brief overview of each country and', 18, 0, 0, 0, 750, 600)
            custom_text('allows you to select which one you want to play as.', 18, 0, 0, 0, 750, 630)
        if Tutorialdisplayscreen == 3: #action menu
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\ActionMenuImage.PNG"), (900, 400)), (300, 170))
            custom_text('This is the action menu. It allows you to have quick access to four main functions in the game.', 18, 0, 0, 0, 750, 600)
            custom_text('From left to right: Your nation home screen, a list of all your currently controlled cities,', 18, 0, 0, 0, 750, 630)
            custom_text('a screen that shows you your current divisions, and a world events screen.', 18, 0, 0, 0, 750, 660)
            custom_text('To hide and show the menu click the arrow.', 18, 0, 0, 0, 750, 690)
        if Tutorialdisplayscreen == 4: #country info screen
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\CountryHomeScreen.PNG"), (450, 500)), (250, 170))
            custom_text('This is the country info screen.', 16, 0, 0, 0, 1100, 200)
            custom_text('It shows you information on the country you have selected.', 16, 0, 0, 0, 1100, 230)
            custom_text('You can navigate to your own country info screen by clicking the action button: ', 16, 0, 0, 0,  1060, 260)
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\CountryActionButton.PNG"), (30, 30)), (1420, 245))
            custom_text('On your own country info screen you will find a national focus button.', 16, 0, 0, 0,  1100, 320)
            custom_text('This takes you to the national focus screen.', 16, 0, 0, 0,  1100, 350)
            custom_text('On the country info screen of another country you will find a', 16, 0, 0, 0,  1100, 410)
            custom_text('declare war button and a button to take you to the diplomacy screen.', 16, 0, 0, 0,  1100, 440)
            custom_text('By clicking on the leader portrait you can open up the list ', 16, 0, 0, 0,  1100, 500)
            custom_text('of countries that are at war with the nation you have selected.', 16, 0, 0, 0,  1100, 530)
        if Tutorialdisplayscreen == 5: #national focus screen
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\CountryFocusScreen.PNG"), (900, 400)), (300, 170))
            custom_text('This is the national focus screen for the UK. It will differ slightly between nations.', 18, 0, 0, 0, 750, 600)
            custom_text('Here you can select an option to give minor buffs to your nation. From left to right, top to bottom:', 18, 0, 0, 0, 750, 630)
            custom_text("10% income bonus, 10% defence bonus, 10% manpower increase,", 18, 0, 0, 0, 750, 660)
            custom_text("10% attack bonus, 20% training time decrease, 25% max army travel distance.", 18, 0, 0, 0, 750, 690)
        if Tutorialdisplayscreen == 6: #diplomacy screen
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\DiplomacyScreen.PNG"), (900, 400)), (300, 170))
            custom_text('This is the diplomacy screen.', 18, 0, 0, 0, 750, 600)
            custom_text('Here you can choose to engage in trade deals with other nations, join wars, or create factions', 18, 0, 0, 0, 750, 630)
            custom_text("Once you have selected options a value will be displayed. If the value is positive (or 0) they will accept", 18, 0, 0, 0, 750, 660)
            custom_text("If the value is negative they will reject that offer.", 18, 0, 0, 0, 750, 690)
        if Tutorialdisplayscreen == 7: #diplomacy screen 2.0
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\DiplomacyScreen.PNG"), (900, 400)), (300, 170))
            custom_text('You will not be able to invite someone in another faction to your faction.', 18, 0, 0, 0, 750, 600)
            custom_text('You are able to offer and demand all cities except capital cities.', 18, 0, 0, 0, 750, 630)
            custom_text("Creating a puppet forces a nation into your faction and gives you 20% of their income and manpower.", 18, 0, 0, 0, 750, 660)
            custom_text("You can also request war support or peace through this screen.", 18, 0, 0, 0, 750, 690)
        if Tutorialdisplayscreen == 8: #army divsion screen/training screen
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\Armylistscreen.PNG"), (900, 400)), (300, 170))
            custom_text('This is the army list screen. It can be accessed by clicking this button on the action menu:', 18, 0, 0, 0, 750, 600)
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\ArmyListIcon.PNG"), (30, 30)), (1205, 585))
            custom_text("On this screen you can view your army names, training status, division makeup and where they're stationed", 18, 0, 0, 0, 750, 630)
            custom_text("If armies are in training this icon will appear next to them: ", 18, 0, 0, 0, 750, 660)
            screen.blit(pygame.transform.scale(pygame.image.load("Assets\TimerIcon.PNG"), (30, 30)), (1045, 645))
            custom_text("To train armies click the train army button.", 18, 0, 0, 0, 750, 690)
        if Tutorialdisplayscreen == 9: #army training screen
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\ArmyTrainScreen.PNG"), (900, 400)), (300, 170))
            custom_text('This is the army training screen. Here you can train armies and decide their makeup.', 18, 0, 0, 0, 750, 600)
            custom_text('Each army can have 14 divisions maximum and each division has a manpower, time and dollar cost.', 18, 0, 0, 0, 750, 630)
            custom_text("tanks are the most expensive but use the least manpower, mechanised are a middle ground, and", 18, 0, 0, 0, 750, 660)
            custom_text("infantry are the cheapest but use the most manpower. After the training time they will appear in your capital.", 18, 0, 0, 0, 750, 690)
        if Tutorialdisplayscreen == 10:#world news screen
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\WorldNewsScreen.PNG"), (900, 400)), (300, 170))
            custom_text('This is the world news screen. Here you can view all events that have taken place on the current turn.', 18, 0, 0, 0, 750, 600)
            custom_text('These events will disappear after each turn.', 18, 0, 0, 0, 750, 630)
            custom_text("This screen can be accessed by clicking this icon in the action menu: ", 18, 0, 0, 0, 750, 660)
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\WorldNewsIcon.PNG"), (30, 30)), (1095, 645))
        if Tutorialdisplayscreen == 11:#cities screen w/ building + view sieges/stationed 
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\CityInfoScreen.PNG"), (450, 500)), (250, 170))
            custom_text('This is the city screen.', 16, 0, 0, 0, 1100, 250)
            custom_text('Here you can see information about the city.', 16, 0, 0, 0, 1100, 280)
            custom_text('You can upgrade buildings by clicking on their icons and selecting upgrade.', 16, 0, 0, 0,  1060, 340)
            custom_text('Level 1 -> 2 100k, level 2 -> 3 250k', 16, 0, 0, 0,  1100, 370)
            custom_text('Bonuses from buildings are shown when you click on them.', 16, 0, 0, 0,  1100, 400)
            custom_text('Clicking on the flag will open up the country screen.', 16, 0, 0, 0,  1100, 460)
        if Tutorialdisplayscreen == 12: #stationed armies and sieges
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\StationedArmyScreen.PNG"), (450, 500)), (250, 170))
            custom_text('By clicking on the stationed armies button you can open up this screen.', 16, 0, 0, 0, 1100, 250)
            custom_text('Here you can see what armies are currently stationed at this city.', 16, 0, 0, 0, 1100, 280)
            custom_text('If you have armies stationed in your own cities ', 16, 0, 0, 0,  1060, 340)
            custom_text('or allied cities you can click on their names to move them.', 16, 0, 0, 0,  1100, 370)
            custom_text('If you or an ally have armies in an enemy city, you can click "start siege"', 16, 0, 0, 0,  1100, 430)
            custom_text('to start a battle.', 16, 0, 0, 0,  1100, 460)
            custom_text('Only 5 armies can be seen in your own cities and 4 in a sieged city', 16, 0, 0, 0,  1100, 520)
            custom_text('More can be stationed and they will be counted in battles but', 16, 0, 0, 0,  1100, 550)
            custom_text('will not appear until another army moves off', 16, 0, 0, 0,  1100, 580)
        if Tutorialdisplayscreen == 13:#moving armies/stationing armies/starting seiges #battles 
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\ArmyInfoScreen.PNG"), (160, 250)), (250, 170)) #division makeup screen
            custom_text('Clicking on one of your armies will open up this screen.', 16, 0, 0, 0, 800, 250)
            custom_text('This shows the current strength (manpower) of your division and its makeup.', 16, 0, 0, 0, 800, 280)
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\ArmyMoveScreen.PNG"), (80, 100)), (1000, 500)) #movement circle
            custom_text('This circle will also appear when an army has been selected.', 16, 0, 0, 0,  600, 480)
            custom_text('Right click anywhere in the circle to move.', 16, 0, 0, 0, 600, 510)
            custom_text('You can only move once per turn.', 16, 0, 0, 0, 600, 540)
            custom_text('If you move your army near a city you will station your army at that city.', 16, 0, 0, 0, 600, 600)
            custom_text('If you mvoe your army near a non-allied army you will initiate a battle. ', 16, 0, 0, 0, 600, 630)
        if Tutorialdisplayscreen == 14:#battles
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\BattleScreen1.PNG"), (700, 500)), (200, 170))
            custom_text('After moving near a non-allied army you ', 18, 0, 0, 0, 1200, 350)
            custom_text('will be prompted if you want to battle them.', 18, 0, 0, 0, 1200, 380) 
            custom_text('If you select yes a battle will be initiated.', 18, 0, 0, 0, 1200, 410)
            custom_text('and war will be declared', 18, 0, 0, 0, 1200, 440)
            custom_text("If you select no you will not move.", 18, 0, 0, 0, 1200, 470)
            custom_text("The same will occur if you move to a non-allied city.", 18, 0, 0, 0, 1200, 500)
        if Tutorialdisplayscreen == 15: #battles 2
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\BattleScreen1.PNG"), (700, 500)), (200, 170))
            custom_text('Tanks are given an attacking buff', 18, 0, 0, 0, 1200, 220)
            custom_text('and infantry are given a defensive buff.', 18, 0, 0, 0, 1200, 250)
            custom_text('Forts, the size of an army,', 18, 0, 0, 0, 1200, 280)
            custom_text('the focus of the nation and the makeup ', 18, 0, 0, 0, 1200, 340)
            custom_text('of the army is taken into account.', 18, 0, 0, 0, 1200, 370)
            custom_text("Using these values an attacker score", 18, 0, 0, 0, 1200, 430)
            custom_text("and a defender score is calculated.", 18, 0, 0, 0, 1200, 460)
            custom_text("Casualties are also calculated for both sides,", 18, 0, 0, 0, 1200, 520)
            custom_text("if your army runs out of manpower it will disappear", 18, 0, 0, 0, 1200, 550)
        if Tutorialdisplayscreen == 16: #Post battle, fix image display
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\BattleScreen2.PNG"), (700, 500)), (200, 170))
            custom_text('After a battle or siege this screen will be displayed.', 18, 0, 0, 0, 1200, 220)
            custom_text('It shows the battle stats', 18, 0, 0, 0, 1200, 250)
            custom_text('If the player score is higher than the enemy', 18, 0, 0, 0, 1200, 310)
            custom_text('score the battle will be won.', 18, 0, 0, 0, 1200, 340)
            custom_text('Winning a battle will force your enemy back.', 18, 0, 0, 0, 1200, 400)
            custom_text("If you lose you will be unable to move.", 18, 0, 0, 0, 1200, 430)
            custom_text("Winning a siege battle will take a city.", 18, 0, 0, 0, 1200, 490)
            custom_text("Losing a siege battle will continue the siege of the city.", 18, 0, 0, 0, 1200, 520)
        if Tutorialdisplayscreen == 17: #winning wars
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\BattleScreen2.PNG"), (700, 500)), (200, 170))
            custom_text('There are multiple options to win a war.', 18, 0, 0, 0, 1200, 220)
            custom_text('Option 1 is to do enough damage to the enemy', 18, 0, 0, 0, 1200, 280)
            custom_text('and force a peace deal.', 18, 0, 0, 0, 1200, 310)
            custom_text('Option 2 is to control all the cities of the enemy,', 18, 0, 0, 0, 1200, 370)
            custom_text('in which case their armies will be transfered to you', 18, 0, 0, 0, 1200, 400)
        if Tutorialdisplayscreen == 18: #ending turn
            screen.blit(pygame.transform.scale(pygame.image.load("TutorialImages\EndTurnButton.PNG"), (900, 400)), (300, 170))
            custom_text('Clicking the end turn button will end the turn and play a noise.', 18, 0, 0, 0, 750, 600)
            custom_text('After ending the turn you gain population, manpower, and your income amount.', 18, 0, 0, 0, 750, 630)
            custom_text("Computer controlled nations will also take their turns and will select focuses, ", 18, 0, 0, 0, 750, 690)
            custom_text("engage in diplomacy and move their armies.", 18, 0, 0, 0, 750, 660)
        if Tutorialdisplayscreen == 19: #Final screen
            custom_text('Enjoy Playing!', 30, 0, 0, 0, 750, 300)
            custom_text('Press the next arrow to return to the menu.', 18, 0, 0, 0, 750, 330)
class MainGame():
    global GameRunner, CountrySelection, TurnButton, ActionMenu,  CountryStatRounder, BuildingIconShortCode, BuildingUpdateOption, BuildingUpdater, CountryStatUpdater,  BuildingBonusApplier, CitiesListStatShortener, CitiesListScreen, ArmyBuildingBonusCalculator, DiplomacyEffect, WarDeclaration, SiegeCalculations, DiplomacyValueCalculator, HistoricalAlliances, HistoryWarDeclare
    def GameRunner():
        global selected, selectedcity, Menu_screen, mouse, country_selected, player_country, allocatedcities, selectedcountry, display_screen, diplomacy_screen, BuildingUpdaterOpen, building_type, city_income, city_manpower, population, nomoney, Cities, shortcut, ViewDivisionMakeup, screenshiftright, siegedisplay, click_time, playerwin
        if Menu_screen == 0: #if play button has been selected
            
            screen.fill((0,0,0))
            screen.blit(EuropeMap,(0,0))
            if country_selected == True: #if you have chosen a country
                if selected == False: #if you have not clicked or a city
                    #reads the information for all capitals and cities 
                    Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
                    countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
                    FactionInfo = ((open('TextFiles\Factions.txt', 'r')).read()).split("\n")
                    blank_colour = (128, 128, 128)#colour for neutral nation cities
                    Enemy_colour = (255, 0, 0) #colour for enemy nation cities
                    Ally_colour = (229, 237, 69)
                    Selected_colour = (0,191,255) #colour for the city you are hovering over
                    Home_colour = (124,252,0) #colour for cities owned by you
                    customise = 1
                    playercitycounter = 0
                    othercitycounter = 0
                    mouse = pygame.mouse.get_pos()
                    atwarlist = []
                    for waritem in countrywarfile:
                        basecountry, atwar = waritem.split()
                        if basecountry == player_country:
                            atwarlist = atwar.split('|')
                    for allianceitem in FactionInfo:
                        alliancename, allies = allianceitem.split()
                        allieslist = allies.split('|')
                        if player_country in allieslist:
                            listofallies = allieslist
                    for item in Cities : #for item in the list of Capitals and Cities
                        city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split() #assigning variable names to all data
                        x = int(x)
                        y = int(y)
                        othercitycounter += 1
                        if country == player_country:
                            playercitycounter += 1
                            customise = 0
                            othercitycounter -= 1
                        for atwarlistitem in atwarlist:
                            if country == atwarlistitem:
                                customise = 3
                        for ally in listofallies:
                            if ally == country and country != player_country:
                                customise = 2
                        if citytype == 't':
                            #drawing the capital boxes depending on the nation you have selected
                            pygame.draw.rect(screen, (0,0,0), [x-8, y, 10, 10], 2) #Border
                            if customise == 0:
                                pygame.draw.rect(screen, Home_colour, [x-6, y+2, 6, 6 ]) #colour of your own city
                            elif customise == 1:
                                pygame.draw.rect(screen, blank_colour, [x-6, y+2, 6, 6 ]) #standard colour
                            elif customise == 2:
                                pygame.draw.rect(screen, Ally_colour, [x-6, y+2, 6, 6 ]) #standard colour
                            else:
                                    pygame.draw.rect(screen, Enemy_colour, [x-6, y+2, 6, 6 ]) #colour of enemy city (at war)
                        elif citytype == 'f':
                            pygame.draw.circle(screen, (0,0,0), [x-4, y], 5)
                            if customise == 0:
                                pygame.draw.circle(screen, Home_colour, [x-4, y], 3)
                            elif customise == 1:
                                pygame.draw.circle(screen, blank_colour, [x-4, y], 3)
                            elif customise == 2:
                                pygame.draw.circle(screen, Ally_colour, [x-4, y], 3) #standard colour
                            else:
                                pygame.draw.circle(screen, Enemy_colour, [x-4, y], 3)
                        #checking if you're hovering over a city
                        if x-8 <= mouse[0] <= x+3 and y-2 <= mouse[1] <= y+8:
                            if citytype == 't':
                                pygame.draw.rect(screen, Selected_colour, [x-10, y, 11, 10 ]) #change colour and size if hovered over
                                pygame.draw.rect(screen, (0,0,0), [x-10, y-2, 14, 14], 3) #border
                            else:
                                pygame.draw.circle(screen, (0,0,0), [x-4, y], 7)
                                cityMain = pygame.draw.circle(screen, Selected_colour, [x-4, y], 4)
                            #checking for events
                            time_limit = 500
                            if pygame.mouse.get_pressed()[0] and pygame.time.get_ticks() - click_time >= time_limit and completionscreen != True: #if you click city button      
                                
                                mousex, mousey = pygame.mouse.get_pos()
                                if mousex <= 770: #checks what side of the screen you clicked on
                                    screenshiftright = True
                                else:
                                    screenshiftright = False
                                pygame.mixer.music.set_volume(0.01) #plays selection sound
                                music(1)
                                selectedcity = city
                                selectedcountry = country
                                selected = True
                                siegedisplay = False
                                ViewDivisionMakeup = False
                        customise = 1
                    CountryReadFile = open('TextFiles\Countries save.txt', 'r')
                    if playercitycounter <= 0: #checks if you have lost the game
                        selected = True
                        display_screen = 7
                        playerwin = False
                    if othercitycounter <= 0: #checks if you have won the game
                        selected = True
                        display_screen = 7
                        playerwin = True
                    for item in CountryReadFile: #updates stats for each country
                        selected_country, a, b,d,e, f, focus = item.split()
                        CountryStatUpdater(selected_country)
                    CountryReadFile.close
                    TroopLocationAssigner()
                    off_colour = (255,253,208)
                    on_colour = (255, 232, 205)
                    pygame.draw.rect(screen, (43, 43, 43), [1295, 0, 130, 50]) #Border
                    pygame.draw.rect(screen, (128, 128, 128), [1300, 5, 120, 40]) #main Background
                    textbutton(off_colour, on_colour, 1300, 1420, 5, 45, 120, 40, "End Turn",0, 0, 0, 20)
                    ActionMenu()
                        
                elif selected and display_screen == 0:# if a city has been selected
                    global upgrade, ViewStationedArmy, SelectedArmyName, SelectedInfantrySize, SelectedArmorSize, SelectedMechSize, SelectedArmyX, SelectedArmyY, checkformovement, displaywarinfo, SelectedArmySize, SelectedMaxArmySize, conflict_display_screen, playerscore, enemyscore, playercasualties, enemycasualties
                    #screen design
                    screenxmodifier = 0
                    result = 'none'
                    armyposchanger = 0
                    if screenshiftright == True:
                        screenxmodifier = 940
                        armyposchanger = 100
                    ArmiesStationed = []
                    armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
                    countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
                    Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
                    stationedcounter = 0
                    Hiddenitems = True
                    maximum = 5
                    for item in countrywarfile: #checks which counties its at war with
                        basecountry, atwar = item.split()
                        if basecountry == player_country:
                            atwarlist = atwar.split('|')
                            if selectedcountry in atwar: #checks if you're at war with the country
                                siegedisplay = True
                                maximum = 4
                    for item in armyinfo: #just going through Armyinfo file to check if any have been stationed in the selected city
                        country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = item.split()
                        if selectedcity == stationed:
                            if stationedcounter <= maximum:
                                ArmiesStationed.append(f'{Name} {stationed}')
                                stationedcounter += 1
                    
                            
                    if ViewStationedArmy: #if you have clicked on the stationed armies button
                        citybattleupdater = []
                        armybattleupdater = []
                        atwarlistupdater = []
                        pygame.draw.rect(screen, (255,253,208), [armyposchanger + 597, 308, 250, 300]) #mainbox
                        pygame.draw.rect(screen, (92, 64,52), [armyposchanger + 597, 308, 250, 300], 6) #border
                        pygame.draw.line(screen, (92, 64,52), [armyposchanger + 597, 350], [armyposchanger + 847, 350], 5) #divider
                        if siegedisplay == True: #Checks if you want to start a siege battle
                            textbutton([173, 216, 230], [30, 30, 255], armyposchanger +620 ,armyposchanger + 820, 565, 595, 200, 30, "Start Battle", 0, 0, 0, 20)
                            if pygame.mouse.get_pressed()[0] and armyposchanger+ 620 <= mouse[0] <= armyposchanger + 820 and 565 <= mouse[1] <= 595 and len(ArmiesStationed) != 0 and result == 'none': #If you click the start siege button
                                pygame.mixer.music.set_volume(0.01)
                                music(1)
                                result, playerscore, enemyscore, playercasualties, enemycasualties = SiegeCalculations(selectedcountry, player_country, selectedcity, 'none', 'none', 'none')
                                if result == player_country: #if you win
                                    conflict_display_screen = 'VICTORY'
                                    citycounter = 0
                                    for item in Cities:
                                        city, x, y, country, city_income, city_manpower, city_population, barracks, factory, market, fort, citytype = item.split()
                                        if country == selectedcountry:
                                            citycounter += 1
                                        if city == selectedcity:
                                            country = player_country
                                        citybattleupdater.append(f"{city} {x} {y} {country} {city_income} {city_manpower} {city_population} {barracks} {factory} {market} {fort} {citytype}")
                                    if citycounter == 1: #transferring the armies if they ran out of cities
                                        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
                                        for item in armyinfo:
                                            items = item.split()
                                            if items[0] == selectedcountry:
                                                items[0] = player_country
                                            armybattleupdater.append(' '.join(items))
                                        countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
                                        for item in countrywarfile:
                                            basecountry, atwar = item.split()
                                            atwarlister = atwar.split('|')
                                            if selectedcountry in atwarlister:
                                                if len(atwarlister) >1:
                                                    atwarlister.remove(selectedcountry)
                                                else:
                                                    atwarlister.remove(selectedcountry)
                                                    atwarlister.append('none')
                                            atwarlistupdater.append(f"{basecountry} {'|'.join(atwarlister)}")
                                        with open('TextFiles\CountryWarFile.txt', 'w') as file:
                                            file.write('\n'.join(atwarlistupdater))
                                        with open('ArmyInfo\ArmyLocation.txt', 'w') as file:
                                            file.write('\n'.join(armybattleupdater))
                                    with open('TextFiles\CityNames.txt', 'w') as file:
                                        file.write('\n'.join(citybattleupdater)) 
                                    selected = False
                                    pygame.time.wait(100)
                                else: #if you lose
                                    conflict_display_screen = 'DEFEAT'
                        
                        
                        custom_text('Stationed Armies', 20, 0, 0, 0, armyposchanger + 723, 330)
                        ArmyYpos = 370
                        for Armyitem in ArmiesStationed:
                            ArmyName, ArmyStationed = Armyitem.split()
                            custom_text(ArmyName, 20, 0, 0, 0, armyposchanger + 723, ArmyYpos)
                            pygame.draw.line(screen, (92, 64,52), [armyposchanger + 597, ArmyYpos + 20], [armyposchanger + 847, ArmyYpos + 20], 5) #divider
                            if pygame.mouse.get_pressed()[0] and armyposchanger + 597 <= mouse[0] <= armyposchanger + 847 and ArmyYpos -20 <= mouse[1] <+ArmyYpos + 20: #If you clicked on a stationed army
                                click_time = pygame.time.get_ticks()
                                pygame.mixer.music.set_volume(0.01)
                                music(1)
                                for item in armyinfo:
                                    country, oldx, oldy, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, Stationed, siegestatus, armysize, maxsize, traintime = item.split()
                                    if Name == ArmyName and country == player_country:
                                        
                                        if CanMove == 't': #assigns variables, if it can move it opens up the division makeup screen and allows you to move the army
                                            ViewDivisionMakeup = True
                                            checkformovement = True
                                            SelectedArmyName = Name
                                            SelectedInfantrySize = int(InfantryDivNo)
                                            SelectedArmorSize = int(ArmoredDivNo)
                                            SelectedMechSize = int(MechanizedDivNo)
                                            SelectedArmySize = armysize
                                            SelectedMaxArmySize = maxsize
                                            selected = False
                                            for item in Cities:
                                                city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split() 
                                                if city == ArmyStationed:
                                                    SelectedArmyX, SelectedArmyY = int(x), int(y)
                            ArmyYpos += 40
                            
                    pygame.draw.rect(screen,(255,253,208),[screenxmodifier,0, 600, screenheight]) #Screen
                    screen.blit(pygame.transform.scale(pygame.image.load(f'FlagImages\{selectedcountry}.PNG'), (295, 200)), (screenxmodifier + 5,110)) #display the flag
                    pygame.draw.rect(screen, (92, 64, 51), [screenxmodifier, 0,600, screenheight], 6) #border
                    pygame.draw.rect(screen, (92, 64, 51), [screenxmodifier, 0, 600, 110], 6) #divider
                    pygame.draw.line(screen, (92, 64,52), [screenxmodifier + 300, 110], [screenxmodifier + 300, 310], 5) #divider
                    pygame.draw.line(screen, (92, 64,52), [screenxmodifier + 0, 310], [screenxmodifier + 302, 310], 5) #divider
                    Titletext(selectedcity, 0, 0, 0, screenxmodifier + 300, 50)
                    pygame.draw.line(screen, (92, 64,52), [screenxmodifier + 0, 310], [screenxmodifier + 600, 310], 5) #divider
                    pygame.draw.line(screen, (92, 64,52), [screenxmodifier + 0, 500], [screenxmodifier + 600, 500], 5) #divider
                    textbutton([173, 216, 230], [30, 30, 255], screenxmodifier + 200, screenxmodifier + 400, 735, 775, 200, 40, 'Stationed Armies', 0, 0, 0, 20) #stationed Armies
                    pygame.draw.rect(screen, (0,0,0), [screenxmodifier + 200, 735, 200, 40],3)
                    if pygame.mouse.get_pressed()[0] and screenxmodifier + 200 <= mouse[0] <= screenxmodifier + 400 and 735 <= mouse[1] <= 775: #check if Stationed Army button pressed
                        pygame.mixer.music.set_volume(0.01)
                        music(1)
                        ViewStationedArmy = True
                    
                    for item in Cities: #assigning proper values to the barracks, market and factory, as well as using the information for the city screen
                        city, x, y, country, city_income, city_manpower, city_population, barracks, factory, market, fort, citytype = item.split()
                        if city == selectedcity:
                            custom_text('Occupied By:',38, 0, 0, 0, screenxmodifier + 450, 175)
                            custom_text(selectedcountry,32, 0, 0, 0, screenxmodifier + 450, 225)
                            custom_text('City Information', 45, 0, 0, 0, screenxmodifier + 300, 525)
                            CountryStatRounder('Income', 35, city_income, screenxmodifier + 300, 600)
                            CountryStatRounder('Manpower', 35, city_manpower, screenxmodifier + 300, 650)
                            CountryStatRounder('Population', 35, city_population, screenxmodifier + 300, 700)
                            selected_barracks = barracks
                            selected_market = market
                            selected_factory = factory
                            selected_fort = fort
                                
                    #buildingselection icons
                    BuildingIconShortCode(screenxmodifier + 80, 'Barracks', selected_barracks)
                    BuildingIconShortCode(screenxmodifier + 220, 'Factory', selected_factory)
                    BuildingIconShortCode(screenxmodifier + 360, 'Market', selected_market)
                    BuildingIconShortCode(screenxmodifier + 500, 'Fort', selected_fort)
                    if BuildingUpdaterOpen == True: #if you have clicked on a building button
                        BuildingUpdateOption(building_type, selected_barracks, selected_factory, selected_market, selected_fort, screenxmodifier)
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            if screenxmodifier == 0: #if it opens on the left side of the screen
                                if mouse[0] > 600: #check if you have clicked off the city screen --> exits the city screen
                                    if BuildingUpdaterOpen == False and ViewStationedArmy == False:
                                        click_time = pygame.time.get_ticks()
                                        selected = False
                                    else: #if the selection screen is open more checks have to be done to make sure you're not just clicking the new pop up
                                        if mouse[0] > 847:
                                            click_time = pygame.time.get_ticks()
                                            selected = False
                                            BuildingUpdaterOpen = False
                                            nomoney = False
                                            ViewStationedArmy = False
                                        elif BuildingUpdaterOpen == True and mouse[0] > 600 and mouse[1] > 700 or mouse[1] <308:
                                            click_time = pygame.time.get_ticks()
                                            selected = False
                                            BuildingUpdaterOpen = False
                                            nomoney = False
                                        elif ViewStationedArmy == True and mouse[0] > 600 and mouse[1] > 700 or mouse[1] <308:
                                            click_time = pygame.time.get_ticks()
                                            selected = False
                                            nomoney = False
                                            ViewStationedArmy = False
                                if mouse[0] <600:
                                    BuildingUpdaterOpen = False
                                    nomoney = False
                                    ViewStationedArmy = False
                            if screenxmodifier > 0: #if it opens on the right side of the screen
                                if mouse[0] < screenxmodifier: #check if you have clicked off the city screen --> exits the city screen
                                    if BuildingUpdaterOpen == False and ViewStationedArmy == False:
                                        click_time = pygame.time.get_ticks()
                                        selected = False
                                        screenshiftright = False

                                    else: #if the selection screen is open more checks have to be done to make sure you're not just clicking the new pop up
                                        if mouse[0] <  screenxmodifier - 247:
                                            click_time = pygame.time.get_ticks()
                                            selected = False
                                            BuildingUpdaterOpen = False
                                            nomoney = False
                                            screenshiftright = False
                                            ViewStationedArmy = False
                                        elif BuildingUpdaterOpen == True and mouse[0] <  screenxmodifier and mouse[1] > 700 or mouse[1] <308:
                                            click_time = pygame.time.get_ticks()
                                            selected = False
                                            BuildingUpdaterOpen = False
                                            nomoney = False
                                            screenshiftright = False
                                        elif ViewStationedArmy == True and mouse[0] <  screenxmodifier and mouse[1] > 700  or mouse[1] <308:
                                            click_time = pygame.time.get_ticks()
                                            selected = False
                                            nomoney = False
                                            ViewStationedArmy = False
                                if mouse[0] > screenxmodifier:
                                    BuildingUpdaterOpen = False
                                    nomoney = False
                                    ViewStationedArmy = False


                            if screenxmodifier + 0 <= mouse[0] <= screenxmodifier + 302 and 110 <= mouse[1] <= 310: #if the flag is clicked takes you to the country screen
                                pygame.mixer.music.set_volume(0.01)
                                music(1)
                                display_screen = 1
                                displaywarinfo = False

                            if selectedcountry == player_country: #checking which building was clicked
                                if screenxmodifier + 20 <= mouse[0] <= screenxmodifier + 140 and 320 <= mouse[1] <= 440:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    BuildingUpdaterOpen = True
                                    building_type = "Barracks"
                                elif screenxmodifier + 160 <= mouse[0] <= screenxmodifier + 280 and 320 <= mouse[1] <= 440:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    BuildingUpdaterOpen = True
                                    building_type = "Factory"
                                elif screenxmodifier + 300 <= mouse[0] <= screenxmodifier + 420 and 320 <= mouse[1] <= 440:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    BuildingUpdaterOpen = True
                                    building_type = "Market"
                                elif screenxmodifier + 440 <= mouse[0] <= screenxmodifier + 560 and 320 <= mouse[1] <= 440:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    BuildingUpdaterOpen = True
                                    building_type = "Fort"
                        elif event.type == pygame.KEYDOWN: #leaving the city info screen
                            if event.key == pygame.K_ESCAPE:
                                selected = False
                                BuildingUpdaterOpen = False
                                upgrade = False
                                screenshiftright = False
                                ViewStationedArmy = False

                elif selected and display_screen == 1 and diplomacy_screen == False:  #country screen
                    global offers, demands, Offer_Text_To_Blit, Demand_Text_To_Blit, costvalue, checkamount, paymentcost, manpowercost, paymentdemand, manpowerdemand, demand, display_error_message, checkcity, onscreencounter, cityofferdisplayfolder, citydemanddisplayfolder, TooManyDemands, diplomacyvalue, focus_click_time, currentFocus
                    countryscreenxmodifier = 0
                    countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
                    if screenshiftright == True:
                        countryscreenxmodifier = 940
                    #country screen design 
                    if shortcut == True: #if you clicked the icon in the action menu
                        screenshiftright = False
                        selectedcountry = player_country
                    pygame.draw.rect(screen,(255,253,208),[countryscreenxmodifier + 0,0, 600, screenheight]) #screen
                    pygame.draw.rect(screen, (92, 64, 51), [countryscreenxmodifier + 0, 0, 600, screenheight], 6) #Border
                    pygame.draw.rect(screen, (92, 64, 51), [countryscreenxmodifier +0, 0, 600, 110], 6) #divider
                    pygame.draw.line(screen, (92, 64,52), [countryscreenxmodifier +0, 450], [countryscreenxmodifier +600, 450], 5) #stat divider
                    pygame.draw.line(screen, (92, 64,52), [countryscreenxmodifier +300, 110], [countryscreenxmodifier +300, 450], 5) #vertical divider
                    pygame.draw.rect(screen, (92, 64,52), [countryscreenxmodifier +20, 120, 266, 320]) #portrait Border
                    screen.blit(pygame.transform.scale(pygame.image.load(f"LeaderImages\{selectedcountry}_Leader.jfif"), (256, 310)), (countryscreenxmodifier +25,125)) #portrait
                    if displaywarinfo == True: #if you clicked the leader image
                        xshifter = 0
                        if screenshiftright == True:
                            xshifter = -791
                        pygame.draw.rect(screen,(255,253,208),[countryscreenxmodifier + 597 + xshifter,0, 200, 270]) #screen
                        pygame.draw.rect(screen, (92, 64, 51), [countryscreenxmodifier + 597+ xshifter,0, 200, 270], 6) #Border
                        textbutton([173, 216, 230], [30, 30, 255], countryscreenxmodifier + 610+ xshifter, countryscreenxmodifier + 690+ xshifter, 230, 260, 80, 30, "", 0, 0, 0, 25)
                        custom_text("^",25, 0, 0, 0, countryscreenxmodifier + 650+ xshifter, 248)
                        pygame.draw.rect(screen,(92, 64, 51),[countryscreenxmodifier + 610+ xshifter,230, 80, 30],4)
                        textbutton([173, 216, 230], [30, 30, 255], countryscreenxmodifier + 700+ xshifter, countryscreenxmodifier + 780+ xshifter, 230, 260, 80, 30, "", 0, 0, 0, 25)
                        custom_text("v",20, 0, 0, 0, countryscreenxmodifier + 740+ xshifter, 242)
                        pygame.draw.rect(screen,(92, 64, 51),[countryscreenxmodifier + 700+ xshifter,230, 80, 30],4)
                        custom_text("War List",25, 0, 0, 0, countryscreenxmodifier + 695+ xshifter, 25)
                        pygame.draw.line(screen, (92, 64,52), [countryscreenxmodifier + 597+ xshifter, 40], [countryscreenxmodifier +795+ xshifter, 40], 5)
                        displayatwarlist = []
                        for item in countrywarfile: #checks which counties its at war with
                            basecountry, atwar = item.split()
                            if basecountry == selectedcountry:
                                atwarlist = atwar.split('|')
                                y = 60
                                for i in range(0,5):
                                    if onscreencounter < len(atwarlist):
                                        displayatwarlist.append(atwarlist[onscreencounter])
                                    onscreencounter += 1
                                for item in displayatwarlist:
                                    if item != 'none':
                                        custom_text(item,25, 0, 0, 0, countryscreenxmodifier + 700+ xshifter, y)
                                        y += 33
                                onscreencounter -= 5
                                if pygame.mouse.get_pressed()[0] and countryscreenxmodifier + 610+ xshifter <= mouse[0] <= countryscreenxmodifier + 690+ xshifter and 230 <= mouse[1] <= 260: #Up arrow
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    if onscreencounter != 0:
                                        onscreencounter -=1
                                    pygame.time.wait(100)
                                if pygame.mouse.get_pressed()[0] and countryscreenxmodifier + 700+ xshifter <= mouse[0] <= countryscreenxmodifier + 780+ xshifter and 230 <= mouse[1] <= 260: #down arrow
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    if len(atwarlist) > 5 and onscreencounter != len(atwarlist)-5:
                                        onscreencounter +=1
                                    pygame.time.wait(100)
                                    
                    Titletext(selectedcountry, 0, 0, 0, countryscreenxmodifier +300, 50)
                    CountryStatUpdater(selectedcountry)
                    if selectedcountry == player_country: #checking if it's your own country or not, this changes what is displayed
                        buttons([99, 93, 93], [64, 61, 61], countryscreenxmodifier + 320, countryscreenxmodifier + 576, 210, 350, 250, 140) 
                        custom_text('National Focus',29, 0, 0, 0, countryscreenxmodifier + 447, 275)
                    else:
                        buttons([255, 115, 84], [255, 59, 15], countryscreenxmodifier + 320, countryscreenxmodifier + 576, 130, 270, 256, 140) #war
                        buttons([99, 93, 93], [64, 61, 61], countryscreenxmodifier + 320, countryscreenxmodifier + 576, 290, 430, 256, 140) #diplomacy
                        custom_text('DECLARE',40, 0, 0, 0, countryscreenxmodifier + 448, 170)
                        custom_text('WAR',40, 0, 0, 0, countryscreenxmodifier + 448, 220)
                        custom_text('Diplomacy',40, 0, 0, 0, countryscreenxmodifier + 448, 350)
                    FactionInfo = ((open('TextFiles\Factions.txt', 'r')).read()).split("\n")
                    selectedfaction = 'None' #checking what faction it's in
                    for item in FactionInfo:
                        factionname, factionmembers = item.split()
                        factionmemberslist = factionmembers.split('|')
                        for member in factionmemberslist:
                            if member == selectedcountry:
                                selectedfaction = factionname
                    CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
                    for item in CountryData: #checking for the country's information 
                        country, treasury, GDP, military, manpower, population, focus = item.split()
                        if country == selectedcountry:
                            CountryStatRounder('Treasury', 32, treasury, countryscreenxmodifier + 300,480)
                            CountryStatRounder('Income',32, GDP, countryscreenxmodifier + 300,535)
                            CountryStatRounder('Military',32, military,countryscreenxmodifier + 300,590)
                            CountryStatRounder('Manpower',32, manpower, countryscreenxmodifier + 300, 645)
                            CountryStatRounder('Population',32, population, countryscreenxmodifier + 300, 700)
                            custom_text('Faction:',32, 0, 0, 0, countryscreenxmodifier + 120, 755)
                            custom_text(selectedfaction,32, 0, 0, 0, countryscreenxmodifier + 500, 755)
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            if countryscreenxmodifier + 20 <= mouse[0] <= countryscreenxmodifier + 286 and 120 <= mouse[1] <= 320: #clicked on national focus
                                displaywarinfo = True
                                music(1)
                                onscreencounter = 0
                            if countryscreenxmodifier == 0:
                                if 320 <= mouse[0] <= 576 and 210 <= mouse[1] <= 350 and selectedcountry == player_country:
                                    selected = True
                                    display_screen = 6
                                    currentFocus = 'None'
                                    music(1)
                                    focus_click_time = pygame.time.get_ticks()
                                if displaywarinfo == False:
                                    if mouse[0] > 600:
                                        music(1)
                                        click_time = pygame.time.get_ticks()
                                        selected = False
                                        shortcut = False
                                        display_screen = 0
                                else:
                                    if mouse[0] >797 or 600 <= mouse[0] <= 797 and mouse[1] >270:
                                        click_time = pygame.time.get_ticks()
                                        music(1)
                                        selected = False
                                        shortcut = False
                                        display_screen = 0
                            if countryscreenxmodifier != 0:
                                if countryscreenxmodifier + 320 <= mouse[0] <= countryscreenxmodifier + 576 and 210 <= mouse[1] <= 350 and selectedcountry == player_country: #clicked on national focus
                                    selected = True
                                    music(1)
                                    display_screen = 6
                                    currentFocus = 'None'
                                    focus_click_time = pygame.time.get_ticks()
                                if displaywarinfo == False:
                                    if mouse[0] < countryscreenxmodifier:
                                        click_time = pygame.time.get_ticks()
                                        selected = False
                                        shortcut = False
                                        display_screen = 0
                                else:
                                    if mouse[0] < 747 or 747 <= mouse[0] <= countryscreenxmodifier and mouse[1] >270:
                                        click_time = pygame.time.get_ticks()
                                        selected = False
                                        shortcut = False
                                        display_screen = 0
                            if selectedcountry != player_country:
                                if countryscreenxmodifier +320 <= mouse[0] <= countryscreenxmodifier + 576 and 130 <= mouse[1] <= 270: #checks if you clicked the declare war button
                                    music(1)
                                    warinfo = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
                                    for item in warinfo:
                                        basecountry, warlist = item.split()
                                        if basecountry == player_country:
                                            if selectedcountry not in warlist:
                                                if WarDeclaration(player_country, selectedcountry) == True:
                                                    click_time = pygame.time.get_ticks()
                                                    selected = False
                                                    display_screen = 0


                                elif countryscreenxmodifier + 320 <= mouse[0] <= countryscreenxmodifier + 576 and 290 <= mouse[1] <= 430: #checks if you have clicked the diplomacy button
                                    music(1)
                                    diplomacy_screen = True
                                    offers = 0
                                    demands = 0
                                    costvalue = 0
                                    paymentcost = 0
                                    manpowercost = 0
                                    paymentdemand = 0
                                    manpowerdemand = 0
                                    diplomacyvalue = 0
                                    checkcity = False
                                    display_error_message = False
                                    Offer_Text_To_Blit = ['']
                                    Demand_Text_To_Blit = ['']
                                    cityofferdisplayfolder = []
                                    citydemanddisplayfolder = []
                                    checkamount = False
                                    demand = False
                                    TooManyDemands = False
                        elif event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                screenshiftright = False
                                selected = False
                                shortcut = False
                                display_screen = 0
                elif selected and display_screen == 1 and diplomacy_screen == True: #diplomacy screen
                    global manpowermultiplier, error_message, citydisplaycounter, errortext, display_time
                    #design
                    pygame.draw.rect(screen, (92, 64, 51), [95, 45, screenwidth-190, screenheight -90]) #border
                    pygame.draw.rect(screen, (255, 253, 208), [100, 50, screenwidth-200, screenheight -100]) #mainscreen
                    pygame.draw.line(screen, (92, 64,52), [450, 45], [450, 750], 5) #vertical divider 1
                    pygame.draw.line(screen, (92, 64,52), [1090, 45], [1090, 750], 5) #vertical divider 2
                    pygame.draw.line(screen, (92, 64,52), [770, 240], [770, 750], 5) #middle vertical divider
                    pygame.draw.line(screen, (92, 64,52), [95, 240], [1443, 240], 5) #horizontal Divider
                    pygame.draw.line(screen, (92, 64,52), [450, 310], [1090, 310], 5) #horizontal offer/demand divider
                    Titletext('Diplomacy', 0, 0, 0, 770, 140)
                    pygame.draw.rect(screen, (92, 64, 51), [110, 60, 325, 170]) #playerflagbox
                    pygame.draw.rect(screen, (92, 64, 51), [1104, 60, 325, 170]) #otherflagbox
                    screen.blit(pygame.transform.scale(pygame.image.load(f"FlagImages\{player_country}.PNG"), (317, 162)), (114,64)) #playerflag
                    screen.blit(pygame.transform.scale(pygame.image.load(f"FlagImages\{selectedcountry}.PNG"), (317, 162)), (1108,64)) #otherflag
                    custom_text('Offers', 30, 0, 0, 0, 260, 270)
                    custom_text('Demands', 30, 0, 0, 0, 1260, 270)
                    custom_text('You Offer', 30, 0, 0, 0, 610, 270)
                    custom_text('You Demand', 30, 0, 0, 0, 930, 270)

                    #offer buttons
                    inactive_colour = (173, 216, 230)
                    active_colour = (78, 236, 245)
                    textbutton(inactive_colour, active_colour, 110, 435, 310, 345, 325, 35, "Invite To Faction", 0, 0, 0, 20)
                    textbutton(inactive_colour, active_colour, 110, 435, 350, 385, 325, 35, "Kick From Faction", 0, 0, 0, 20)
                    textbutton(inactive_colour, active_colour, 110, 435, 390, 425, 325, 35, "Offer Payment", 0, 0, 0, 20)
                    textbutton(inactive_colour, active_colour, 110, 435, 430, 465, 325, 35, "Offer Manpower", 0, 0, 0, 20)
                    textbutton(inactive_colour, active_colour, 110, 435, 470, 505, 325, 35, "Offer City", 0, 0, 0, 20)
                    textbutton(inactive_colour, active_colour, 110, 435, 510, 545, 325, 35, "Create Puppet", 0, 0, 0, 20) 

                    #Demand Buttons, peace
                    textbutton(inactive_colour, active_colour, 1100, 1425, 310, 345, 325, 35, "Request to Join Faction", 0, 0, 0, 20)
                    textbutton(inactive_colour, active_colour, 1100, 1425, 350, 385, 325, 35, "Request Payment", 0, 0, 0, 20)
                    textbutton(inactive_colour, active_colour, 1100, 1425, 390, 425, 325, 35, "Request City", 0, 0, 0, 20)
                    textbutton(inactive_colour, active_colour, 1100, 1425, 430, 465, 325, 35, "Request Manpower", 0, 0, 0, 20) 
                    textbutton(inactive_colour, active_colour, 1100, 1425, 470, 505, 325, 35, "Request War Support", 0, 0, 0, 20)
                    textbutton(inactive_colour, active_colour, 1100, 1425, 510, 545, 325, 35, "Request Peace", 0, 0, 0, 20)

                    #Send button
                    textbutton(inactive_colour, active_colour, 1100, 1425, 700, 735, 325, 35, "Send Offers\Demands", 0, 0, 0, 20)
                    if display_error_message == True:
                        custom_text(error_message, 25, 255, 15, 15, 1263, 680)
                        if pygame.mouse.get_pressed():
                            if (1100 > mouse[0] or mouse[0] > 1425) and (mouse[1] > 735 or mouse[1] <700):
                                display_error_message = False
                    #Checking how much to offer/demand
                    CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
                    for item in CountryData:
                        country, treasury, GDP, military, manpower, population, focus = item.split()
                        if country == player_country:
                            playerbalance = treasury
                            playermanpower = manpower
                    
                    if checkamount == True: #checks how much manpower/money you want to send/request
                        pygame.draw.rect(screen, (92, 64, 51), [110, 550, 325 ,190 ], 4)
                        custom_text(str(costvalue), 25, 0, 0, 0, 268, 641)
                        pygame.draw.rect(screen, (92, 64, 51), [328, 623, 84, 34])
                        textbutton((27, 133, 20), (56, 240, 43), 330, 410, 625, 655, 80, 30, "OK", 0, 0, 0, 15) #ok
                        pygame.draw.rect(screen, (92, 64, 51), [128, 623, 84, 34])
                        textbutton((223, 42, 53), (255,23, 24), 130, 210, 625, 655, 80, 30, "Cancel", 0, 0, 0, 15) #cancel
                        display_text = 1000
                        displayxvalue = 130
                        for i in range(0,3):
                            pygame.draw.rect(screen, (92, 64, 51), [displayxvalue-2, 568, 84, 44])
                            textbutton(inactive_colour, active_colour, displayxvalue, displayxvalue+80, 570, 610, 80, 40, f"+{CitiesListStatShortener(str(display_text))}", 0, 0, 0, 15)
                            pygame.draw.rect(screen, (92, 64, 51), [displayxvalue-2, 668, 84, 44])
                            textbutton(inactive_colour, active_colour, displayxvalue, displayxvalue+80, 670, 710, 80, 40, f"-{CitiesListStatShortener(str(display_text))}", 0, 0, 0, 15)
                            displayxvalue += 100
                            display_text *= 10
                    if checkcity == True: #checks which cities you want to trade
                        pygame.draw.rect(screen, (92, 64, 51), [110, 550, 325 ,190 ], 4)
                        pygame.draw.rect(screen, (92, 64, 51), [336, 698, 84, 34])
                        textbutton((27, 133, 20), (56, 240, 43), 338, 418, 700, 730, 80, 30, "OK", 0, 0, 0, 15) #ok
                        pygame.draw.rect(screen, (92, 64, 51), [128, 698, 84, 34])
                        textbutton((223, 42, 53), (255,23, 24), 130, 210, 700, 730, 80, 30, "Cancel", 0, 0, 0, 15) #cancel
                        textbutton([173, 216, 230], [30, 30, 255], 340, 420, 569, 629, 80, 60, "", 0, 0, 0, 25)
                        custom_text("^",43, 0, 0, 0, 380, 602)
                        pygame.draw.rect(screen,(92, 64, 51),[340,569, 80, 60],4)
                        textbutton([173, 216, 230], [30, 30, 255], 340, 420, 634, 694, 80, 60, "", 0, 0, 0, 25)
                        custom_text("v",35, 0, 0, 0, 380, 662)
                        pygame.draw.rect(screen,(92, 64, 51),[340,634, 80, 60],4)
                        Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
                        cities_to_blit =[]
                        citiestodisplay = []
                        for item in Cities:
                            city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
                            if citytype == 'f':
                                if demand == True:
                                    if country == selectedcountry:
                                        cities_to_blit.append(city)
                                else:
                                    if country == player_country:
                                        cities_to_blit.append(city)
                        for i in range(0,5):
                            if citydisplaycounter < len(cities_to_blit):
                                citiestodisplay.append(cities_to_blit[citydisplaycounter])
                            citydisplaycounter +=1
                        displayyvalue = 570  
                        for item in citiestodisplay: #creates a scrollable list
                            pygame.draw.rect(screen, (92, 64, 51), [128, displayyvalue-2, 204, 24])
                            textbutton(inactive_colour, active_colour, 130, 330, displayyvalue, displayyvalue + 20, 200, 20, item, 0, 0, 0, 11)
                            
                            if pygame.mouse.get_pressed()[0] and 130 <= mouse[0] <= 330 and displayyvalue <= mouse[1] <= displayyvalue + 20:
                                pygame.mixer.music.set_volume(0.01)
                                music(1)
                                if demand == False:
                                    if item not in cityofferdisplayfolder:
                                        cityofferdisplayfolder.append(item)
                                        pygame.time.wait(100)
                                    else:
                                        cityofferdisplayfolder.remove(item)
                                        pygame.time.wait(100)
                                else:
                                    if item not in citydemanddisplayfolder:
                                        citydemanddisplayfolder.append(item)
                                        pygame.time.wait(100)
                                    else:
                                        citydemanddisplayfolder.remove(item)
                                        pygame.time.wait(100)
                            displayyvalue += 25
                        citydisplaycounter -= 5
                        if pygame.mouse.get_pressed()[0]: #scrolling up/down list + other options
                            pygame.mixer.music.set_volume(0.01)
                            music(1)
                            if 340 <= mouse[0] <= 420 and 569 <= mouse[1] <= 629:
                                if citydisplaycounter != 0:
                                    citydisplaycounter -=1
                                pygame.time.wait(100)
                            if 340 <= mouse[0] <= 420 and 634 <= mouse[1] <= 694:
                                if len(cities_to_blit) > 5 and citydisplaycounter != len(cities_to_blit)-5:
                                    citydisplaycounter +=1
                                pygame.time.wait(100)
                            if 338 <= mouse[0] <= 418 and 700 <= mouse[1] <= 730:
                                checkcity = False
                            if 130 <= mouse[0] <= 210 and 700 <= mouse[1] <= 730:
                                checkcity = False
                                if demand == False:
                                    Offer_Text_To_Blit.remove("Offer City")
                                    cityofferdisplayfolder.clear()
                                else:
                                    Demand_Text_To_Blit.remove("Request City")
                                    citydemanddisplayfolder.clear()
                    #Displaying values
                    if Offer_Text_To_Blit != '':
                        textyblit = 330
                        for item in Offer_Text_To_Blit:
                            if item != '':
                                if textyblit < 730:
                                    
                                    custom_text(item, 20, 0, 0, 0, 610, textyblit)
                                    textyblit += 50
                                    if item == "Offer Payment":
                                        if paymentcost != 0:
                                            custom_text(f"${CitiesListStatShortener(str(paymentcost))}", 20, 0, 0, 0, 610, textyblit-27)
                                            textyblit += 10
                                    if item == "Offer Manpower":
                                        if manpowercost != 0:
                                            custom_text(f"{CitiesListStatShortener(str(manpowercost))}", 20, 0, 0, 0, 610, textyblit-27)
                                            textyblit += 10
                                    if item == 'Offer City':
                                        for item in cityofferdisplayfolder:
                                            if textyblit <= 770:
                                                custom_text(item,15, 0, 0, 0, 610, textyblit-27)
                                                textyblit += 20
                                            else:
                                                cityofferdisplayfolder.remove(item)
                                                display_time = pygame.time.get_ticks()
                                                TooManyDemands = True
                                                errortext = "offers"
                                else:
                                    Offer_Text_To_Blit.remove(item)
                                    display_time = pygame.time.get_ticks()
                                    TooManyDemands = True
                                    errortext = "offers"
                    if Demand_Text_To_Blit != '':
                        textyblit = 330
                        for item in Demand_Text_To_Blit:
                            if item != '':
                                if textyblit < 730:
                                    custom_text(item, 20, 0, 0, 0, 930, textyblit)
                                    textyblit += 50
                                    if item == "Request Payment":
                                        if paymentdemand != 0:
                                            custom_text(f"${CitiesListStatShortener(str(paymentdemand))}", 20, 0, 0, 0, 930, textyblit-27)
                                            textyblit += 10
                                    if item == "Request Manpower":
                                        if manpowerdemand != 0:
                                            custom_text(f"{CitiesListStatShortener(str(manpowerdemand))}", 20, 0, 0, 0, 930, textyblit-27)
                                            textyblit += 10
                                    if item == 'Request City':
                                        for item in citydemanddisplayfolder:
                                            if textyblit <= 770:
                                                custom_text(item,15, 0, 0, 0, 930, textyblit-27)
                                                textyblit += 20
                                            else:
                                                citydemanddisplayfolder.remove(item)
                                                display_time = pygame.time.get_ticks()
                                                TooManyDemands = True
                                                errortext = "demands"
                                else:
                                    Demand_Text_To_Blit.remove(item)
                                    display_time = pygame.time.get_ticks()
                                    TooManyDemands = True
                                    errortext = "demands"
                    if TooManyDemands == True: #in the event that the demands go off the screen
                        custom_text(f"Too many {errortext}", 20, 255, 15, 15, 1263, 680)
                        if pygame.mouse.get_pressed()[0] and pygame.time.get_ticks() - display_time >= 1500:
                            TooManyDemands = False
                    diplomacyvalue = DiplomacyValueCalculator(Offer_Text_To_Blit, Demand_Text_To_Blit, player_country, selectedcountry, paymentcost, manpowercost, paymentdemand, manpowerdemand, citydemanddisplayfolder, cityofferdisplayfolder)
                    pygame.draw.rect(screen, (129, 138, 132), [723, 190, 100, 40]) #valuebox
                    pygame.draw.rect(screen, (36, 38, 37), [723, 190, 100, 40], 3) #valueborder
                    if diplomacyvalue >= 0:
                        diplomacyr, diplomacyg, diplomacyb = 42, 232, 61
                        diplomacyvaluetext = f"+{round(diplomacyvalue,1)}"
                    else:
                        diplomacyr, diplomacyg, diplomacyb = 232, 42, 42
                        diplomacyvaluetext = f"{round(diplomacyvalue,1)}"
                    if diplomacyvalue > 999 or diplomacyvalue <-999:
                        diplomacyvaluetext = '-999'
                    custom_text(diplomacyvaluetext, 23, diplomacyr, diplomacyg,diplomacyb, 773, 210)
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                        elif event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                diplomacy_screen = False
                        elif event.type == pygame.MOUSEBUTTONDOWN: #pretty much just checking what diplomacy option you have selected
                            toblit = ''
                            if checkamount == False and checkcity == False:
                                if 110 <= mouse[0] <= 435:
                                    if 310 <= mouse[1] <= 345:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = 'Invite To Faction'
                                        if "Request to Join Faction" in Demand_Text_To_Blit:
                                            Demand_Text_To_Blit.remove("Request to Join Faction")
                                        if "Kick From Faction" in Offer_Text_To_Blit:
                                            Offer_Text_To_Blit.remove("Kick From Faction")
                                        if "Create Puppet" in Offer_Text_To_Blit:
                                            Offer_Text_To_Blit.remove("Create Puppet")
                                    elif 350 <= mouse[1] <= 385:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Kick From Faction"
                                        if "Invite To Faction" in Offer_Text_To_Blit:
                                            Offer_Text_To_Blit.remove("Invite To Faction")
                                        if "Request to Join Faction" in Demand_Text_To_Blit:
                                            Demand_Text_To_Blit.remove("Request to Join Faction")
                                        if "Create Puppet" in Offer_Text_To_Blit:
                                            Offer_Text_To_Blit.remove("Create Puppet")
                                    elif 390 <= mouse[1] <= 425:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit ="Offer Payment"
                                        if toblit not in Offer_Text_To_Blit:
                                            checkamount = True
                                        
                                        manpowermultiplier = 1
                                        demand = False
                                    elif 430 <= mouse[1] <= 465:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Offer Manpower"
                                        if toblit not in Offer_Text_To_Blit:
                                            checkamount = True
                                        manpowermultiplier = 10
                                        demand = False
                                    elif 470 <= mouse[1] <= 505:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Offer City"
                                        if toblit not in Offer_Text_To_Blit:
                                            checkcity = True
                                        else:
                                            cityofferdisplayfolder.clear()
                                        demand = False
                                        citydisplaycounter = 0
                                    elif 510 <= mouse[1] <= 545:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Create Puppet"
                                        if "Invite To Faction" in Offer_Text_To_Blit:
                                            Offer_Text_To_Blit.remove("Invite To Faction")
                                        if "Kick From Faction" in Offer_Text_To_Blit:
                                            Offer_Text_To_Blit.remove("Kick From Faction")
                                        if "Request to Join Faction" in Demand_Text_To_Blit:
                                            Demand_Text_To_Blit.remove("Request to Join Faction")
                                    if toblit != '' and toblit in Offer_Text_To_Blit:
                                        Offer_Text_To_Blit.remove(toblit)
                                        if toblit == "Offer Payment":
                                            paymentcost = 0
                                        elif toblit == "Offer Manpower":
                                            manpowercost = 0
                                    elif toblit != '':
                                        Offer_Text_To_Blit.append(toblit)  
                                                
                                elif 1100 <= mouse[0] <= 1425:
                                    if 310 <= mouse[1] <= 345:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Request to Join Faction"
                                        if "Invite To Faction" in Offer_Text_To_Blit:
                                            Offer_Text_To_Blit.remove("Invite To Faction")
                                        if "Kick From Faction" in Offer_Text_To_Blit:
                                            Offer_Text_To_Blit.remove("Kick From Faction")
                                        if "Create Puppet" in Offer_Text_To_Blit:
                                            Offer_Text_To_Blit.remove("Create Puppet")
                                    elif 350 <= mouse[1] <= 385:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Request Payment"
                                        manpowermultiplier = 1
                                        if toblit not in Demand_Text_To_Blit:
                                            checkamount = True
                                        paymentdemand = 0
                                        demand = True
                                    elif 390 <= mouse[1] <= 425:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Request City"
                                        if toblit not in Demand_Text_To_Blit:
                                            checkcity = True
                                        else:
                                            citydemanddisplayfolder.clear()
                                        demand = True
                                        citydisplaycounter = 0
                                    elif 430 <= mouse[1] <= 465:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Request Manpower"
                                        if toblit not in Demand_Text_To_Blit:
                                            checkamount = True
                                        manpowermultiplier = 10
                                        manpowerdemand = 0
                                        demand = True
                                    elif 470 <= mouse[1] <= 505:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Request War Support"
                                    elif 510 <= mouse[1] <= 545:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        toblit = "Request Peace"
                                    if toblit != '' and toblit in Demand_Text_To_Blit:
                                        Demand_Text_To_Blit.remove(toblit)
                                        if toblit == "Demand Payment":
                                            paymentdemand = 0
                                        elif toblit == "Demand Manpower":
                                            manpowerdemand = 0
                                    elif toblit != '':
                                        Demand_Text_To_Blit.append(toblit)
                            if checkamount == True:
                                if 130 <= mouse[0] <= 210 and 570 <= mouse[1] <= 610:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    costvalue += 1000
                                if 230 <= mouse[0] <= 310 and 570 <= mouse[1] <= 610:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    costvalue += 10000
                                if 330 <= mouse[0] <= 410 and 570 <= mouse[1] <= 610:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    costvalue += 100000
                                if 130 <= mouse[0] <= 210 and 670 <= mouse[1] <= 710:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    if (costvalue - 1000) >= 0:
                                        costvalue -= 1000
                                if 230 <= mouse[0] <= 310 and 670 <= mouse[1] <= 710:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    if (costvalue - 10000) >= 0:
                                        costvalue -= 10000
                                if 330 <= mouse[0] <= 410 and 670 <= mouse[1] <= 710:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    if costvalue - (100000) >= 0:
                                        costvalue -= 100000
                                if  330 <= mouse[0] <= 410 and 625 <= mouse[1] <= 655:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    if manpowermultiplier ==1:
                                        if demand == True:
                                            paymentdemand = costvalue
                                        else:
                                            paymentcost = costvalue
                                    else:
                                        if demand == True:
                                            manpowerdemand = costvalue
                                        else:
                                            manpowercost = costvalue
                                    costvalue = 0
                                    checkamount = False
                                if 130 <= mouse[0] <= 210 and 625 <= mouse[1] <= 655:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    costvalue = 0
                                    if manpowermultiplier == 1:
                                        if demand == False:
                                            toblit = "Offer Payment"
                                        else:
                                            toblit = "Request Payment"
                                    else:
                                        if demand == False:
                                            toblit = "Offer Manpower"
                                        else:
                                            toblit = "Request Manpower"
                                    if demand == False:
                                        Offer_Text_To_Blit.remove(toblit)
                                    else:
                                        Demand_Text_To_Blit.remove(toblit)
                                    checkamount = False
                            elif 1100 <= mouse[0] <= 1425 and 700 <= mouse[1] <= 735: #if you click the send offer button, checks the value, checks for errors, then implements any changes
                                pygame.mixer.music.set_volume(0.01)
                                music(1)
                                if diplomacyvalue >= 0:
                                    flag, error_message = DiplomacyEffect(Offer_Text_To_Blit, Demand_Text_To_Blit, player_country, selectedcountry, paymentcost, manpowercost, paymentdemand, manpowerdemand, citydemanddisplayfolder, cityofferdisplayfolder)
                                    if flag == False:
                                        display_error_message = True
                                    else:
                                        diplomacy_screen = False
                                else:
                                    error_message = 'REJECTED'
                                    display_error_message = True                        
                           
                elif selected and display_screen == 2: #city list screen
                    CitiesListScreen(Cities)
                elif selected and display_screen == 3: #Army display screen, mainly just text telling you how many armies you have, stats and where they are
                    global InfTrainNo, MechTrainNo, ArmorTrainNo, newarmynumber, calculatecost, calculatetraintime, Trainerror, calculatemanpower, costmodifier, TimeModifier, ManpowerModifier
                    pygame.draw.rect(screen, (255,253,208), [100, 50, 1340, 700]) #mainbox
                    pygame.draw.rect(screen, (92, 64,52), [100, 50, 1340, 700], 6) #border
                    pygame.draw.line(screen, (92, 64,52), [100, 105], [1437, 105], 6) #divider
                    DeleteSymbol = pygame.transform.scale(pygame.image.load(f"GeneralImages\ArmyDelete.png"), (45,25))
                    y = 75
                    custom_text('Icon', 33, 0, 0, 0, 230, y)
                    custom_text('Name', 33, 0, 0, 0, 400, y)
                    custom_text('Infantry', 33, 0, 0, 0, 590, y)
                    custom_text('Armored', 33, 0, 0, 0, 800, y)
                    custom_text('Mechanized', 33, 0, 0, 0, 1030, y)
                    custom_text('Stationed', 33, 0, 0, 0, 1270, y)
                    armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
                    armytotalcounter = 0
                    canTrain = True
                    UpdateNameList = []
                    y += 20
                    removalList = []
                    for item in armyinfo: #Gets data and creates a list of all the armies you have
                        country, oldx, oldy, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, OldCanMove, Name, Stationed, siegestatus, armysize, maxsize, traintime = item.split()
                        removalList.append(item)
                        traintime = int(traintime)
                        if country == player_country:
                            y += 35
                            maxchecker = max(int(InfantryDivNo), int(ArmoredDivNo), int(MechanizedDivNo))
                            if maxchecker == int(InfantryDivNo):
                                Icon = pygame.transform.scale(pygame.image.load(f"GeneralImages\InfantryDivision.png"), (45,25))
                            elif maxchecker == int(ArmoredDivNo):
                                Icon = pygame.transform.scale(pygame.image.load(f"GeneralImages\TankDivision.png"), (45,25))
                            else:
                                Icon = pygame.transform.scale(pygame.image.load(f"GeneralImages\MechDivision.png"), (45,25))
                            if traintime > 0:
                                TimeIcon = pygame.transform.scale(pygame.image.load(f"Assets\TimerIcon.png"), (45,25))
                                screen.blit(TimeIcon, (130, y-12))
                            screen.blit(Icon, (210, y-10))
                            custom_text(Name, 22, 0, 0, 0, 400, y)
                            custom_text(InfantryDivNo, 22, 0, 0, 0, 590, y)
                            custom_text(ArmoredDivNo, 22, 0, 0, 0, 800, y)
                            custom_text(MechanizedDivNo, 22, 0, 0, 0, 1030, y)
                            custom_text(Stationed, 22, 0, 0, 0, 1270, y)
                            screen.blit(DeleteSymbol, (1360, y-15))
                            CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
                            militaryupdatelist = []
                            if pygame.mouse.get_pressed()[0] and  1360 <= mouse[0] <= 1405 and y-15 <= mouse[1] <= y+10: #removing an army
                                pygame.mixer.music.set_volume(0.01)
                                music(1)
                                pygame.time.wait(100)
                                removalList.remove(item)
                                for countryitem in CountryData: #removes armysize from the military of a country
                                    countryitems = countryitem.split()
                                    if countryitems[0] == player_country:
                                        military = int(countryitems[3])
                                        military -= int(armysize)
                                        countryitems[3] = str(military)
                                        militaryupdatelist.append(' '.join(countryitems))
                                    else:
                                        militaryupdatelist.append(countryitem)
                                with open('TextFiles\Countries.txt', 'w') as file:
                                    file.write('\n'.join(militaryupdatelist))
                            pygame.draw.line(screen, (92, 64,52), [100, y+17], [1437, y+17], 3) #divider
                            numbermerger = []
                            for letter in Name:
                                if letter.isdigit() == True:
                                    numbermerger.append(letter)
                            UpdateNameList.append(int(''.join(numbermerger)))
                            armytotalcounter += 1
                    with open('ArmyInfo\ArmyLocation.txt', 'w') as file:
                        file.write('\n'.join(removalList))
                    if armytotalcounter == 16: #limits the amount of armies you can have
                        canTrain = False
                    if canTrain == False: #displays if you are at max armies
                        custom_text("Army Slots Full", 30, 255, 12, 20, 1190, 700)
                    if len(UpdateNameList) != 0:
                        UpdateNameList.sort()
                        newarmynumber = int(UpdateNameList[-1]) + 1
                    else:
                        newarmynumber = 1
                    
                    textbutton((173, 216, 230), (30, 30, 255), 583, 986, 670, 720, 413, 50, 'Train Army', 0, 0, 0, 25)
                    pygame.draw.rect(screen, (0,0,0), [583, 670, 413, 50],3)
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            if 583 <= mouse[0] <= 986 and 670 <= mouse[1] <= 720: #if you click on the train army button, also some one time definitions
                                pygame.mixer.music.set_volume(0.01)
                                music(1)
                                if canTrain == True:
                                    display_screen = 4
                                    InfTrainNo = 0
                                    MechTrainNo = 0
                                    ArmorTrainNo = 0
                                    calculatecost = 0
                                    calculatetraintime = float(0)
                                    calculatemanpower = 0
                                    Trainerror = False
                                    costmodifier, TimeModifier, ManpowerModifier = ArmyBuildingBonusCalculator(player_country)
                        elif event.type == pygame.KEYDOWN: #if you click escape, returns you to the main city screen thing (see all the cities/countries)
                            if event.key == pygame.K_ESCAPE:
                                screenshiftright = False
                                shortcut = False
                                display_screen = 0
                                selected = False
                elif selected and display_screen == 4: #Army Training screen
                    trainingbonus = 1
                    InfDisplayNo = str(InfTrainNo) #This stuff is just converting the integers/floats into displayable strings
                    MechDisplayNo = str(MechTrainNo)
                    ArmorDisplayNo = str(ArmorTrainNo)
                    ManpowerDisplayNo = CitiesListStatShortener(str(int(round(calculatemanpower, 0))))
                    cost = CitiesListStatShortener(str(int(round(calculatecost,0))))
                    Traintime = math.ceil(calculatetraintime)
                    display_country = player_country 
                    if player_country == 'SovietUnion': #special case for the soviets because their name is too long
                        display_country = 'Soviet'
                    if InfTrainNo + MechTrainNo + ArmorTrainNo == 0: #kinda a cheat, allows for more precise troop train time calculations
                        Traintime = str(0)
                    TrainName = f'{display_country}Army{newarmynumber}' #Name of the army

                    #Design
                    pygame.draw.rect(screen, (255,253,208), [100, 50, 1340, 700]) #mainbox
                    pygame.draw.rect(screen, (92, 64,52), [100, 50, 1340, 700], 6) #border
                    custom_text('Army Training', 40, 0, 0, 0, 770, 85)
                    pygame.draw.line(screen, (92, 64,52), [100, 125], [1437, 125], 6) #divider
                    custom_text('Infantry Divsions:', 30, 0, 0, 0, 300, 165) #regular text
                    custom_text('Armored Divisions:', 30, 0, 0, 0, 310, 245)
                    custom_text('Mechanized Divisions:', 30, 0, 0, 0, 335, 325)
                    custom_text('Name:', 30, 0, 0, 0, 210, 405)
                    pygame.draw.line(screen, (92, 64,52), [100, 435], [1437, 435], 6) #divider
                    custom_text(InfDisplayNo, 30, 0, 0, 0, 1250, 165) #text numbers/name
                    custom_text(ArmorDisplayNo, 30, 0, 0, 0, 1250, 245)
                    custom_text(MechDisplayNo, 30, 0, 0, 0, 1250, 325)
                    custom_text(TrainName, 30, 0, 0, 0, 1220, 405)
                    y = 165
                    for i in range(0,3): #increase/decrease arrows
                        textbutton((173, 216, 230), (30, 30, 255), 1275, 1315, y-20, y+20, 40, 40, '>', 0, 0, 0, 30)
                        textbutton((173, 216, 230), (30, 30, 255), 1185, 1225, y-20, y+20, 40, 40, '<', 0, 0, 0, 30)
                        y += 80
                    custom_text('Training Time:', 30, 0, 0, 0, 280, 475)
                    custom_text('Cost:', 30, 0, 0, 0, 205, 535)
                    custom_text('Manpower:', 30, 0, 0, 0, 250, 595)
                    custom_text(f'{Traintime} Turns', 30, 0, 0, 0, 1250, 475)
                    custom_text(cost, 30, 0, 0, 0, 1250, 535)
                    custom_text(ManpowerDisplayNo, 30, 0, 0, 0, 1250, 595)
                    textbutton((173, 216, 230), (30, 30, 255), 583, 986, 640, 690, 413, 50, 'Train', 0, 0, 0, 25) #Train Button
                    pygame.draw.rect(screen, (0,0,0), [583, 640, 413, 50],3)
                    #checks how much money your nation has
                    CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
                    for item in CountryData:
                        country, treasury, GDP, military, manpower, population, focus = item.split()
                        if country == player_country:
                            balance = treasury
                            if focus == 'Training':
                                trainingbonus = 0.8
                            
                    if Trainerror == True: #if you have tried training troops and don't meet the requirements
                        if int(calculatecost) > int(balance):
                            custom_text("Not Enough Money", 30, 255, 12, 20, 790, 715)
                        else:
                            custom_text("Army Can't Be Empty", 30, 255, 12, 20, 790, 715)
                        if pygame.mouse.get_pressed()[0] and mouse[0] < 583 or mouse[0] > 986 and mouse[1] < 640 or mouse[1] > 690:
                            Trainerror = False
                    for event in pygame.event.get(): #calculates the stats of each trained army
                        if event.type == pygame.QUIT:
                            pygame.quit()
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            if 1275 <= mouse[0] <= 1315: #controls the increasing of divisions\
                                if ArmorTrainNo + MechTrainNo + InfTrainNo < 14:
                                    if 145 <= mouse[1] <= 185:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        InfTrainNo += 1
                                        calculatecost += 25000 *costmodifier
                                        calculatetraintime += 0.2 *TimeModifier*trainingbonus
                                        calculatemanpower += 40000 *ManpowerModifier
                                    elif 225 <= mouse[1] <= 265:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        ArmorTrainNo += 1
                                        calculatecost += 50000 *costmodifier
                                        calculatetraintime += 0.4 *TimeModifier*trainingbonus
                                        calculatemanpower += 20000*ManpowerModifier
                                    elif 305 <= mouse[1] <= 345:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        MechTrainNo += 1
                                        calculatecost += 30000 *costmodifier
                                        calculatetraintime += 0.3 *TimeModifier*trainingbonus
                                        calculatemanpower += 30000*ManpowerModifier
                            elif 1185 <= mouse[0] <= 1225: #decreasing of divisions
                                if 145 <= mouse[1] <= 185:
                                    if InfTrainNo != 0:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        InfTrainNo -= 1
                                        calculatecost -= 25000 *costmodifier
                                        calculatetraintime -= 0.2 *TimeModifier*trainingbonus
                                        calculatemanpower -= 40000*ManpowerModifier
                                elif 225 <= mouse[1] <= 265:
                                    if ArmorTrainNo != 0:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        ArmorTrainNo -= 1
                                        calculatecost -= 50000 *costmodifier
                                        calculatetraintime -= 0.4 *TimeModifier*trainingbonus
                                        calculatemanpower -= 20000*ManpowerModifier
                                elif 305 <= mouse[1] <= 345:
                                    if MechTrainNo != 0:
                                        pygame.mixer.music.set_volume(0.01)
                                        music(1)
                                        MechTrainNo -= 1
                                        calculatecost -= 30000 *costmodifier
                                        calculatetraintime -= 0.3 *TimeModifier*trainingbonus
                                        calculatemanpower -= 30000*ManpowerModifier
                            
                            elif 583 <= mouse[0] <= 986 and 640 <= mouse[1] <= 690: #training the armies
                                if int(calculatecost) <= int(balance) and ArmorTrainNo + MechTrainNo + InfTrainNo > 0:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    newbalance = int(balance) - int(calculatecost)
                                    armyupdatelist = []
                                    countryupdatelist = []
                                    for item in CountryData: #checks the country data file
                                        country, treasury, GDP, military, manpower, population, focus = item.split()
                                        if country == player_country: #updates your country stats
                                            countryupdatelist.append(f"{country} {newbalance} {GDP} {int(round(int(military) + calculatemanpower, 0))} {manpower} {population} {focus}")
                                        else:
                                            countryupdatelist.append(f"{country} {treasury} {GDP} {military} {manpower} {population} {focus}")
                                    
                                    with open('TextFiles\Countries.txt','w') as file:
                                        file.write('\n'.join(countryupdatelist))
                                    #Manpowerupdater
                                    citycounter = 0
                                    player_update_list = []
                                    normal_update_list = []
                                    for item in Cities:
                                        city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split() 
                                        if country == player_country:
                                            citycounter +=1
                                            player_update_list.append(item)
                                        else:
                                            normal_update_list.append(item)
                                    manpowercostpercity = calculatemanpower/citycounter
                                    new_player_update_list = []
                                    for item in player_update_list:
                                        city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split() 
                                        new_player_update_list.append(f"{city} {x} {y} {country} {city_income} {int(round(int(city_manpower) - manpowercostpercity,0))} {population} {barracks} {factory}  {market} {fort} {citytype}")
                                    combined_list = normal_update_list + new_player_update_list
                                    CityWriteFile = open('TextFiles\CityNames.txt', 'w')
                                    CityWriteFile.write('\n'.join(combined_list))
                                    
                                    #adds the new army to the army text file
                                    standingmanpower = calculatemanpower/ManpowerModifier
                                    newarmy = f"\n{player_country} {100000} {100000} {InfDisplayNo} {ArmorDisplayNo} {MechDisplayNo} t {TrainName} none f {int(round(standingmanpower,0))} {int(round(standingmanpower,0))} {math.ceil(calculatetraintime)}"
                                    with open('ArmyInfo\ArmyLocation.txt', 'a') as file:
                                        file.write(newarmy)
                                    display_screen = 3
                                else:
                                    Trainerror = True
                                    
                                    

                        elif event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                display_screen = 3
                elif selected and display_screen == 5:#World news screen
                    global Month, initialindex
                    display_list = []
                    pygame.draw.rect(screen, (255,253,208), [100, 50, 1340, 700]) #mainbox
                    pygame.draw.rect(screen, (92, 64,52), [100, 50, 1340, 700], 6) #border
                    custom_text('World News', 40, 0, 0, 0, 770, 85)
                    pygame.draw.line(screen, (92, 64,52), [100, 125], [1437, 125], 6) #divider
                    textbutton([173, 216, 230], [30, 30, 255], 1300, 1400, 150, 300, 100, 150, "", 0, 0, 0, 25)
                    custom_text("^",60, 0, 0, 0,1350, 230)
                    pygame.draw.rect(screen,(92, 64, 51),[1300,150, 100, 150],4)
                    textbutton([173, 216, 230], [30, 30, 255], 1300, 1400, 575, 725, 100, 150, "", 0, 0, 0, 25)
                    custom_text("v",50, 0, 0, 0, 1350, 640)
                    pygame.draw.rect(screen,(92, 64, 51),[1300,575, 100, 150],4)
                    worldeventfile = ((open('TextFiles\WorldEvents.txt', 'r')).read()).split('\n')
                    displaylist = []
                    worldeventy = 150
                    for item in worldeventfile: #checks for items in the world news file
                        if item != '':
                            displaylist.append(item)
                    for i in range(0, 10): #displays the items in the world news file
                        displaytext2 = ''
                        if initialindex < len(displaylist):
                            displaytext = displaylist[initialindex]
                            if len(displaytext) >= 100:
                                displaytext, displaytext2 = displaytext[:len(displaytext)//2], displaytext[len(displaytext)//2:] 
                            custom_text(displaytext, 20, 0, 0, 0, 770, worldeventy)
                            if displaytext2 != '':
                                worldeventy += 20
                                custom_text(displaytext2, 20, 0, 0, 0, 770, worldeventy)
                        worldeventy += 40
                        initialindex += 1
                    initialindex -= 10
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                selected = False
                                display_screen = 0
                        if event.type == pygame.MOUSEBUTTONDOWN: #scrollable list
                            if len(displaylist) > 10:
                                if 1300 <= mouse[0] <= 1400 and 150 <= mouse[1] <= 300:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    if initialindex > 0:
                                        initialindex -= 1
                                if 1300 <= mouse[0] <= 1400 and 575 <= mouse[1] <= 725:
                                    pygame.mixer.music.set_volume(0.01)
                                    music(1)
                                    if initialindex < len(displaylist) -10:
                                        initialindex += 1
                    
                elif selected and display_screen == 6: #Focus Screen
                    CountryDataFile = ((open('TextFiles\Countries.txt', 'r')).read()).split('\n')
                    pygame.draw.rect(screen, (255,253,208), [100, 50, 1340, 700]) #mainbox
                    pygame.draw.rect(screen, (92, 64,52), [100, 50, 1340, 700], 6) #border
                    pygame.draw.line(screen, (92, 64,52), [100, 115], [1437, 115], 6) #divider
                    custom_text('National Focus', 40, 0, 0, 0, 770, 85)
                    images_to_blit = ['Industry', 'Defense', 'Manpower', 'Planes', 'Training', 'Travel']
                    imagesindex = 0
                    x = 225
                    clicked = 'None'
                    for i in range(0,3): #displays first 3 focus assets and checks if you click one
                        screen.blit(pygame.transform.scale(pygame.image.load(f'FocusAssets\{player_country}_{images_to_blit[imagesindex]}.png'), (280, 280)), (x, 150))
                        if images_to_blit[imagesindex] == currentFocus:
                            pygame.draw.rect(screen, (84, 237, 50), [x-7, 137, 300, 300],3)
                        if pygame.time.get_ticks() - 200 >= focus_click_time and pygame.mouse.get_pressed()[0] and x <= mouse[0] <= x+280 and 150 <= mouse[1] <= 430:
                            pygame.mixer.music.set_volume(0.01)
                            music(1)
                            clicked = images_to_blit[imagesindex]
                        x += 400 
                        imagesindex+= 1
                        
                    x = 225
                    for i in range(0,3): #displays second 3 focus assets and checks if you click one
                        screen.blit(pygame.transform.scale(pygame.image.load(f'FocusAssets\{player_country}_{images_to_blit[imagesindex]}.png'), (280, 280)), (x, 450))
                        if images_to_blit[imagesindex] == currentFocus:
                            pygame.draw.rect(screen, (84, 237, 50), [x-7, 437, 300, 300],3)
                        if pygame.time.get_ticks() - 200 >= focus_click_time and pygame.mouse.get_pressed()[0] and x <= mouse[0] <= x+280 and 450 <= mouse[1] <= 730:
                            pygame.mixer.music.set_volume(0.01)
                            music(1)
                            clicked = images_to_blit[imagesindex]
                        x += 400 
                        imagesindex+= 1
                    updaterlist = []
                    for item in CountryDataFile:#checks the current Focus + changes to new Focus
                        country, treasury, GDP, military, manpower, population, Focus = item.split()
                        if country == player_country:
                            currentFocus = Focus
                            if clicked != 'None' and clicked != Focus:
                                Focus = clicked
                            else:
                                clicked = 'None'
                        updaterlist.append(f"{country} {treasury} {GDP} {military} {manpower} {population} {Focus}")
                    
                    if clicked != 'None':
                        with open('TextFiles\Countries.txt', 'w') as file:
                            file.write('\n'.join(updaterlist))
                        BuildingBonusApplier()
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                        elif event.type == pygame.KEYDOWN:
                            if event.key == K_ESCAPE:
                                display_screen = 1
                elif selected and display_screen == 7: #Ends the game
                    gameend(playerwin)         

            elif country_selected == False: #country selection screen
                CountrySelection()
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                    elif event.type == pygame.MOUSEBUTTONDOWN: #checks which country you have picked and assigns you cities
                        pygame.mixer.music.set_volume(0.01)
                        music(1)
                        click_time = pygame.time.get_ticks()
                        if 109 <= mouse[0] <= 445 and 168 <= mouse[1] <= 737:
                            player_country = 'UK'
                            country_selected = True
                            allocatedcities = ['London', 'Birmingham', 'Manchester', 'Edinburgh', 'Jerusalem', 'Dubai', 'Alexandria', 'Cairo',]
                        elif 445 < mouse[0] <= 762 and 170 <= mouse[1] <= 737:
                            player_country = 'France'
                            country_selected = True
                            allocatedcities = ['Paris', 'Metz', 'Lyon', 'Marseille', 'Nantes', 'Algiers', 'Ajaccio', 'Oran', 'Tunis', 'Rabat', 'Crampel', 'Beirut']
                        elif 762 < mouse[0] <= 1111 and 170 <= mouse[1] <= 737:
                            player_country = 'Germany'
                            country_selected = True
                            allocatedcities = ['Berlin', 'Hamburg', 'Gdansk', 'Munich', 'Vienna', 'Prague', 'Kosice']
                        elif 1111 < mouse[0] <= 1439 and 170 <= mouse[1] <= 737:
                            player_country = 'SovietUnion'
                            country_selected = True
                            allocatedcities = ['Moscow', 'Leningrad', 'Minsk', 'Kiev', 'Tbilisi', 'Stalingrad']
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            Menu_screen = 1
    def TurnButton(): #End Turn Button moves onto the next turn and performs the necessary changes/calculations
        global Month, TurnButtonclicktime
        open('TextFiles\WorldEvents.txt', 'w')
        manpowerincrease = 0.11
        if TurnButtonclicktime + 3000 < pygame.time.get_ticks():
            pygame.mixer.music.set_volume(0.1)
            music(2)
            Month += 1
            CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
            countrywritelist = []    
            for item in CountryData: #checking for the country's information, adds GDP to treasury
                country, treasury, GDP, military, manpower, population, Focus = item.split()
                treasury = int(treasury) + int(GDP)           
                countrywritelist.append(f"{country} {treasury} {GDP} {military} {manpower} {population} {Focus}")
            with open('TextFiles\Countries.txt', 'w') as file:
                file.write('\n'.join(countrywritelist))
            
            Cityreadfile = ((open('TextFiles\CityNames.txt', 'r')).read()).split("\n")
            Citywritelist = []
            for item in Cityreadfile : #updates manpower and population for each city
                city, x, y, country, city_income, city_manpower, ogpopulation, barracks, factory, market, fort, citytype = item.split()
                population = int(round(int(ogpopulation)*1.006, 0))
                city_manpower = int(city_manpower)
                if country == 'SovietUnion':
                    manpowerincrease = 0.2
                city_manpower += (population-int(ogpopulation))*manpowerincrease
                Citywritelist.append(f"{city} {x} {y} {country} {city_income} {str(int(round(city_manpower,0)))} {population} {barracks} {factory} {market} {fort} {citytype}")
            with open('TextFiles\CityNames.txt', 'w') as file:
                file.write('\n'.join(Citywritelist))
            
            Capital_city = 'none'
            armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
            armywritelist = []
            for item in armyinfo:
                controlledcities = []
                items = item.split()
                items[6] = 't'
                number = int(items[12])
                if number != 0:
                    items[12] = str(number-1)
                if number-1 == 0:
                    for city in Cities: #checks which city is your capital city
                        city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = city.split() 
                        for cityitem in allocatedcities:
                            if cityitem[0] in item:
                                controlledcities.append(f"{city} {citytype}")
                            if cityitem[0] in item and citytype == 't':
                                Capital_city = f"{cityitem[0]}, {citytype}"
                    if Capital_city in controlledcities:
                        cityname, citiestype = Capital_city.split()
                        Deploycity = cityname
                    else:
                        for controlleditem in controlledcities:
                            cityname, citiestype = controlleditem.split()
                            Deploycity = cityname
                    
                    items[8] = Deploycity

                armywritelist.append(' '.join(items))
            with open('ArmyInfo\ArmyLocation.txt', 'w') as file: #adds trained armies to the capital city
                file.write('\n'.join(armywritelist))

            CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
            for item in CountryData: #Computer takes it's turn
                country, treasury, GDP, military, manpower, population, Focus = item.split()
                if country != player_country:
                    InfoCalculator(country,int(treasury), int(military), int(manpower), Focus, Month)

            
            TurnButtonclicktime = pygame.time.get_ticks()
            if historicalmode == True and player_country != 'Germany': #if in historical mode, historical war declarations take place
                HistoricalAlliances(Month)
    
        else:
            pygame.draw.rect(screen,(255,253,208),[1300, 47, 125, 40]) #selectionscreen
            pygame.draw.rect(screen, (43, 43, 43), [1295, 45, 130, 44], 5) #border
            custom_text('Please Wait', 15, 255, 0, 0, 1360, 65)

    def CountrySelection(): #country selection screen, all just design, not much functionality
        pygame.draw.rect(screen,(255,253,208),[100, 50, screenwidth-200, 120]) #selectionscreen
        pygame.draw.rect(screen, (92, 64, 51), [100, 50, screenwidth-200, screenheight-100], 10) #border
        buttons([255, 255, 237], [255,253,208], 109, 445, 168, 737, 336, 575) #UK button
        custom_text('Medium Difficulty', 30, 0, 0, 0, 278, 438)
        custom_text('Medium Economy', 30, 0, 0, 0, 278, 488)
        custom_text('Medium Industry', 30, 0, 0, 0, 278, 538)
        custom_text('Weak Military', 30, 0, 0, 0, 278, 588)
        custom_text('Strong Airforce', 30, 0, 0, 0, 278, 638)
        buttons([255, 255, 237], [255,253,208], 445, 762, 168, 737, 317, 575) #France
        custom_text('Hard Difficulty', 30, 0, 0, 0, 608, 438)
        custom_text('Weak Economy', 30, 0, 0, 0, 608, 488)
        custom_text('Medium Industry', 30, 0, 0, 0, 608, 538)
        custom_text('Weak Military', 30, 0, 0, 0, 608, 588)
        custom_text('Weak Airforce', 30, 0, 0, 0, 608, 638)
        buttons([255, 255, 237], [255,253,208], 762, 1111, 168, 737, 349, 575) #Germany
        custom_text('Easy Difficulty', 30, 0, 0, 0, 938, 438)
        custom_text('Strong Economy', 30, 0, 0, 0, 938, 488)
        custom_text('Strong Industry', 30, 0, 0, 0, 938, 538)
        custom_text('Strong Military', 30, 0, 0, 0, 938, 588)
        custom_text('Strong Airforce', 30, 0, 0, 0, 938, 638)
        buttons([255, 255, 237], [255,253,208], 1111, 1439, 168, 737, 328, 575) #Soviet
        custom_text('Medium Difficulty', 30, 0, 0, 0, 1278, 438)
        custom_text('Medium Economy', 30, 0, 0, 0, 1278, 488)
        custom_text('Weak Industry', 30, 0, 0, 0, 1278, 538)
        custom_text('Medium Military', 30, 0, 0, 0, 1278, 588)
        custom_text('Weak Airforce', 30, 0, 0, 0, 1278, 638)
        pygame.draw.rect(screen, (92, 64, 51), [100, 50, screenwidth-200, 120], 6) #divder
        pygame.draw.rect(screen, (92, 64, 51), [445, 164, 320, screenheight-215], 6)#divder
        pygame.draw.rect(screen, (92, 64, 51), [1110, 164, 330, screenheight-215], 6)#divder
        Titletext('Select Your Country', 0, 0, 0, screenwidth/2, 110)
        Othertext('United Kingdom', 0,0,0,268,200)
        Othertext('France', 0,0,0,603,200)
        Othertext('German Reich', 0,0,0,938,200)
        Othertext('Soviet Union', 0,0,0,1273,200)
        screen.blit(BritainImage, (190,240))
        screen.blit(FranceImage, (520, 240))
        screen.blit(GermanyImage, (850, 240))
        screen.blit(RussiaImage, (1185, 240))

    def ActionMenu(): #action menu in the top left, quick access to various important features
        global menu_open, Menu_screen, selected, display_screen, city_screen_running, shortcut, ViewDivisionMakeup, checkformovement, screenshiftright, displaywarinfo
        off_colour = (255,253,208)
        on_colour = (255, 232, 205)
        border_colour= (77,47,2)
        if menu_open: #if the action screen menu should be open, allows you to click the arrow to close or open it
            pygame.draw.rect(screen, (43, 43, 43), [0, 0, 390, 90]) #Border
            pygame.draw.rect(screen, (128, 128, 128), [5, 5, 380, 80]) #Background
            circlebuttons(border_colour, off_colour, on_colour, 17, 83, 12, 78, 33, 50, 45) #1
            screen.blit(pygame.transform.scale(pygame.image.load(f"GeneralImages\Home.png"), (140,140)), (-8,-15)) #Country Screen Image
            circlebuttons(border_colour, off_colour, on_colour, 109, 175, 12, 78, 33, 142, 45) #2
            screen.blit(pygame.transform.scale(pygame.image.load(f"GeneralImages\CityScreen.png"), (55,55)), (115,17)) #Cities List Screen Image
            circlebuttons(border_colour, off_colour, on_colour, 201,267, 12, 78, 33, 234, 45) #3
            screen.blit(pygame.transform.scale(pygame.image.load(f"GeneralImages\ArmyScreen.png"), (55,55)), (205,15)) #Armies Screen/Troop Training Image
            circlebuttons(border_colour, off_colour, on_colour, 293, 359, 12, 78, 33, 326, 45) #4
            screen.blit(pygame.transform.scale(pygame.image.load(f"GeneralImages\WorldImage.png"), (55,55)), (298,17)) #Armies Screen/Troop Training Image
            buttons((99, 93, 93), (64, 61, 61), 145, 235, 90, 130, 90, 40) #close button
            custom_text('V', 30, 0, 0, 0, 190, 107)
        elif menu_open == False: #if the action screen menu is closed, gives you the button to open it
            buttons((99, 93, 93), (64, 61, 61), 145, 235, 0, 40, 90, 40) #close button
            custom_text('V', 30, 0, 0, 0, 190, 17)
        if city_screen_running == True:
            display_screen = 2
            selected = True
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 1300 <= mouse[0] <= 1420 and 5 <= mouse[1] <= 45:
                    TurnButton()
                if menu_open == True:
                    if 145 <= mouse[0] <= 235 and 90 <= mouse[1] <= 130: #close
                        pygame.mixer.music.set_volume(0.01)
                        music(1)
                        menu_open = False
                    elif 17 <= mouse[0] <= 83 and 12 <= mouse[1] <= 78: #quick access button for you nation screen
                        pygame.mixer.music.set_volume(0.01)
                        music(1)
                        shortcut = True
                        selected = True
                        display_screen = 1
                        ViewDivisionMakeup = False
                        screenshiftright = False
                        displaywarinfo = False
                    elif 109 <= mouse[0] <= 175 and 12 <= mouse[1] <= 78: #button for list of city screen\
                        pygame.mixer.music.set_volume(0.01)
                        music(1)
                        city_screen_running = True
                        ViewDivisionMakeup = False
                    elif 201 <= mouse[0] <= 267 and 12 <= mouse[1] <= 78: #button for armies list
                        pygame.mixer.music.set_volume(0.01)
                        music(1)
                        selected = True
                        display_screen = 3
                    elif 293 <= mouse[0] <= 359 and 12 <= mouse[1] <= 78: #world events
                        pygame.mixer.music.set_volume(0.01)
                        music(1)
                        selected = True
                        display_screen = 5
                if menu_open == False:
                    if 145 <= mouse[0] <= 235 and 0 <= mouse[1] <= 40:#open
                         pygame.mixer.music.set_volume(0.01)
                         music(1)
                         menu_open = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:#closing the division makeup screen
                    if ViewDivisionMakeup == True:
                        ViewDivisionMakeup = False
                        checkformovement = False
                    else:
                        Menu_screen = 1
                        ViewDivisionMakeup = False
                        checkformovement = False
    def CountryStatRounder(text, size,number, x, y): #rounds numbers to thousands or millions and displays them
        numbers = int(number)
        numlength = len(number)
        if numlength  >= 7:
            display = f"{round(numbers/1000000,1)}M"
        elif numlength >= 4:
            display = f"{round(numbers/1000,1)}K"
        else:
            display = str(numbers)
        custom_text(f"{text}:", size, 0, 0, 0, x-180, y)
        custom_text(display, size, 0,0,0, x+210, y)
    def BuildingIconShortCode(x, text, selected): #building selection shortcut for efficiency (just design reasons)
        circlebuttons((92, 64,52), (99, 93, 93), (64, 61, 61), x-60, x+60, 320, 440, 60, x, 380) #button 
        pygame.draw.circle(screen, (92, 64,52), [x, 380], 60) #border
        pygame.draw.rect(screen, (255,253,208), [x-60, 420, 120, 50]) #textbackground
        pygame.draw.rect(screen, (92, 64, 51), [x-60, 420, 120, 50], 6) #textborder
        custom_text(text, 20, 0, 0, 0, x, 445) #text
        screen.blit(pygame.transform.scale(pygame.image.load(f'BuildingImages\{selected}{text}.png'), (90, 90)), (x-45, 328)) #building Image

    def BuildingUpdateOption(type, bar, fact, mark, fort, xmodifier): #building selection screen, once a building is selected this runs
        global enoughmoney, nomoney, building_click_time
        upgrade = False
        click_time = 0
        levels = ['small', 'medium', 'large'] #used to check what level it is
        if xmodifier > 0:
            upgradechanger = 100
        else:
            upgradechanger = 0
        #design
        pygame.draw.rect(screen, (255,253,208), [upgradechanger + 595, 308, 250, 195]) #mainbox
        pygame.draw.rect(screen, (92, 64,52), [upgradechanger + 595, 308, 250, 195], 6) #border
        screen.blit(pygame.transform.scale(pygame.image.load("GeneralImages\Increase_arrow.png"), (100, 120)),(upgradechanger + 670, 310)) #Upgrade Arrow
        custom_text(f"Upgrade {type}", 23, 0, 0, 0, upgradechanger + 720, 440) #Upgrade text

        pygame.draw.rect(screen, (255,253,208), [upgradechanger + 595, 498, 250, 197]) #mainbox
        pygame.draw.rect(screen, (92, 64,52), [upgradechanger + 595, 498, 250, 197], 6) #border
        for item in levels: #automatically updates each building to the next level and checks if it is at the maximum level
            if type == 'Barracks':
                if bar == item:
                    level = levels.index(item)
                    level +=1
                    if level <= 2:
                        new_level = levels[level]
                    custom_text(f"-{str(3*(level))}% train time", 20, 0, 0, 0, upgradechanger + 723, 525)
                    custom_text(f"-{str(3*(level))}% train cost", 20, 0, 0, 0, upgradechanger + 723, 565)
                    custom_text(f"+{str(25*(level))}% manpower", 20, 0, 0, 0, upgradechanger + 723, 605)

            elif type == 'Factory':
                if fact == item:
                    level = levels.index(item)
                    level +=1
                    if level <= 2:
                        new_level = levels[level]
                    custom_text(f"-{str(2*(level))}% train manpower", 20, 0, 0, 0, upgradechanger + 723, 525)
                    custom_text(f"-{str(3*(level))}% train time", 20, 0, 0, 0, upgradechanger + 723, 565)
            elif type == 'Market':
                if mark == item:
                    level = levels.index(item)
                    level +=1
                    if level <= 2:
                        new_level = levels[level]
                    custom_text(f"+{str(50*(level))}% city income", 20, 0, 0, 0, upgradechanger + 723, 525)
            elif type == 'Fort':
                if fort == item:
                    level = levels.index(item)
                    level +=1
                    if level <=2:
                        new_level = levels[level]
                    custom_text(f"+{str(5*(level))}% defence bonus", 20, 0, 0, 0, upgradechanger + 723, 525)
        pygame.draw.rect(screen, (173, 216, 230), [upgradechanger + 650, 645, 150, 50]) #pricebox
        pygame.draw.rect(screen, (92, 64,52), [upgradechanger + 650, 645, 150, 50], 6) 
        if level == 1:
            custom_text(f"$100k", 20, 0, 0, 0, upgradechanger + 723, 667)
        elif level == 2:
            custom_text(f"$250k", 20, 0, 0, 0, upgradechanger + 723, 667)
            
        if pygame.mouse.get_pressed()[0] and pygame.time.get_ticks() >= building_click_time + 500: #if you click the upgrade button
            pygame.mixer.music.set_volume(0.01)
            music(1)
            building_click_time = pygame.time.get_ticks()
            if xmodifier == 0:
                if mouse[0] >600 and 308 < mouse[1] <505:
                    upgrade = True
            else:
                if mouse[0] < xmodifier and 308 < mouse[1] <505:
                    upgrade = True

        rfilelist = []
        rfile = ((open('TextFiles\CitySave.txt', 'r')).read()).split("\n")
        for line in rfile:
            rfilelist.append(line)
            
        if upgrade == True: #if upgrade button is pressed
            nomoney = False
            if level == 2:
                if type == 'Barracks': #checks what type of building it is
                    BuildingUpdater(rfilelist, new_level, 7,  level)
                elif type == 'Factory':
                    BuildingUpdater(rfilelist, new_level, 8, level)
                elif type == 'Market':
                    BuildingUpdater(rfilelist, new_level, 9, level)
                elif type == 'Fort':
                    BuildingUpdater(rfilelist, new_level, 10,  level)
            elif level == 1:
                if type == 'Barracks': #checks what type of building it is
                    BuildingUpdater(rfilelist, new_level, 7, level)
                elif type == 'Factory':
                    BuildingUpdater(rfilelist, new_level, 8, level)
                elif type == 'Market':
                    BuildingUpdater(rfilelist, new_level, 9, level)
                elif type == 'Fort':
                    BuildingUpdater(rfilelist, new_level, 10, level)
        if level > 2: #if building at max level it tells you
            pygame.draw.rect(screen, (255,253,208), [upgradechanger + 597, 234, 250, 80]) #mainbox
            pygame.draw.rect(screen, (92, 64,52), [upgradechanger + 597, 234, 250, 80], 6) 
            custom_text('Building at Max Level', 19, 255,2, 10, upgradechanger + 720, 274)
        if nomoney == True: #if you don't have enough money it tells you
            pygame.draw.rect(screen, (255,253,208), [upgradechanger + 597, 234, 250, 80]) #mainbox
            pygame.draw.rect(screen, (92, 64,52), [upgradechanger + 597, 234, 250, 80], 6) 
            custom_text('Not Enough Money', 20, 255,2, 10, upgradechanger + 720, 274)
        
    def BuildingUpdater(list, new_level, index, level):
        global enoughmoney, nomoney
        if level ==2: #checks level to determine cost
            cost = 250000
        elif level == 1:
            cost = 100000
        countryrfile = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        countrylist = []
        for line in countryrfile: #reads through the file
            countrystats = line.split()
            if player_country in line:
                #updates the stats
                treasuryvalue = int(countrystats[1])
                if treasuryvalue >= cost: #checks if you have enough money to upgrade
                    treasuryvalue -= cost
                    enoughmoney = True
                    nomoney = False
                else:
                    enoughmoney = False    
                countrystats[1] = str(treasuryvalue)
            countrylist.append(' '.join(countrystats)) #adds new country + stats to list
        if enoughmoney == True:#If you have enough money the building is updated
            with open('Textfiles\Countries.txt', 'w') as file:
                file.write('\n'.join(countrylist)) 
            finalvalue = list[-1]
            if finalvalue == '':
                finalvalue = list[-2]
            updaterlist = []
            for line in list:
                lines = line.split()
                if lines[0] == selectedcity:
                    lines[index] = new_level
                updaterlist.append(' '.join(lines))
            with open('TextFiles\CitySave.txt', 'w') as file:
                file.write('\n'.join(updaterlist))
            BuildingBonusApplier()
        else:
            nomoney = True

    def CountryStatUpdater(country):#updates the country stats depending on changes to the city stats, works similarly to the selection screen
        income_total = 0
        manpower_total = 0
        population_total = 0
        militarysize = 0
        citycount = 0
        #reads the city files
        Cityreadfile = ((open('TextFiles\CityNames.txt', 'r')).read()).split("\n")
        Citysavefile = ((open('TextFiles\CitySave.txt', 'r')).read()).split("\n")
        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
        corecities = []
        for item in Citysavefile:
            items = item.split()
            if items[3] == country:
                corecities.append(items[0])
        for item in Cityreadfile: #checks for any citites belonging to the country
            items = item.split()
            if items[3] == country: #adds the city stats to the total
                citycount += 1
                if items[0] in corecities:
                    income_total += int(items[4])
                    manpower_total += int(items[5])
                    population_total += int(items[6])
                else:
                    income_total += 0.1*(int(items[4]))
                    manpower_total += 0.1*(int(items[5]))
                    population_total += int(items[6])
                

        for armyitem in armyinfo:
            armyitems = armyitem.split()
            if armyitems[0] == country:
                militarysize += int(armyitems[10])

        countryreadfile = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n") #opens to the country file in read mode
        countrylist = []
        for line in countryreadfile: #reads through the file
            countrystats = line.split()
            if country == countrystats[0]: #checks the stats for the country in teh file
                countrystats = line.split() 
                #updates the stats
                countrystats[2] = str(int(round(income_total,0)))
                countrystats[3] = str(militarysize)
                countrystats[4] = str(int(round(manpower_total,0)))
                countrystats[5] = str(population_total)
            countrylist.append(' '.join(countrystats)) #adds new country + stats to list
        if citycount <= 0:
            for item in countrylist:
                if country in item:
                    countrylist.remove(item)
        with open('Textfiles\Countries.txt', 'w') as file:
            file.write('\n'.join(countrylist))
    
    def BuildingBonusApplier(): #applies bonuses from building levels
        City_file = ((open('TextFiles\CitySave.txt', 'r')).read()).split("\n")
        countryreadfile = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        incomebonus = 1
        manpowerbonus = 1
        for item in countryreadfile:
            items = item.split()
            if items[0] == player_country:
                if items[-1] == 'Industry':
                    incomebonus = 1.1
                if items[-1] == 'Manpower':
                    manpowerbonus = 1.1
        Updated_City_stats = []
        for item in City_file : #calculates bonuses for each city using their base (pre bonus) values then applies the bonuses
            if item != '\n':
                city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split() #assigning variable names to all data
                city_income = int(city_income)
                city_manpower = int(city_manpower)
                if barracks == 'small':
                    city_manpower = int(round(city_manpower*1.25*manpowerbonus, 0))
                if barracks == 'medium':
                    city_manpower = int(round(city_manpower*1.5*manpowerbonus, 0))
                if barracks == 'large':
                    city_manpower = int(round(city_manpower*1.75*manpowerbonus, 0))
                if market == 'small':
                    city_income = int(round(city_income*1.5*incomebonus, 0))
                if market  == 'medium':
                    city_income = int(round(city_income*2*incomebonus, 0))
                if market  == 'large':
                    city_income = int(round(city_income*2.5*incomebonus, 0))
                Updated_City_stats.append(f'{city} {x} {y} {country} {city_income} {city_manpower} {population} {barracks} {factory} {market} {fort} {citytype}')
        with open('TextFiles\CityNames.txt', 'w') as file:
            file.write('\n'.join(Updated_City_stats))

    def CitiesListStatShortener(number): #rounds numbers to thousands or millions and displays them. The CountryStatRounder is specific for when the text needs to be displayed in a certain place
        numbers = int(number)
        numlength = len(number)
        if numlength  >= 7:
            shortened = round(numbers/1000000,1)
            display = f"{shortened}M"
        elif numlength >= 4:
            shortened = round(numbers/1000,1)
            display = f"{shortened}K"
        else:
            display = str(numbers)
        return display

    def CitiesListScreen(cities): #Screen that shows you all the citites you control
        global selected, display_screen, city_screen_running, citylistdisplaycounter
        pygame.draw.rect(screen, (255,253,208), [100, 50, 1340, 700]) #mainbox
        pygame.draw.rect(screen, (92, 64,52), [100, 50, 1340, 700], 6) #border
        pygame.draw.line(screen, (92, 64,52), [100, 110], [1437, 110], 6) #divider
        y = 85
        custom_text('City', 30, 0, 0, 0, 180, y)
        custom_text('Income', 30, 0, 0, 0, 310, y)
        custom_text('Manpower', 30, 0, 0, 0, 480, y)
        custom_text('Population', 30, 0, 0, 0, 680, y)
        custom_text('Barracks', 30, 0, 0, 0, 870, y)
        custom_text('Factory', 30, 0, 0, 0, 1030, y)
        custom_text('Market', 30, 0, 0, 0, 1180, y)
        custom_text('Fort', 30, 0, 0, 0, 1310, y)
        textbutton([173, 216, 230], [30, 30, 255], 1360, 1420, 150, 280, 60, 130, "", 0, 0, 0, 25) #Up arrow
        custom_text("^",40, 0, 0, 0, 1388, 215)
        pygame.draw.rect(screen,(92, 64, 51),[1356,146, 64, 134],4)

        textbutton([173, 216, 230], [30, 30, 255], 1360, 1420, 550, 680, 60, 130, "", 0, 0, 0, 25) #Down Arrow
        custom_text("v",40, 0, 0, 0, 1388, 615)
        pygame.draw.rect(screen,(92, 64, 51),[1356,546, 64, 134],4)
        size = 18
        y += 25
        totalcounter = 0
        pickerindex = 0
        displayList = []
        for item in Cities: #checks all the cities you have and display them in a list
            items = item.split()
            if items[3] == player_country:
                totalcounter += 1
                displayList.append(item)
        displaylength = 24
        if len(displayList) < displaylength:
            displaylength = len(displayList)-1
        for i in range(0, displaylength): #makes the list scrollable to prevent overflowing numbers of cities
            y += 25
            item = displayList[citylistdisplaycounter]
            citylistdisplaycounter += 1
            city, x, z, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
            custom_text(city, size, 0, 0, 0, 180, y)
            custom_text(CitiesListStatShortener(city_income), size, 0, 0, 0, 310, y)
            custom_text(CitiesListStatShortener(city_manpower), size, 0, 0, 0, 480, y)
            custom_text(CitiesListStatShortener(population), size, 0, 0, 0, 680, y)
            custom_text(barracks, size, 0, 0, 0, 870, y)
            custom_text(factory, size, 0, 0, 0, 1030, y)
            custom_text(market, size, 0, 0, 0, 1180, y)
            custom_text(fort, size, 0, 0, 0, 1310, y)
                
        citylistdisplaycounter -= displaylength

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    selected = False
                    display_screen = 0
                    city_screen_running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 1360 <= mouse[0] <= 1420 and 150 <= mouse[1] <= 280:
                    if citylistdisplaycounter > 0:
                        citylistdisplaycounter -= 1
                elif 1360 <= mouse[0] <= 1420 and 550 <= mouse[1] <= 680:
                    if citylistdisplaycounter < totalcounter - 25:
                        citylistdisplaycounter += 1
    def ArmyBuildingBonusCalculator(country): #Calculates training bonuses depending on your buildings
        Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
        #building modifier calculator
        barracksbonuscount = 0
        factorybonuscount = 0
        costmodifier = 1
        traintimemodifier = 1
        trainmanpowermodifier = 1
        buildinglist = ['small', 'medium', 'large']
        Cities
        for item in Cities: #works by calculating the index in the building list and using that to multiply the numbers by the correct amount (e.g. large is index 2 (add 1 =3) so the bonus is applied 3 times --> 9% reduction)
            city, x, y, savecountry, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
            if savecountry == country:
                barracksbonuscount += buildinglist.index(barracks) + 1
                factorybonuscount += buildinglist.index(factory) + 1
        for i in range(0, barracksbonuscount): #just calculates the bonus
            traintimemodifier *= 0.97
            costmodifier *= 0.97
        for i in range(0, factorybonuscount):
            trainmanpowermodifier *= 0.98
            traintimemodifier *= 0.97
        return(costmodifier, traintimemodifier, trainmanpowermodifier)
    def DiplomacyEffect(Offer_list, Demand_list, player, othercountry, offermoney, offermanpower, demandmoney, demandmanpower, citydemandlist, cityofferlist): #implements all changes from diplomacy if there are no errors
        CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
        warfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
        factioninfo = ((open('TextFiles\Factions.txt', 'r')).read()).split('\n')
        worldeventfile = ((open('TextFiles\WorldEvents.txt', 'r')).read()).split('\n')
        factionupdatelist = []
        updatelist = []
        newcitieslist = []
        armyupdatelist = []
        eventupdatelist = []
        for item in worldeventfile:
            eventupdatelist.append(''.join(item))
        new_player_manpower = 0
        new_other_manpower = 0
        GDPmodifier = 0
        manpowermodifier = 0
        for item in CountryData: #checking for the country's information 
            country, treasury, GDP, military, manpower, population, focus = item.split()
            if country == player:
                player_country = country
                player_GDP = int(GDP)
                player_military = military
                player_population = population
                player_treasury = int(treasury)
                player_manpower = int(manpower)
                player_focus = focus
            if country == othercountry:
                other_country = country
                other_GDP = int(GDP)
                other_military = military
                other_population = population
                other_treasury = int(treasury)
                other_manpower = int(manpower)
                other_focus = focus
            elif country != player and country != othercountry:
                updatelist.append(f"{country} {treasury} {GDP} {military} {manpower} {population} {focus}")
        for item in Offer_list:
            if item == "Invite To Faction": #checks if any country is already in a faction, if not the other country is added to your faction
                for item in factioninfo:
                    factionname, factionmembers = item.split()
                    factionmemberlist = factionmembers.split('|')
                    if other_country in factionmemberlist:
                        return False, "Country In Faction."
                    elif player in factionmemberlist:
                        factionmemberlist.append(other_country)
                    factionupdatelist.append(f"{factionname} {'|'.join(factionmemberlist)}")
            if item == "Kick From Faction": #checks if other country is not in a faction. If they are and you are in it, they are removed
                for item in factioninfo:
                    factionname, factionmembers = item.split()
                    factionmemberlist = factionmembers.split('|')
                    if player in factionmemberlist and other_country not in factionmemberlist:
                        return False, "Not In Faction"
                    elif player in factionmemberlist and other_country in factionmemberlist:
                        factionmemberlist.remove(other_country)
                    factionupdatelist.append(f"{factionname} {'|'.join(factionmemberlist)}")    
            if item == "Offer Payment": #checks if you have enough money to offer then transfers it
                if offermoney > player_treasury:
                    return False, "Not Enough Money"
                else:
                    player_treasury -= offermoney
                    other_treasury += offermoney
            if item == "Offer Manpower": #checks if you have enough manpower to offer than transfers it
                if offermanpower > player_manpower:
                    return False, "Not Enough Manpower"
                else:
                    new_player_manpower -= offermanpower
                    new_other_manpower +=  offermanpower
            if item == "Offer City": #Checks if you have enough cities to offer then transfers it
                citycount = 0
                for item in Cities:
                    items = item.split()
                    if items[3] == player:
                        citycount += 1
                if citycount == 1:
                    return False, "Not enough cities."
            if item == "Create Puppet": #adds them to your faction and transfers 20% of their GDP and 20% of their manpower to you
                for item in factioninfo:
                    factions, factionmembers = item.split()
                    factionmemberslist = factionmembers.split('|')
                    if othercountry in factionmemberslist:
                        return False, "In Faction"
                for item in factioninfo:
                    factions, factionmembers = item.split()
                    factionmemberslist = factionmembers.split('|')
                    if player in factionmemberslist:
                        factionmemberslist.append(othercountry)
                        factionmembers = '|'.join(factionmemberslist)
                    factionupdatelist.append(f"{factions} {factionmembers}")
                GDPmodifier = other_GDP*0.2
                manpowermodifier = other_manpower*0.2
                eventupdatelist.append(f"{player} has puppeted {othercountry}")
        Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
        for item in Demand_list: #Checks for demands
            if item == "Request to Join Faction": #checks if any country is already in a faction, if not you are added to theirs
                player = 'Latvia'
                for item in factioninfo:
                    factionname, factionmembers = item.split()
                    factionmemberlist = factionmembers.split('|')
                    if player in factionmemberlist:
                        return False, 'Already in faction'
                    elif other_country in factionmemberlist and player in factionmemberlist:
                        return False, 'In Same Faction'
                    elif other_country in factionmemberlist and player not in factionmemberlist:
                        factionmemberlist.append(player)
                        
                    factionupdatelist.append(f"{factionname} {'|'.join(factionmemberlist)}")
            if item == "Request Payment": #checks if they have enough money then transfers it
                if demandmoney > other_treasury:
                    return False, "Country Lacks Money"
                else:
                    player_treasury += demandmoney
                    other_treasury -= demandmoney
            if item == "Request City": #checks if they have enough cities then transfers them
                demandcityupdatelist = []
                othercountrycitycount = 0
                for item in Cities:
                    items = item.split()
                    if items[0] in citydemandlist:
                        newcitieslist.append(items[0])
                    if items[3] == othercountry:
                        othercountrycitycount += 1
                if othercountrycitycount == 1:
                    return False, "Not enough cities."
            if item == "Request Manpower": #checks if they have enough manpower then transfers it
                if demandmanpower > other_manpower:
                    return False, "Country Lacks Manpower"
                else:
                    new_player_manpower += demandmanpower
                    new_other_manpower -= demandmanpower
            ran = 0
            if item == "Request War Support": #Checks if you are at war then adds them to the war
                warnations = []
                warwritelist = []
                for waritem in warfile:
                    basecountry, atwar = waritem.split()
                    if basecountry == player:
                        if atwar == 'none':
                            return False, 'Not At War'
                        playeratwarlist = atwar.split('|')
                        for item in playeratwarlist:
                            warnations.append(item)
                        warwritelist.append(f"{basecountry} {atwar}")
                    elif basecountry == other_country:
                        otheratwarlist = atwar.split('|')
                        if 'none' in otheratwarlist:
                            otheratwarlist.remove('none')
                    else:
                        warwritelist.append(waritem)
                for item in warnations:
                    if item not in otheratwarlist:
                        otheratwarlist.append(item)
                    for waritem in warwritelist:
                        basecountry, atwar = waritem.split()
                        if item == basecountry:
                            ran +=1
                            if ran != 2:
                                atwarlist = atwar.split('|')
                                if other_country not in atwarlist:
                                    atwarlist.append(other_country)
                                if 'none' in atwarlist:
                                    atwarlist.remove('none')
                                warwritelist.append(f"{basecountry} {'|'.join(atwarlist)}")
                                warwritelist.remove(waritem)
                    ran = 0
                            
                            
                warwritelist.append(f"{other_country} {'|'.join(otheratwarlist)}")
                warwritefile = open('TextFiles\CountryWarFile.txt', 'w')
                warwritefile.write('\n'.join(warwritelist))
                                  
            if item == "Request Peace": #checks you are at war with each other then ends the war
                finalwritelist = []
                for waritem in warfile:
                    basecountry, atwar = waritem.split()
                    if basecountry == player_country:
                        playeratwarlist = atwar.split('|')
                    if basecountry == othercountry:
                        otheratwarlist = atwar.split('|')
                    elif basecountry != player_country and basecountry != othercountry:
                        finalwritelist.append(waritem)
                            
                if othercountry not in playeratwarlist:
                    return False, "Not At War"
                else:
                    playeratwarlist.remove(othercountry)
                    otheratwarlist.remove(player)
                    if len(playeratwarlist) == 0:
                        playeratwarlist.append('none')
                    if len(otheratwarlist) == 0:
                        otheratwarlist.append('none')
                    finalwritelist.append(f"{player} {'|'.join(playeratwarlist)}")
                    finalwritelist.append(f"{othercountry} {'|'.join(otheratwarlist)}")
                warfile = open('TextFiles\CountryWarFile.txt', 'w')
                warfile.write('\n'.join(finalwritelist))
                eventupdatelist.append(f"{player} has made peace with {othercountry}")
                

        #pretty much just implementing any changes that have been made
        updatelist.append(f"{player_country} {player_treasury} {player_GDP} {player_military} {player_manpower} {player_population} {player_focus}")
        updatelist.append(f"{other_country} {other_treasury} {other_GDP} {other_military} {other_manpower} {other_population} {other_focus}")
        writefile = open('TextFiles\Countries.txt', 'w')
        writefile.write('\n'.join(updatelist))

        playercitycount = 0
        othercountrycitycount = 0
        cityupdatelist = []
        Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
        for item in Cities:
            city, x, y, country, city_income, city_manpower, city_population, barracks, factory, market, fort, citytype = item.split()
            if country != player and country != other_country:
                cityupdatelist.append(f'{city} {x} {y} {country} {city_income} {city_manpower} {population} {barracks} {factory} {market} {fort} {citytype}')
            if country == player:
                playercitycount += 1
            elif country == other_country:
                othercountrycitycount += 1
        playerGDPmodifier = int(round(GDPmodifier/playercitycount, 0))
        playermanpowermodifier = int(round(manpowermodifier/playercitycount, 0))
        otherGDPmodifier = int(round(GDPmodifier/othercountrycitycount, 0))
        othermanpowermodifier = int(round(manpowermodifier/othercountrycitycount, 0))

        for item in Cities:
            city, x, y, country, city_income, city_manpower, city_population, barracks, factory, market, fort, citytype = item.split()
            city_income, city_manpower = int(city_income), int(city_manpower)
            if country == player:
                if city in cityofferlist:
                    country = othercountry
                cityupdatelist.append(f'{city} {x} {y} {country} {city_income + playerGDPmodifier} {int(int(city_manpower+playermanpowermodifier) + (new_player_manpower/playercitycount))} {city_population} {barracks} {factory} {market} {fort} {citytype}')
            elif country == othercountry:
                if city in newcitieslist:
                    country = player
                cityupdatelist.append(f'{city} {x} {y} {country} {city_income-otherGDPmodifier} {int(int(city_manpower-othermanpowermodifier) + (new_other_manpower/othercountrycitycount))} {city_population} {barracks} {factory} {market} {fort} {citytype}')
        Citywrite = open('TextFiles\CityNames.txt', 'w')
        Citywrite.write('\n'.join(cityupdatelist))

        if len(factionupdatelist) != 0:
            with open('TextFiles\Factions.txt', 'w') as file:
                file.write('\n'.join(factionupdatelist))

        if len(eventupdatelist) != 0:
            with open('TextFiles\WorldEvents.txt', 'w') as file:
                file.write('\n'.join(eventupdatelist))
        return True, 'none'
    def DiplomacyValueCalculator(Offer_list, Demand_list, player, othercountry, offermoney, offermanpower, demandmoney, demandmanpower, citydemandlist, cityofferlist): #calculates the value of each diplomatic deal
        CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
        Citysavefile = ((open('TextFiles\CityUnchanged.txt', 'r')).read()).split('\n')
        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
        warfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
        factioninfo = ((open('TextFiles\Factions.txt', 'r')).read()).split('\n')
        diplomacyvalue = 0
        for item in Offer_list:
            if item == "Invite To Faction": #accounts for current wars then produces a value
                for item in warfile:
                    basecountry, warlist = item.split()
                    if basecountry == player:
                        playerwarlist = warlist.split()
                    if basecountry == othercountry:
                        enemywarlist = warlist.split()
                for item in playerwarlist:
                    if playerwarlist == 'none' and enemywarlist == 'none':
                        diplomacyvaluechanger = 100
                    elif item not in enemywarlist:
                        diplomacyvaluechanger = 900
                    else:
                        diplomacyvaluechanger = 100
                diplomacyvalue -= diplomacyvaluechanger
                for item in enemywarlist:
                    if playerwarlist == 'none' and enemywarlist == 'none':
                        pass
                    elif item not in playerwarlist:
                        diplomacyvaluechanger = 50
                diplomacyvalue += diplomacyvaluechanger
                diplomacyvalue -= 200
                    
            if item == "Kick From Faction":  #does not require a value
               diplomacyvalue += 0
            if item == "Offer Payment": #calculates the value of the money offered relative to the amount in their treasury
                for item in CountryData:
                    country, treasury, GDP, military, manpower, population, focus = item.split()
                    if country == othercountry:
                        if offermoney/int(treasury) <= 1:
                            diplomacyvalue += 100 * (offermoney/int(treasury))
                        else: #max of 100 score
                            diplomacyvalue += 100
            if item == "Offer Manpower":
                for item in CountryData: #calculates value of manpower offered relative to the manpower in their reserves
                    country, treasury, GDP, military, manpower, population, focus = item.split()
                    if country == othercountry:
                        if offermanpower/int(manpower) <= 1:
                            diplomacyvalue += 300 * offermanpower/int(manpower)
                        else: #max of 100 score
                            diplomacyvalue += 100
            if item == "Offer City": #checks the value of the city you're offering includes income, manpower and building sizes
                value = 0
                for item in Cities:
                    city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
                    if city in cityofferlist:
                        levels = ['small', 'medium', 'large']
                        value += int(city_income)/1000 + int(city_manpower)/50000
                        value += 4*(levels.index(barracks)+1)
                        value += 4*(levels.index(factory)+1)
                        value += 4*(levels.index(market)+1)
                        value += 4*(levels.index(fort)+1)
                value *= 2.5
                diplomacyvalue += value

            if item == "Create Puppet": #checks the strength of your nation compared to theirs
                cant_puppet = ['Germany', 'France', 'SovietUnion', 'UK']
                for item in CountryData:
                    country, treasury, GDP, military, manpower, population, focus = item.split()
                    if country == othercountry: #checks your GDP compared to theirs
                        othercountryvalue = int(GDP)/1000 + int(military)/10000
                    if country == player_country:
                        playercountryvalue = int(GDP)/1000 + int(military)/10000
                valueadder = playercountryvalue-othercountryvalue-800
                citycounter = 0
                savecitycounter = 0
                for item in Cities: #checks the number of cities you have compared to them
                    items = item.split()
                    if items[3] == othercountry:
                        citycounter += 1
                for item in Citysavefile:
                    items = item.split()
                    if items[3] == othercountry:
                        savecitycounter += 1
                if savecitycounter *0.2 >= citycounter:
                    valueadder += 450
                if othercountry in cant_puppet: #stops you from puppeting Majors
                    valueadder -= 9999999999
                diplomacyvalue += valueadder
        
        for item in Demand_list:
            if item == "Request to Join Faction":  #checks the people in each of your war lists and determines whether you are accepted or not
                for item in warfile:
                    basecountry, warlist = item.split()
                    if basecountry == player:
                        playerwarlist = warlist.split()
                    if basecountry == othercountry:
                        enemywarlist = warlist.split()
                for item in playerwarlist:
                    if playerwarlist == 'none' and enemywarlist == 'none':
                        diplomacyvaluechanger = 100
                    elif item not in enemywarlist:
                        diplomacyvaluechanger = 900
                    else:
                        diplomacyvaluechanger = 100
                diplomacyvalue -= diplomacyvaluechanger
                for item in enemywarlist:
                    if playerwarlist == 'none' and enemywarlist == 'none':
                        pass
                    elif item not in playerwarlist:
                        diplomacyvaluechanger = 50
                diplomacyvalue += diplomacyvaluechanger
            if item == "Request Payment": #determines value of requested money compared to their treasury size
                 for item in CountryData:
                    country, treasury, GDP, military, manpower, population, focus = item.split()
                    if country == othercountry:
                        if demandmoney/int(treasury) <= 1:
                            diplomacyvalue -= 100 * (demandmoney/int(treasury))
                        else:
                            diplomacyvalue -= 9999999
            if item == "Request City": #determines value of cities you have requested
                value = 0
                for item in Cities: 
                    city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
                    if city in citydemandlist:
                        levels = ['small', 'medium', 'large']
                        value += int(city_income)/1000 + int(city_manpower)/50000
                        value += 4*(levels.index(barracks)+1)
                        value += 4*(levels.index(factory)+1)
                        value += 4*(levels.index(market)+1)
                        value += 4*(levels.index(fort)+1)
                value *= 2.5
                diplomacyvalue -= value
            if item == "Request Manpower": #determines value of manpower requested compared to your manpower pool
               for item in CountryData:
                    country, treasury, GDP, military, manpower, population, focus = item.split()
                    if country == othercountry:
                        if demandmanpower/int(manpower) <= 1:
                            diplomacyvalue -= 300 * demandmanpower/int(manpower)
                        else:
                            diplomacyvalue -= 9999999
            if item == "Request War Support": #determines who you are at war with and how strong you are compared to them
                countryvalue = 0
                for item in warfile:
                    basecountry, warlist = item.split()
                    if basecountry == player:
                        playerwarnations = warlist.split('|')
                    if basecountry == othercountry:
                        otherwarnations = warlist.split('|')
                for item in playerwarnations:
                    if item not in otherwarnations:
                        for countryitem in CountryData:
                            country, treasury, GDP, military, manpower, population, focus = countryitem.split()
                            if item == country:
                                countryvalue += int(military)/10000 + int(GDP)/1000
                                countryvalue += 100
                diplomacyvalue -= countryvalue
            if item == "Request Peace": #determines your strength compared to that of the other country
                basevalue = -500
                for item in CountryData:
                    country, treasury, GDP, military, manpower, population, focus = item.split()
                    if country == player: #treasury/military compared to other country
                        playerwarcountryvalue = int(treasury)/10000 + int(military)/100000
                    if country == othercountry:
                        enemywarcountryvalue = int(treasury)/10000 + int(military)/100000
                basevalue += (playerwarcountryvalue-enemywarcountryvalue)
                currentcities = []
                citycounter = 0
                savecitycounter = 0
                for item in Cities: #number of cities they control
                    items = item.split()
                    if items[3] == othercountry:
                        currentcities.append(items[0])
                        citycounter += 1
                for item in Citysavefile: #checks if they control their capital and how many cities they have
                    items = item.split()
                    if items[3] == othercountry:
                        savecitycounter += 1
                        if items[11] == 't':
                            capital = items[0]
                if capital not in currentcities: #pretty much the UK just never surrendering lol, otherwise losing their capital significantly sways them towards making peace
                    if othercountry != 'UK' and othercountry != 'SovietUnion':
                        basevalue += 250
                if othercountry == 'SovietUnion' or 'UK':
                    basevalue -= 300
                basevalue += 100/((citycounter/savecitycounter))#number of starting cities vs number of cities currently controlled
                diplomacyvalue += basevalue
        return diplomacyvalue #returns final value to original function
    def WarDeclaration(original_country, selectedcountry): #Declares war on other country   
        canWar = True
        countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
        factioninfo = ((open('TextFiles\Factions.txt', 'r')).read()).split('\n')
        Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
        UKcapitalcontrolcheck = False
        Sovietcapitalcontrolcheck = False
        Francecapitalcontrolcheck = False
        finalwritelist = []
        friendlyfactionmembers = []
        enemyfactionmembers = []
        UKguaranteedlist = ['Afhganistan', 'Belgium', 'Cyprus', 'Denmark', 'Greece', 'Ireland', 'Luxembourg', 'Netherlands', 'Norway', 'Portugal', 'Poland', 'Turkey']
        SOVguaranteedlist = ['Latvia', 'Lithuania', 'Estonia']
        for cityitem in Cities:
            cityitems = cityitem.split()
            if cityitems[11] == 't' and cityitems[3] == 'UK':
                UKcapitalcontrolcheck = True
            if cityitems[11] == 't' and cityitems[3] == 'SovietUnion':
                Sovietcapitalcontrolcheck = True
            if cityitems[11] == 't' and cityitems[3] == 'France':
                Francecapitalcontrolcheck = True
        for line in factioninfo: #checks the faction of both countries
            factioname, factionmembersbase = line.split()
            factionmembers = factionmembersbase.split('|')
            if original_country in factionmembers and selectedcountry in factionmembers:
                canWar = False
            elif original_country in factionmembers:
                friendlyfactionmembers = factionmembers
            elif selectedcountry in factionmembers:
                enemyfactionmembers = factionmembers
        if len(friendlyfactionmembers) == 0:
            friendlyfactionmembers = [original_country]
        if len(enemyfactionmembers) == 0:
            enemyfactionmembers = [selectedcountry]
        if selectedcountry in UKguaranteedlist and player_country != 'UK' and player_country != 'France':
            if UKcapitalcontrolcheck:
                enemyfactionmembers.append('UK')
            if Francecapitalcontrolcheck:
                enemyfactionmembers.append('France')
        if selectedcountry in SOVguaranteedlist and player_country != 'SovietUnion':
            if Sovietcapitalcontrolcheck:
                enemyfactionmembers.append('SovietUnion')
        if canWar == True: #all faction members go to war with each other
            for line in countrywarfile:
                basecountry, atwar = line.split()
                atwarlist = atwar.split()
                if basecountry in friendlyfactionmembers:
                    for item in enemyfactionmembers:
                        if item not in atwarlist:
                            atwarlist.append(item)
                            if 'none' in atwarlist:
                                atwarlist.remove('none')
                    finalwritelist.append(f"{basecountry} {'|'.join(atwarlist)}")
                elif basecountry in enemyfactionmembers:
                    for item in friendlyfactionmembers:
                        if item not in atwarlist:
                            atwarlist.append(item)
                            if 'none' in atwarlist:
                                atwarlist.remove('none')
                    finalwritelist.append(f"{basecountry} {'|'.join(atwarlist)}")
                else:
                    finalwritelist.append(line)
            countrywritefile = open('TextFiles\CountryWarFile.txt', 'w')
            countrywritefile.write('\n'.join(finalwritelist))
            worldeventfile = ((open('TextFiles\WorldEvents.txt', 'r')).read()).split('\n')
            finalfriendly = ', '.join(friendlyfactionmembers)
            finalenemy = ', '.join(enemyfactionmembers)
            if len(friendlyfactionmembers) == 0:
                finalfriendly = original_country
            if len(enemyfactionmembers) == 0:
                finalenemy = selectedcountry
            eventupdatelist = []
            for item in worldeventfile: #updates world events file
                eventupdatelist.append(''.join(item))
            eventupdatelist.append(f"{finalfriendly} declares war on {finalenemy}")
            with open('TextFiles\WorldEvents.txt', 'w') as file:
                file.write('\n'.join(eventupdatelist))
            return canWar

    def SiegeCalculations(enemy, player, siegecity, playerarmyname, attackedarmyname, CityFile): #Calculates score and casualties for sieges and battles + updates files accordingly
        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
        Cities = ((open('TextFiles\CityNames.txt', 'r')).read()).split('\n')
        CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        if CityFile != 'none':
            Cities = CityFile
        playercasualties = 0
        enemycasualties = 0
        playersiegescore = 0 
        enemysiegescore = 0
        playerarmytotalsize = 0
        enemyarmytotalsize = 0
        armyupdater = []
        playerattackbonus = 1
        enemydefencebonus = 1
        siegecasualtymodifier = 1
        if siegecity != 'NoCity': #applies defense bonus if it's a siege
            siegecasualtymodifier = 3
            enemysiegescore += 500
        for item in CountryData: #checks focus for defence/attack buffs
            items = item.split()
            if items[0] == enemy:
                if items[-1] == 'Defense':
                    enemydefencebonus = 1.10
            if items[0] == player:
                if items[-1] == 'Planes':
                    playerattackbonus = 1.10
        if player == 'Germany' and Month < 20:
            playerattackbonus += 2
        if enemy == 'Germany' and Month < 20:
            enemydefencebonus += 1.5
        if player == 'SovietUnion' and enemy == 'Finland':
            enemydefencebonus += 2
        if player == 'Germany' and enemy == 'UK' and Month > 10:
            enemydefencebonus += 0.3
        if player == 'Germany' and enemy == 'SovietUnion':
            enemydefencebonus += 1.5

        for armyitem in armyinfo: #checking who won the battle
            country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = armyitem.split()
            armysize = int(armysize)
            maxsize = int(maxsize)

            #Score Calculations
            if country == player and stationed == siegecity: #calculating player score for sieges
                siegescoreadder = int(InfantryDivNo) *150 + int(ArmoredDivNo)*500 + int(MechanizedDivNo)*320 
                playerarmytotalsize += armysize
                armysizemodifier = armysize/maxsize
                playersiegescore += siegescoreadder*armysizemodifier*playerattackbonus
            if country == enemy and stationed == siegecity:#calculating enemy score for sieges
                siegescoreadder = int(InfantryDivNo) *350 + int(ArmoredDivNo)*80 + int(MechanizedDivNo)*190
                armysizemodifier = armysize/maxsize
                enemyarmytotalsize += armysize
                enemysiegescore += siegescoreadder*armysizemodifier*enemydefencebonus
            elif country == player and Name == playerarmyname: #calculating player score for battles
                siegescoreadder = int(InfantryDivNo) *200 + int(ArmoredDivNo)*250 + int(MechanizedDivNo)*220
                armysizemodifier = armysize/maxsize
                playerarmytotalsize += armysize
                playersiegescore += siegescoreadder*armysizemodifier*playerattackbonus
            elif country == enemy and Name == attackedarmyname: #calculating enemy score for battles
                siegescoreadder = int(InfantryDivNo) *200 + int(ArmoredDivNo)*250 + int(MechanizedDivNo)*220
                armysizemodifier = armysize/maxsize
                enemyarmytotalsize += armysize
                enemysiegescore += siegescoreadder*armysizemodifier*enemydefencebonus

        if playersiegescore == 0:
            return enemy, 0, 0, 0, 0
        if playerarmytotalsize >= enemyarmytotalsize: #checking the size of both armies compared to each other to apply a bonus to the larger army
            playersiegescore += (playerarmytotalsize-enemyarmytotalsize)*0.01
        else:
            enemysiegescore += (enemyarmytotalsize-playerarmytotalsize)*0.01

        for item in Cities: #applies bonus for forts
            items = item.split()
            if items[0] == siegecity:
                if items[10] == 'large':
                    enemysiegescore *= 1.15
                if items[10] == 'medium':
                    enemysiegescore *= 1.1
                if items[10]== 'small':
                    enemysiegescore *= 1.05
        playercasualtymodifier = 11
        enemycasualtymodifier = 11
        if siegecity != 'NoCity': #casaulaties modified depending on winner, victor determined
            if enemysiegescore >= playersiegescore:
                enemycasualtymodifier = 3
                playercasualtymodifier = 12
                victor = enemy
                loser = player
            else:
                playercasualtymodifier = 5
                enemycasualtymodifier = 10
                victor = player
                loser = enemy
        else:
            if enemysiegescore >= playersiegescore:
                enemycasualtymodifier = 4
                victor = attackedarmyname
                loser = playerarmyname
            else:
                playercasualtymodifier = 4
                victor = playerarmyname
                loser = attackedarmyname
        casualtycalculator = 0
        for armyitem in armyinfo: #applying casualties
            country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = armyitem.split()
            armysize = int(armysize)
            maxsize = int(maxsize)
            if country == player and stationed == siegecity:
                startplayerarmysize = armysize
                casualtycalculator = random.randint(100-(2*playercasualtymodifier),100-(2*(playercasualtymodifier-3)))
                armysize -= (maxsize- (maxsize * casualtycalculator/100))*siegecasualtymodifier
                playercasualties += startplayerarmysize - armysize
                if armysize <= 0:
                    playercasualties = startplayerarmysize
            if country == enemy and stationed == siegecity:
                startenemyarmysize = armysize
                casualtycalculator = random.randint(100-(1*enemycasualtymodifier),100-(1*(enemycasualtymodifier-3)))
                armysize -= (maxsize- (maxsize * casualtycalculator/100))
                enemycasualties += startenemyarmysize - armysize
            elif country == player and Name == playerarmyname:
                startplayerarmysize = armysize
                casualtycalculator = random.randint(100-(2*playercasualtymodifier),100-(2*(playercasualtymodifier-3)))
                armysize -= (maxsize- (maxsize * casualtycalculator/100))
                playercasualties += startplayerarmysize - armysize
                if armysize <= 0:
                    playercasualties = startplayerarmysize
            elif country == enemy and Name == attackedarmyname: 
                startenemyarmysize = armysize
                casualtycalculator = random.randint(100-(2*enemycasualtymodifier),100-(2*(enemycasualtymodifier-3)))
                armysize -= (maxsize- (maxsize* casualtycalculator/100))
                enemycasualties += startenemyarmysize - armysize
                if armysize <= 0:
                    enemycasualties = startenemyarmysize
            if armysize > 0:
                armyupdater.append(f"{country} {x} {y} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {Name} {stationed} {siegestatus} {int(round(armysize,0))} {maxsize} {traintime}")
        with open('ArmyInfo\ArmyLocation.txt', 'w') as file:
            file.write('\n'.join(armyupdater))
        worldeventfile = ((open('TextFiles\WorldEvents.txt', 'r')).read()).split('\n')
        eventupdatelist = []
        for item in worldeventfile: #adding to world events
            eventupdatelist.append(''.join(item))
        if siegecity != 'NoCity':
            eventupdatelist.append(f"{victor} defeated {loser} at {siegecity}")
        else:
            eventupdatelist.append(f"{victor} defeated {loser}")
        with open('TextFiles\WorldEvents.txt', 'w') as file:
            file.write('\n'.join(eventupdatelist))
        with open("TextFiles\CasualtyFile.txt", 'a') as file: #returning values
            file.write(f"{player} {int(round(playercasualties, 0))} {int(round(enemycasualties, 0))}\n")
            file.write(f"{enemy} {int(round(enemycasualties, 0))} {int(round(playercasualties, 0))}\n")
        if enemysiegescore >= playersiegescore:
            return enemy, str(int(round(playersiegescore,0))), str(int(round(enemysiegescore,0))), str(int(round(playercasualties,0))), str(int(round(enemycasualties,0)))
        else:
            return player, str(int(round(playersiegescore,0))), str(int(round(enemysiegescore,0))), str(int(round(playercasualties,0))), str(int(round(enemycasualties,0)))
    def HistoricalAlliances(Month): #if the game is in historical mode, countries declare war on each other like they actually did
        if Month == 2 and player_country != 'Germany': #in Month 2 Germany declares war on Poland and the Allies join against them
            with open('TextFiles\WorldEvents.txt', 'w') as file:
                file.write('Germany has declared war on Poland.')
            countrywritefile = []
            countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split("\n")
            for item in countrywarfile:
                basecountry, warlist = item.split()
                if basecountry == 'UK' or basecountry == 'France' or basecountry == 'Poland' or basecountry == 'Oman':
                    if warlist == 'none':
                        alliedatwarlist = ['Germany', 'Italy']
                    else:
                        alliedatwarlist = warlist.split('|')
                        alliedatwarlist.extend(['Germany', 'Italy'])
                    countrywritefile.append(f"{basecountry} {'|'.join(alliedatwarlist)}")
                elif basecountry == 'Germany' or basecountry == 'Italy':
                    if warlist == 'none':
                        axisatwarlist = ['UK', 'France', 'Poland', 'Oman']
                    else:
                        axisatwarlist = warlist.split('|')
                        axisatwarlist.extend(['UK', 'France', 'Poland', 'Oman'])
                    countrywritefile.append(f"{basecountry} {'|'.join(axisatwarlist)}")
                else:
                    countrywritefile.append(f"{basecountry} {warlist}")
            with open('TextFiles\CountryWarFile.txt', 'w') as file:
                file.write('\n'.join(countrywritefile))
            Factionsfile = ((open('TextFiles\Factions.txt', 'r')).read()).split("\n")
            Factionswritefile = []
            for item in Factionsfile:
                Faction, members = item.split()
                if Faction == 'Allies':
                    memberslist = members.split('|')
                    if 'Poland' not in memberslist:
                        memberslist.append('Poland')
                    Factionswritefile.append(f"{Faction} {'|'.join(memberslist)}")
                else:
                    Factionswritefile.append(f"{Faction} {members}")
            with open('TextFiles\Factions.txt', 'w') as file:
                file.write('\n'.join(Factionswritefile))
        if Month == 8: #In Month 8 the other allied countries join the war (not fully historical)
           allylist = ['Poland', 'Belgium', 'Luxembourg', 'Netherlands', 'Norway', 'Greece', 'Yugoslavia' ]
           HistoryWarDeclare(allylist, 'Allies', 'Axis')
            

        if Month == 13: #In month 13 the other axis countris join the war (not fully historical)
            axislist = ['Hungary', 'Slovakia', 'Bulgaria', 'Romania', 'Finland']
            HistoryWarDeclare(axislist, 'Axis', 'Allies')
        
        if Month == 25:#In month 25 the Germans declare war on the Soviets
            sovietlist = ['Latvia', 'Lithuania', 'Estonia', 'SovietUnion']
            HistoryWarDeclare(sovietlist, 'Comintern', 'Axis')
    def HistoryWarDeclare(list, warstarters, defenders): #just a simplification of the war declaration function so that it doesn't have to be repeated
        countryfile = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        memberslist = []
        allymemberslist = []
        for item in countryfile:
            items = item.split()
            if items[0] == 'Germany' and int(items[2]) >= 5 and int(items[3]) >= 2000000: #If Germany still maintains most of their strength, the countries will join the war
                Factionsfile = ((open('TextFiles\Factions.txt', 'r')).read()).split("\n")
                Factionswritefile = []
                for item in Factionsfile:
                    Faction, members = item.split()
                    if Faction == warstarters:
                        memberslist = members.split('|')
                        for memberitem in memberslist:
                            if memberitem in list:
                                memberslist.remove(memberitem)
                        memberslist.extend(list)
                        Factionswritefile.append(f"{Faction} {'|'.join(memberslist)}")
                    if Faction == defenders:
                        allymemberslist = members.split('|')
                        Factionswritefile.append(f"{Faction} {'|'.join(allymemberslist)}")
                    elif Faction != warstarters and Faction != defenders:
                        Factionswritefile.append(f"{Faction} {members}")
                with open('TextFiles\Factions.txt', 'w') as file:
                    file.write('\n'.join(Factionswritefile))
        countrywritefile = []
        countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split("\n")
        for item in countrywarfile:
            basecountry, warlist = item.split()
            atwarlist = warlist.split('|')
            if basecountry in memberslist:
                for memberitem in allymemberslist:
                    if memberitem not in atwarlist:
                        atwarlist.append(memberitem)
                if 'none' in atwarlist:
                    atwarlist.remove('none')
            elif basecountry in allymemberslist:
                for memberitem in memberslist:
                    if memberitem not in atwarlist:
                        atwarlist.append(memberitem)
                if 'none' in atwarlist:
                    atwarlist.remove('none')
            countrywritefile.append(f"{basecountry} {'|'.join(atwarlist)}")
        with open('TextFiles\CountryWarFile.txt', 'w') as file:
            file.write('\n'.join(countrywritefile))
        with open('TextFiles\WorldEvents.txt', 'w') as file:
            file.write(f"{', '.join(memberslist)} have declared war on {', '.join(allymemberslist)}.")
      
class TroopMovements(): #Controls player army movements
    global TroopLocationAssigner, ViewDivisionMakeup, TroopArmyDisplayer, MovementCalculator,  checkformovement, checkformove, cantMove, checkifoncity, siegechecker, checkforsiege, checkifonarmy, battle, conflict_display_screen, Display_conflict_stats, stats_click_time
    ViewDivisionMakeup = False #flag for when you click on a division
    can_move = False #if you click on a division you can move
    checkformovement = False #checks if you've moved
    cantMove = False #displays if you can't move
    checkforsiege = False
    battle = False
    conflict_display_screen = 'none'
    Display_conflict_stats = False
    stats_click_time = 0
    def TroopLocationAssigner(): #assigns the position of armies and controls division makeup screen and conflict display screen
        global InfantryDivNo, ArmoredDivNo, MechanizedDivNo, TroopSelectPosx, TroopSelectPosy, can_move, checkformovement, CanMove, armyinfo, cantMove, SelectedArmyName,SelectedMaxArmySize, SelectedArmorSize, SelectedInfantrySize, SelectedMechSize, checkforsiege, atwarlist, conflict_display_screen, SelectedArmySize, Display_conflict_stats, stats_click_time
        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
        FactionInfo = ((open('TextFiles\Factions.txt', 'r')).read()).split("\n")
        blank_colour = (128, 128, 128)#colour for neutral nation cities
        Enemy_colour = (255, 0, 0) #colour for enemy nation cities
        Selected_colour = (0,191,255) #colour for the city you are hovering over
        Home_colour = (124,252,0) #colour for cities owned by you
        Ally_colour = (229, 237, 69) #colour for friends
        Background_colour = (255,253,208)
        border_colour = (92, 64,52)
        customise = 0
        
        
        mouse = pygame.mouse.get_pos()
        countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
        atwarlist = []
        for waritem in countrywarfile: #checks which armies you're at war with
            basecountry, atwar = waritem.split()
            if basecountry == player_country:
                atwarlist = atwar.split('|')
        for allianceitem in FactionInfo: #checks which armies belong to allies
            alliancename, allies = allianceitem.split()
            allieslist = allies.split('|')
            if player_country in allieslist:
                listofallies = allieslist
        for item in armyinfo: #for item in the list of Capitals and Cities
            global ViewDivisionMakeup, x, y, SelectedArmyX,SelectedArmyY
            if item != '':
                country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = item.split() #assigning variable names to all data
                for atwarlistitem in atwarlist:
                    if atwarlistitem == country:
                        customise = 2
                for ally in listofallies:
                    if ally == country and country != player_country:
                        customise = 1
                x = int(x)
                y = int(y)
                InfantryDivNo = int(InfantryDivNo)
                ArmoredDivNo = int(ArmoredDivNo)
                MechanizedDivNo = int(MechanizedDivNo) #converting to integers
                if country == player_country:
                    pygame.draw.polygon(screen, Home_colour, ((x,y+12), (x-6,y+2), (x+6, y+2)))#colour of your own city
                    if x-10 <= mouse[0] <= x+2 and y-2 <= mouse[1] <= y+12:
                        pygame.draw.polygon(screen, Selected_colour, ((x,y+13), (x-7,y+2), (x+7, y+2))) #change colour and size if hovered over
                        pygame.draw.polygon(screen, (0,0,0), ((x,y+13), (x-7,y+2), (x+7, y+2)), 3) #border
                        #checking for events
                        able_to_click = True
                        if pygame.mouse.get_pressed()[0] and able_to_click == True: #if you click on the division
                            pygame.mixer.music.set_volume(0.01)
                            music(1)
                            ViewDivisionMakeup = True
                            SelectedArmyName = Name
                            SelectedArmySize = armysize
                            SelectedMaxArmySize = maxsize
                            SelectedInfantrySize = InfantryDivNo
                            SelectedArmorSize = ArmoredDivNo
                            SelectedMechSize = MechanizedDivNo
                            SelectedArmyX, SelectedArmyY = int(x),int(y)
                            able_to_click = False
                            checkformovement = True
                elif customise == 1:
                    pygame.draw.polygon(screen, Ally_colour, ((x,y+12), (x-6,y+2), (x+6, y+2)))
                elif customise == 0: #drawing stuff
                    pygame.draw.polygon(screen, blank_colour, ((x,y+12), (x-6,y+2), (x+6, y+2)))#standard colour
                else:
                    pygame.draw.polygon(screen, Enemy_colour, ((x,y+12), (x-6,y+2), (x+6, y+2))) #colour of enemy city (at war)
                pygame.draw.polygon(screen, (0,0,0), ((x,y+13), (x-7,y+2), (x+6, y+2)), 2)
                #checking if you're hovering over a city
            if checkformovement == True and pygame.mouse.get_pressed()[-1]:
                checkformove(SelectedArmyName, SelectedArmyX, SelectedArmyY)
                    
            if cantMove == True:
                x, y = SelectedArmyX, SelectedArmyY
                pygame.draw.rect(screen,Background_colour,[x-20, y-20, 70, 17]) #background
                pygame.draw.rect(screen,border_colour,[x-20, y-20, 70, 17],2) #border
                custom_text("Can't Move", 10, 255, 12, 12, x+15, y-13)
                if pygame.mouse.get_pressed()[0]:
                    pygame.mixer.music.set_volume(0.01)
                    music(1)
                    cantMove = False
            customise = 0
        if checkforsiege == True: #If you haved moved to attack an army or a city
            if battle == True:
                battletype = 'battle'
            if battle == False:
                battletype = 'siege'
            if siegechecker(battletype) == True: #Checks if you clicked yes for siege or no for siege/battle
                checkforsiege = False
                ViewDivisionMakeup = False
            elif siegechecker(battletype) == False:
                checkforsiege = False
                ViewDivisionMakeup = False
                checkformovement = False
        if conflict_display_screen != 'none': #Screen after a conflict that gives you stats
            global click_time
            pygame.draw.rect(screen,Background_colour,[500, 0, 200, 60]) #background
            pygame.draw.rect(screen,border_colour,[500, 0, 200, 60],5) #border
            custom_text(conflict_display_screen, 23, 0,0,0, 600, 30)
            textbutton((173, 216, 230), (30, 30, 255),  675, 695, 35, 55, 20, 20, '+', 0, 0, 0, 15)
            if Display_conflict_stats == True:
                pygame.draw.rect(screen,Background_colour,[500, 60, 200, 100]) #background
                pygame.draw.rect(screen,border_colour,[500, 57, 200, 103],5) #border
                custom_text(f"Score:    {playerscore}", 15, 0,0,0, 600, 80)
                custom_text(f"Enemy Score:    {enemyscore}", 15, 0,0,0, 600, 100)
                custom_text(f"Casualties:    {playercasualties}", 15, 0,0,0, 600, 120)
                custom_text(f"Kills:    {enemycasualties}", 15, 0,0,0, 600, 140)
                textbutton((173, 216, 230), (30, 30, 255),  675, 695, 35, 55, 20, 20, '-', 0, 0, 0, 15)
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            Display_conflict_stats = False
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        pygame.mixer.music.set_volume(0.01)
                        music(1)
                        if 675 <= mouse[0] <= 695 or 35 <= mouse[1] <= 55:
                            Display_conflict_stats = False
                            click_time = pygame.time.get_ticks()
                        if (mouse[0] <= 500 or mouse[0] >= 700 and mouse[1] <= 160) or mouse[1] > 160:
                            Display_conflict_stats = False
                            conflict_display_screen = 'none'
            if pygame.mouse.get_pressed()[0] and pygame.time.get_ticks() - click_time >= 500:
                pygame.mixer.music.set_volume(0.01)
                music(1)
                if (mouse[0] <= 500 or mouse[0]>= 700 and mouse[1] <= 60) or mouse[1] > 60:
                    conflict_display_screen = 'none'
                if 675 <= mouse[0] <= 695 and 35 <= mouse[1] <= 55 and pygame.time.get_ticks() - click_time >= 100:
                    if Display_conflict_stats == False:
                        Display_conflict_stats = True
                        stats_click_time = pygame.time.get_ticks()
                    
                        

        if ViewDivisionMakeup == True: #screen that shows you the division makeup and number of soldiers
            CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
            displayy = 315
            pygame.draw.rect(screen,Background_colour,[0, displayy, 210, 60]) #background
            pygame.draw.rect(screen,border_colour,[0, displayy, 210, 64],5) #border
            custom_text(SelectedArmyName, 22, 0,0,0, 105, displayy+23)
            custom_text(f"{SelectedArmySize}/{SelectedMaxArmySize}", 13, 0,0,0, 105, displayy+45)
            ypos = displayy+60
            ypos = TroopArmyDisplayer('Infantry Division', 1, ypos, SelectedInfantrySize)
            ypos = TroopArmyDisplayer('Armoured Division', 1, ypos, SelectedArmorSize)
            ypos = TroopArmyDisplayer('Mechanized Division', 1, ypos, SelectedMechSize)
            travelmultiplier = 1
            for item in CountryData:
                items = item.split()
                if items[0] == player_country:
                    if items[-1] == 'Travel':
                        travelmultiplier = 1.5
            if CanMove == 't':
                pygame.draw.circle(screen, (0,0,0), (SelectedArmyX-1, SelectedArmyY+5), (20)*travelmultiplier, 1)
    def TroopArmyDisplayer(text, number, ypos, pull): #displayer, simplifies display of troops
        Background_colour = (255,253,208)
        border_colour = (92, 64,52)
        size = 17
        if text == 'Mechanized Division':
            size = 15
        for i in range(pull): #max 14 per army
            pygame.draw.rect(screen,Background_colour,[5, ypos, 200, 35]) #background
            pygame.draw.rect(screen, border_colour, [0, ypos, 210,35 ], 5) #divider
            custom_text(f'{text} {number}', size, 0, 0, 0, 105, ypos +16) #text
            number +=1
            ypos += 30
        return ypos
    def checkformove(selectedArmyName, armyx, armyy): #Checks where you move and what's in the location you moved to
        global cantMove, checkformovement, ViewDivisionMakeup, checkforsiege, saveStationed, savecountry, battle, updatedx, updatedy
        moveconfirmation = False
        updatelist = []
        checkxpos, checkypos = pygame.mouse.get_pos()
        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
        CountryData = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        travelmultiplier = 1
        for item in CountryData: #checks for the travel focus and applies a bonus if it's selected
            items = item.split()
            if items[0] == player_country:
                if items[-1] == 'Travel':
                    travelmultiplier = 1.5
        xcheck = abs(checkxpos-(armyx-1))
        ycheck = abs(checkypos-(armyy+5))
        for item in armyinfo:
            readcountry, readx, ready, readInfantryDivNo, readArmoredDivNo, readMechanizedDivNo, readCanMove, readName, readStationed, inSiege, armysize, maxsize, traintime = item.split()
            if readName == SelectedArmyName:
                selectedmove = readCanMove
                currentx = readx
                currenty = ready
                currentstationed = readStationed
                currentSiege = inSiege
        if xcheck <= (18*travelmultiplier) and ycheck <= (18*travelmultiplier) and selectedmove == 't': #if you click inside the radius
            checkerflag1, checkercountry1 = checkifonarmy(checkxpos, checkypos, readName)
            checkerflag, checkercity, checkercountry = checkifoncity(checkxpos, checkypos)
            if checkerflag1 == 'MoveEnemyArmy': #if you move onto an enemy army a battle is prompted
                moveconfirmation = True
                newx, newy = currentx, currenty
                newStationed = 'none'
                savecountry = checkercountry1
                checkforsiege = True
                battle = True
            elif checkerflag == 'MoveNone' and checkerflag1 == 'MoveNone': #if you don't move onto a city or enemy army it moves it to the new coordinates
                moveconfirmation = True
                newStationed = 'none'
                newy = checkypos
                newx = checkxpos
            elif checkerflag == 'MoveFriendly': #if you move onto an friendly city, it garrisons the army
                newStationed = checkercity
                moveconfirmation = True
                newx = 10000
                newy = 10000
            elif checkerflag == 'MoveEnemy': #if you move onto an enemy city, it prompts a siege
                moveconfirmation = True
                newx = currentx
                newy = currenty
                newStationed = currentstationed
                saveStationed = checkercity
                savecountry = checkercountry
                if currentSiege == 'f':
                    checkforsiege = True
                    battle = False
            elif checkerflag == 'CityFull' and checkerflag1 == 'CityFull': #if the city is full you don't move
                cantMove = True
                checkformovement = False
                ViewDivisionMakeup = False
            if moveconfirmation == True:
                CanMove = 'f' #changes it so that you can no longer move in that turn
                for item in armyinfo: #updates the position
                    country, oldx, oldy, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, OldCanMove, Name, Stationed, oldsiege, armysize, maxsize, traintime = item.split()
                    if Name == SelectedArmyName: #basically just updating the coordinates
                        updatelist.append(f'{country} {newx} {newy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {Name} {newStationed} f {armysize} {maxsize} {traintime}')
                    else:
                        updatelist.append(f'{country} {oldx} {oldy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {OldCanMove} {Name} {Stationed} {oldsiege} {armysize} {maxsize} {traintime}')
                movementupdatefile = open('ArmyInfo\ArmyLocation.txt', 'w')
                movementupdatefile.write('\n'.join(updatelist)) #writes the changes
                checkformovement = False
                moveconfirmation = False
                checkiffortify = False
                ViewDivisionMakeup = False
        else:
            cantMove = True
            checkformovement = False
            ViewDivisionMakeup = False
    def checkifoncity(militaryx, militaryy): #checking if you clicked on a city
        CityCheck = False
        FriendlyCity = False
        SelectedCity = 'none'
        FactionInfo = ((open('TextFiles\Factions.txt', 'r')).read()).split('\n')
        Selectedcountry = 'none'
        for item in Cities:
            city, cityx, cityy, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
            cityx, cityy = int(cityx), int(cityy)
            if cityx-11 <= militaryx <= cityx+6 and cityy-7 <= militaryy <= cityy+7: #checks the coordinates
                if country == player_country: 
                    FriendlyCity = True #checks if it's a friendly city
                CityCheck = True
                SelectedCity= city 
                Selectedcountry = country
        for item in FactionInfo: #checks if it's a friendly city
            factionname, factionmembers = item.split()
            factionmemberslist = factionmembers.split('|')
            if player_country in factionmemberslist and Selectedcountry in factionmemberslist:
                CityCheck = True
                FriendlyCity = True
        stationedcount = 0 
        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
        for armyitem in armyinfo: #checks how many armies are stationed
            armycountry, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = armyitem.split()
            if stationed == SelectedCity:
                stationedcount += 1
        if stationedcount == 6: 
            return('CityFull', 'None', 'None')
        if CityCheck == True: #returns various results
            if FriendlyCity == True:
                return ('MoveFriendly', SelectedCity, Selectedcountry)
            else:
                return ('MoveEnemy', SelectedCity, Selectedcountry)
        else:
            return ('MoveNone', 'None', 'None')
    def checkifonarmy(militaryx, militaryy, oldName): #checks if you clicked on an army
        global updatedx, updatedy, savecountry, AttackedArmyName
        FactionInfo = ((open('TextFiles\Factions.txt', 'r')).read()).split('\n')
        for item in armyinfo:
            country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, AttackedArmyName, stationed, siegestatus, armysize, maxsize, traintime = item.split() #assigning variable names to all data
            armyx, armyy = int(x), int(y)
            if armyx-4 <= militaryx <= armyx+4 and armyy-7 <= militaryy <= armyy+7:
                if AttackedArmyName != oldName:
                    if country != player_country:
                        for item in FactionInfo: #checks if it's a friendly army, in which case you can't move 
                            factionname, factionmembers = item.split()
                            factionmemberslist = factionmembers.split('|')
                            if player_country in factionmemberslist and country in factionmemberslist:
                                return 'CityFull', 'none'
                        updatedx, updatedy = armyx-8, armyy+3
                        return 'MoveEnemyArmy', country
                    else:
                        return 'CityFull', 'none'
        return 'MoveNone', 'none'
    def siegechecker(name): #Checks if you want to a start a siege/battle or not. If you start a battle it runs the battle calculations
        global saveStationed, conflict_display_screen, click_time, playerscore, enemyscore, playercasualties, enemycasualties, completionscreen
        updatelist = []
        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
        pygame.draw.rect(screen,(255,253,208),[screenwidth/2-150, 0, 300, 150]) #background
        pygame.draw.rect(screen, (92, 64,52), [screenwidth/2-150, 0, 300, 150 ], 5) #Border
        custom_text(f'Would you like to start a {name}?', 16, 255, 20, 20, screenwidth/2, 20)
        pygame.draw.line(screen, (92, 64,52), [screenwidth/2-150, 35], [screenwidth/2+149, 35], 2) #divider
        custom_text(f'Starting a {name} is an act of war.', 14, 0, 0, 0, screenwidth/2, 60)

        #Yes Button
        textbutton((52, 163, 0), (60,253,68),screenwidth/2+15 , screenwidth/2+135, 90, 140, 120, 50, 'YES', 0, 0, 0, 22)
        pygame.draw.rect(screen, (92, 64,52), [screenwidth/2+15, 90, 120, 50 ], 3) #Border

        #No Button
        textbutton((161, 34, 18), (255, 43, 15),screenwidth/2-130 , screenwidth/2-10, 90, 140, 120, 50, 'NO', 0, 0, 0, 22)
        pygame.draw.rect(screen, (92, 64,52), [screenwidth/2-130, 90, 120, 50 ], 3) #Border
        completionscreen = True
        if pygame.mouse.get_pressed()[0]: #if you click
            pygame.mixer.music.set_volume(0.01)
            music(1)
            pygame.time.wait(100)
            completionscreen = False
            if screenwidth/2 + 15 <= mouse[0] <= screenwidth/2 + 135 and 90 <= mouse[1] <= 140: #If you click the yes button
                warinfo = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split('\n')
                for item in warinfo:
                    basecountry, warlist = item.split()
                    if basecountry == player_country:
                        if savecountry not in warlist:
                            WarDeclaration(player_country, savecountry)
                newx = 10000
                newy = 10000
                newsiegestatus = 't'
                if name == 'battle': #if it's a battle it runs the battle calcualtions
                    newx = updatedx
                    newy = updatedy
                    saveStationed = 'none'
                    newsiegestatus = 'f'
                    outcome, playerscore, enemyscore, playercasualties, enemycasualties = SiegeCalculations(savecountry, player_country, 'NoCity', SelectedArmyName, AttackedArmyName, 'none')
                    if outcome == savecountry: #If you lose
                        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
                        for item in armyinfo: #changes it so that you can no longer move in that turn
                            country, oldx, oldy, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, OldCanMove, Name, Stationed, oldsiege, armysize, maxsize, traintime = item.split()
                            if Name == SelectedArmyName: #basically just updating the coordinates
                                updatelist.append(f'{country} {oldx} {oldy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {Name} none {oldsiege} {armysize} {maxsize} {traintime}')
                            else:
                                updatelist.append(f'{country} {oldx} {oldy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {OldCanMove} {Name} {Stationed} {oldsiege} {armysize} {maxsize} {traintime}')
                        movementupdatefile = open('ArmyInfo\ArmyLocation.txt', 'w')
                        movementupdatefile.write('\n'.join(updatelist)) #writes the changes
                        click_time = pygame.time.get_ticks()
                        conflict_display_screen = 'DEFEAT'
                            
                    else: #if you win
                        click_time = pygame.time.get_ticks()
                        conflict_display_screen = 'VICTORY'
                        armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
                        for item in armyinfo: #changes it so that you can no longer move in that turn
                            country, oldx, oldy, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, OldCanMove, Name, Stationed, oldsiege, armysize, maxsize, traintime = item.split()
                            if Name == SelectedArmyName: #basically just updating the coordinates
                                updatelist.append(f'{country} {newx} {newy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {Name} none {newsiegestatus} {armysize} {maxsize} {traintime}')
                            if Name == AttackedArmyName: #enemy army is moved backed 5 spaces
                                updatelist.append(f'{country} {int(oldx)+5} {oldy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {Name} none {oldsiege} {armysize} {maxsize} {traintime}')
                            elif Name != SelectedArmyName and Name != AttackedArmyName:
                                updatelist.append(f'{country} {oldx} {oldy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {OldCanMove} {Name} {Stationed} {oldsiege} {armysize} {maxsize} {traintime}')
                if len(updatelist) == 0: #if you clicked yes on the siege button
                    armyinfo = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split('\n')
                    for item in armyinfo: #changes it so that you can no longer move in that turn
                        country, oldx, oldy, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, OldCanMove, Name, Stationed, oldsiege, armysize, maxsize, traintime = item.split()
                        if Name == SelectedArmyName: #basically just updating the coordinates
                            updatelist.append(f'{country} {newx} {newy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {Name} {saveStationed} {newsiegestatus} {armysize} {maxsize} {traintime}')
                        else:
                            updatelist.append(f'{country} {oldx} {oldy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {OldCanMove} {Name} {Stationed} {oldsiege} {armysize} {maxsize} {traintime}')
                movementupdatefile = open('ArmyInfo\ArmyLocation.txt', 'w')
                movementupdatefile.write('\n'.join(updatelist)) #writes the changes
                return True
            elif screenwidth/2-130 <= mouse[0] <= screenwidth/2 - 10 and 90 <= mouse[1] <= 140: #if you clicked no
                for item in armyinfo: #changes it so that you can no longer move in that turn
                    country, oldx, oldy, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, OldCanMove, Name, Stationed, oldsiege, armysize, maxsize, traintime = item.split()
                    if Name == SelectedArmyName: #basically just updating the coordinates
                        updatelist.append(f'{country} {oldx} {oldy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {Name} {saveStationed} {oldsiege} {armysize} {maxsize} {traintime}')
                    else:
                        updatelist.append(f'{country} {oldx} {oldy} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {OldCanMove} {Name} {Stationed} {oldsiege} {armysize} {maxsize} {traintime}')
                movementupdatefile = open('ArmyInfo\ArmyLocation.txt', 'w')
                movementupdatefile.write('\n'.join(updatelist)) #writes the changes
                return False
class ComputerHandler(): #handler to control actions during the computer turn
    global InfoCalculator, FocusCalculations, DiplomacyHandler, TroopMover
    def InfoCalculator(chosencountry,treasury, military, manpower, Focus, Month): #trains armies, upgrades buildings
        global cityfile
        atwarstatus = False
        TrainTroops = False
        TrainingRequirement = 1
        Capital_city = 'none'
        cityfile = ((open('TextFiles\CityNames.txt', 'r')).read()).split("\n")
        countrysavefile = ((open('TextFiles\Countries save.txt', 'r')).read()).split("\n")
        armyfile = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split("\n")
        countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split("\n")
        countryfile = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        for item in countrywarfile: #checks if country is at war and, if it is as war, how many armies it has
            basecountry, warlist = item.split()
            if basecountry == chosencountry:
                if warlist != 'none':
                    atwarstatus = True
                    for item in countrysavefile:
                        savecountry, savetreasury, saveGDP, savemilitary, savemanpower, savepopulation, saveFocus = item.split()
                        if savecountry == chosencountry:
                            if saveFocus == 'Training':
                                TrainingRequirement = 0.9
                            if military <= int(savemilitary) * 2:
                                TrainTroops = True
                            else:
                                TrainTroops = False
        major_list = ['France', 'Italy', 'Germany', 'Poland', 'SovietUnion','Spain', 'UK']
        if atwarstatus == True and chosencountry != 'Luxembourg' and TrainTroops == True: #trains soldiers, only when at war
            numberlist = []
            for item in armyfile:
                country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = item.split() #assigning variable names to all data
                if country == chosencountry:
                    updatelist = []
                    for letter in Name:
                        if letter.isdigit() == True:
                            updatelist.append(letter)
                    numberlist.append(int(''.join(updatelist)))
            numberlist.sort()
            if len(numberlist) != 0:
                newnumber = int((numberlist)[-1]) + 1
            else:
                newnumber = 1
            if chosencountry in major_list: #decides whether it is a "major" country or not, determines how big the army it trains is
                mechcount = 2
                armorcount = 1
                infantrycount = 4
            else:
                mechcount = 1
                armorcount = 0
                infantrycount = 3
            #calculates cost and manpower of training an army
            costmodifier, traintimemodifier, trainmanpowermodifier = ArmyBuildingBonusCalculator(chosencountry)
            totalcost = infantrycount*25000*costmodifier*TrainingRequirement + armorcount * 50000*costmodifier*TrainingRequirement  + mechcount *30000*costmodifier*TrainingRequirement 
            totalcost = int(round(totalcost, 0))
            totalmanpower = infantrycount*40000*trainmanpowermodifier*TrainingRequirement  + 20000*armorcount*trainmanpowermodifier*TrainingRequirement  + 30000*mechcount*trainmanpowermodifier*TrainingRequirement 
            totalmanpower = int(round(totalmanpower, 0))
            standingmanpower = infantrycount*40000 + 20000*armorcount + 30000*mechcount
            TrainName = f"{chosencountry}Army{newnumber}"
            controlledcities = []
            Capital = 'none'
            Deploycity = 'none'
            for item in cityfile: #checks where to spawn the army
                city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
                if country == chosencountry:
                    controlledcities.append(f"{city} {citytype}")
                if country == chosencountry and citytype == 't':
                    Capital = f"{city} {citytype}"
            if Capital in controlledcities:
                cityname, citiestype = Capital.split()
                Deploycity = cityname
            else:
                for controlleditem in controlledcities:
                    cityname, citiestype = controlleditem.split()
                    Deploycity = cityname
                
            Capital_city = Deploycity
            
            
            counter = 0
            for item in armyfile:
                country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = item.split()
                if stationed == Capital_city:
                    counter += 1
            if counter < 5:
                if totalcost <= treasury and totalmanpower <= manpower: #adds the army to file if it can be afforded
                    newarmy = f"\n{chosencountry} {100000} {100000} {infantrycount} {armorcount} {mechcount} t {TrainName} {Capital_city} f {standingmanpower} {standingmanpower} 0"
                    with open('ArmyInfo\ArmyLocation.txt', 'a') as file:
                        file.write(newarmy)
                        
                    citycounter = 0
                    player_update_list = []
                    for item in cityfile: #checks number of cities, divides manpower by number of cities
                        city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split() 
                        if country == chosencountry:
                            citycounter +=1
                            player_update_list.append(item)
                    manpowercostpercity = totalmanpower/citycounter
                    for item in player_update_list: #removes manpower from the cities
                        city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
                        new_player_update_item = (f"{city} {x} {y} {country} {city_income} {int(round(int(city_manpower) - manpowercostpercity,0))} {population} {barracks} {factory}  {market} {fort} {citytype}")
                        if item in cityfile:
                            cityfile.remove(item)
                            cityfile.append(new_player_update_item)
                    countryupdatelist = [] #updates the countries stats following this cahnge
                    for item in countryfile: #checks the country data file
                        savecountry, savetreasury, saveGDP, savemilitary, savemanpower, savepopulation, savefocus = item.split()
                        if savecountry == chosencountry: #Removes cost of training from treasury

                            countryupdatelist.append(f"{savecountry} {int(savetreasury)-totalcost} {saveGDP} {int(round(int(savemilitary) + totalmanpower, 0))} {manpower-totalmanpower} {savepopulation} {savefocus}")
                        else:
                            countryupdatelist.append(f"{savecountry} {savetreasury} {saveGDP} {savemilitary} {savemanpower} {savepopulation} {savefocus}")
                    with open('TextFiles\Countries.txt','w') as file:
                        file.write('\n'.join(countryupdatelist))
        elif TrainTroops == False or atwarstatus == False: #if not at war, upgrades buildings with money instead
            buildingstoupgrade = []
            upgradeorder = ['small', 'medium', 'large']
            for item in cityfile: #checks which buildings are the weakest, starts with the weakest first
                city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
                if country == chosencountry:
                    if barracks == 'small' or factory == 'small' or market == 'small' or fort == 'small':
                        buildingstoupgrade.append(city)
            if len(buildingstoupgrade) == 0:
                for item in cityfile:
                    city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
                    if country == chosencountry:
                        if barracks == 'medium' or factory == 'medium' or market == 'medium' or fort == 'medium':
                            buildingstoupgrade.append(city)
            else:
                citywritelist = []
                upgradenumber = random.randint(0, len(buildingstoupgrade)-1)
                upgradecity = buildingstoupgrade[upgradenumber] #picks a random city to upgrade from the list
                for item in cityfile: #checks if they can afford the upgrade and starts upgrading from the market first
                    city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split()
                    if city == upgradecity: #calculates cost of upgrading and upgrades them
                        if upgradeorder.index(market) != 2:
                            cost = 100000 + 150000*upgradeorder.index(market)
                            if cost <= treasury:
                                market = upgradeorder[upgradeorder.index(market) + 1]
                        elif upgradeorder.index(factory) != 2:
                            cost = 100000 + 150000*upgradeorder.index(market)
                            if cost <= treasury:
                                factory = upgradeorder[ upgradeorder.index(factory) + 1]
                        elif upgradeorder.index(barracks) != 2:
                            cost = 100000 + 150000*upgradeorder.index(market)
                            if cost <= treasury:
                                barracks = upgradeorder[upgradeorder.index(barracks) + 1]
                        elif upgradeorder.index(fort) != 2:
                            cost = 100000 + 150000*upgradeorder.index(market)
                            if cost <= treasury:
                                fort = upgradeorder[upgradeorder.index(fort) + 1]
                    citywritelist.append(f"{city} {x} {y} {country} {city_income} {city_manpower} {population} {barracks} {factory} {market} {fort} {citytype}")
                
                
                
                countrywritefile = []
                countryfile = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
                for item in countryfile: #subtracts the cost from the country treasury and writes the change
                    savecountry, savetreasury, saveGDP, savemilitary, savemanpower, savepopulation, savefocus = item.split()
                    if savecountry == chosencountry and cost <= int(savetreasury):
                        savetreasury = int(savetreasury)
                        savetreasury -= cost
                    countrywritefile.append(f"{savecountry} {savetreasury} {saveGDP} {savemilitary} {savemanpower} {savepopulation} {savefocus}")
                with open('TextFiles\Countries.txt', 'w') as file:
                    file.write('\n'.join(countrywritefile))
                if int(savetreasury) >= 0: #updates the cityfile with the new building level
                    cityfile = citywritelist
        FocusCalculations(Focus, atwarstatus, manpower, major_list, chosencountry, military)
    def FocusCalculations(Focus, atwarstatus, manpower, majors, chosencountry, military): #Decides which focus to select
        global atwarlist
        countryfile = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        countrywarfile = ((open('TextFiles\CountryWarFile.txt', 'r')).read()).split("\n")
        for item in countrywarfile: #checks who the country is at war with
            basecountry, warlist = item.split()
            if basecountry == chosencountry:
                atwarlist = warlist.split('|')
        totalenemymilitary = 0
        for item in countryfile: #checks the enmy military size
            items = item.split()
            if items[0] in atwarlist:
                totalenemymilitary += int(items[3])
        if atwarstatus == True: #if the country is at war
            if chosencountry in majors and manpower <= 240000: #if it has little manpower
                newfocus = 'Manpower'
            elif chosencountry not in majors and manpower <= 150000:
                newfocus = 'Manpower'
            elif chosencountry in majors and military <= 0.8*totalenemymilitary: #if their military is too small
                newfocus = 'Training'
            elif chosencountry not in majors and military <= 0.2*totalenemymilitary:
                newfocus = 'Training'
            else:#if both of those are fine it selects on of these
                possible = ['Defense', 'Planes', 'Travel']
                newfocus = possible[random.randint(0, 2)]
        if atwarstatus == False: #if it's not at war, they focus on industry
            newfocus = 'Industry'
        countryupdatelist = []
        for item in countryfile: #updates relevant files
            savecountry, savetreasury, saveGDP, savemilitary, savemanpower, savepopulation, savefocus = item.split()
            if savecountry == chosencountry:
                savefocus = newfocus
            countryupdatelist.append(f"{savecountry} {savetreasury} {saveGDP} {savemilitary} {savemanpower} {savepopulation} {savefocus}")
        with open('TextFiles\Countries.txt', 'w') as file:
            file.write('\n'.join(countryupdatelist))
        DiplomacyHandler(chosencountry, atwarstatus, Focus)
    def DiplomacyHandler(chosencountry, atwarstatus, Focus): #Diplomatic interactions with other countries, they trade manpower and money
        global treasury, manpower, cityfile
        countrysavefile = ((open('TextFiles\Countries save.txt', 'r')).read()).split("\n")
        countryfile = ((open('TextFiles\Countries.txt', 'r')).read()).split("\n")
        check = True
        for item in countryfile:#checks how much money they have
            items = item.split()
            if items[0] == chosencountry:
                treasury = int(items[1])
                manpower = int(items[4])
        for item in countrysavefile: #checks how much manpower/money they need or howmuch extra they have
            savecountry, savetreasury, saveGDP, savemilitary, savemanpower, savepopulation, saveFocus = item.split()
            savetreasury = int(savetreasury)
            savemanpower = int(savemanpower)
            if savecountry == chosencountry:
                replacetreasury, replacemanpower = treasury-savetreasury, manpower-savemanpower
                if replacetreasury <= 0 and replacemanpower <= 0:
                    replacetreasury, replacemanpower = 0, 0
                    check = False
                elif replacetreasury < 0:
                    manpowersurplus = manpower-savemanpower
                elif replacemanpower < 0:
                    treasurysurplus = treasury-savetreasury
                else:
                    check = False
        
        currenttreasury = 0
        currentmanpower = 0
        currentcountry = 'none'
        for item in countryfile: #checks which country has the most manpower and money to offer
            othercountry, othertreasury, otherGDP, othermilitary, othermanpower, otherpopulation, otherFocus = item.split()
            if int(othertreasury) > currenttreasury and othercountry != chosencountry and othercountry != player_country:
                treasurycountry = othercountry
                treasurycountrytreasury = int(othertreasury)
                treasurycountrymanpower = int(othermanpower)
            if  int(othermanpower) >currentmanpower and othercountry != chosencountry and othercountry != player_country:
                manpowercountry = othercountry
                manpowercountrymanpower = int(othermanpower)
                manpowercountrytreasury = int(othertreasury)
        
        if replacetreasury < 0: #Buys money with manpower
            currentcountry = treasurycountry
            demandedmoney = manpowersurplus *0.1
            if treasurycountrytreasury - demandedmoney <= 0.5*treasurycountrytreasury:
                reducedrate = ((treasurycountrytreasury*0.5)/demandedmoney)
                manpowersurplus *= reducedrate
                demandedmoney = treasurycountrytreasury*0.5
            treasurycountrytreasury -= int(round(demandedmoney,0))
            newmanpower = manpower - int(round(manpowersurplus,0))
            treasury += int(round(demandedmoney,0))
            treasurycountrymanpower += int(round(manpowersurplus,0))
            currenttreasury = treasurycountrytreasury
            currentmanpower = treasurycountrymanpower
        if replacemanpower < 0: #buys manpower with money
            currentcountry = manpowercountry
            demandedmanpower = treasurysurplus*10
            if manpowercountrymanpower - demandedmanpower <= 0.5*manpowercountrymanpower:
                reducedrate = ((manpowercountrymanpower*0.5)/demandedmanpower)
                treasurysurplus *= reducedrate
                demandedmanpower = manpowercountrymanpower*0.5
            manpowercountrytreasury += int(round(treasurysurplus,0))
            newmanpower = manpower + int(round(demandedmanpower,0))
            treasury -= int(round(treasurysurplus,0))
            manpowercountrymanpower -= int(round(demandedmanpower,0))
            currenttreasury = manpowercountrytreasury
            currentmanpower = manpowercountrymanpower
        if check == True: #If a trade has been made, the updates are written
            countrywritefile = []
            for item in countryfile:
                othercountry, othertreasury, otherGDP, othermilitary, othermanpower, otherpopulation, otherFocus = item.split()
                if othercountry == currentcountry:
                    countrywritefile.append(f"{othercountry} {currenttreasury} {otherGDP} {othermilitary} {currentmanpower} {otherpopulation} {otherFocus}")
                elif othercountry == chosencountry:
                    countrywritefile.append(f"{othercountry} {treasury} {otherGDP} {othermilitary} {newmanpower} {otherpopulation} {otherFocus}")
                else:
                    countrywritefile.append(f"{othercountry} {othertreasury} {otherGDP} {othermilitary} {othermanpower} {otherpopulation} {otherFocus}")
            with open('TextFiles\Countries.txt', 'w') as file:
                file.write('\n'.join(countrywritefile))
            citycounter = 0
            othercitycounter = 0
            player_update_list = []
            other_update_list = []
            normal_update_list = []
            for item in cityfile: #checks number of cities, divides manpower by number of cities
                city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split() 
                if country == chosencountry:
                    citycounter +=1
                    player_update_list.append(item)
                if country == currentcountry:
                    othercitycounter += 1
                    other_update_list.append(item)
                elif country != chosencountry and country != currentcountry:
                    normal_update_list.append(f"{city} {x} {y} {country} {city_income} {city_manpower} {population} {barracks} {factory} {market} {fort} {citytype}")
            if citycounter == 0 or othercitycounter == 0:
                manpowercostperchosencity, manpowercostperothercity = 0,0
            else:
                manpowercostperchosencity = newmanpower/citycounter
                manpowercostperothercity = currentmanpower/othercitycounter
            new_player_update_list = []
            new_other_update_list = []

            for item in player_update_list: #adds manpower to the cities
                city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split() 
                new_player_update_list.append(f"{city} {x} {y} {country} {city_income} {int(round(manpowercostperchosencity, 0))} {population} {barracks} {factory}  {market} {fort} {citytype}")
            for item in other_update_list: #adds manpower to the cities
                city, x, y, country, city_income, city_manpower, population, barracks, factory, market, fort, citytype = item.split() 
                new_other_update_list.append(f"{city} {x} {y} {country} {city_income} {int(round(manpowercostperothercity, 0))} {population} {barracks} {factory}  {market} {fort} {citytype}")
            combined_list = normal_update_list + new_player_update_list + new_other_update_list
            cityfile = combined_list
        TroopMover(chosencountry, atwarstatus, Focus)
    def TroopMover(chosencountry, atwarstatus, Focus): #moves armies when the country is at war
        global cityfile
        armychosen = False
        citysavefile = ((open('TextFiles\CitySave.txt', 'r')).read()).split("\n")
        armyfile = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split("\n")
        startingcities = []
        missingcities = []
        bonus = 1
        Distance = 0
        if Focus == 'Travel': #checks if they have a travel bonus
            bonus = 1.5
        for item in citysavefile:
            items = item.split()
            if items[3] == chosencountry:
                startingcities.append(items[0])
        for item in cityfile: #checks if any of their cities are missing
            items = item.split()
            if items[0] in startingcities and items[3] != chosencountry and items[3] in atwarlist:
                missingcities.append(f"{items[0]} {items[1]} {items[2]}")
        armyfileinitialupdatelist = []
        for item in armyfile:
            country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = item.split()
            if stationed != 'none' and country == chosencountry: #if the armies are stationed somewhere
                for citystatitem in cityfile:
                    cityitems = citystatitem.split()
                    if cityitems[0] == stationed: #moves the armies to the coordinates of the city and unstations them
                        if cityitems[3] == chosencountry:
                            x, y = int(cityitems[1]), int(cityitems[2])
                            stationed = 'none'
            armyfileinitialupdatelist.append(f"{country} {x} {y} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {Name} {stationed} {siegestatus} {armysize} {maxsize} {traintime}")
        with open('ArmyInfo\ArmyLocation.txt', 'w') as file:
            file.write('\n'.join(armyfileinitialupdatelist))
        if len(missingcities) != 0 and atwarstatus == True: #if they are missing any cities
            ArmiesStationed = False
            armyfile = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split("\n")
            towardcitymovements = []
            distances = []
            for item in armyfile: #checks the distance of all armies from that city
                country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = item.split()
                x, y = int(x), int(y)
                if country == chosencountry:
                    for cityitem in missingcities:
                        cityname, cityx, cityy = cityitem.split()
                        cityx, cityy = int(cityx), int(cityy)
                    distance = ((abs(cityx-x)**2)*(abs(cityy-y)**2))**0.5
                    distances.append(distance)
                    towardcitymovements.append(f"{Name} {cityname} {distance} {cityx} {cityy} {country}")
                
            distances.sort()
            list_length = len(distances)
            list_length = math.floor(list_length/2)
            if list_length == 0 and len(distances) > 0:
                list_length = 1
            distance_changers = []
            for i in range(0, list_length): #checks which armies are the closets
                distance_changers.append(distances[i])
            armyupdatelist = []
            for item in towardcitymovements: #moves the armies towards the city and stations them if they're close enough
                Name, CityName, Distance, readcityx, readcityy, BaseCountry = item.split()
                if float(Distance) in distance_changers:
                    armyfile = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split("\n")
                    readcityx, readcityy = int(readcityx), int(readcityy)
                    for army in armyfile:
                        country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, ArmyName, stationed, siegestatus, armysize, maxsize, traintime = army.split()
                        if BaseCountry == country:
                            x,y = int(x), int(y)
                            if abs(readcityx-x) <16 and abs(readcityy-y) <16: #checks if they're within range to be stationed
                                stationed = CityName
                                x = 10000
                                y = 10000
                                ArmiesStationed = True
                            if abs(readcityx - x) >= 16:#moves x and y depending onwhat needs to be moved
                                if readcityx > x:
                                    x+= 16*bonus
                                else:
                                    x -= 16*bonus
                            elif abs(readcityx-x) < 16:
                                x += (readcityx-x)
                            if abs(readcityy - y) >= 16:
                                if readcityy > y:
                                    y += 16*bonus
                                else:
                                    y -= 16*bonus
                            elif abs(readcityy-y) <16:
                                y += (readcityy-y)
                        x, y = int(round(float(x), 0)), int(round(float(y),0))
                        updateitem = f"{country} {x} {y} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {ArmyName} {stationed} {siegestatus} {armysize} {maxsize} {traintime}"
                        if updateitem not in armyupdatelist:
                            armyupdatelist.append(updateitem)
            if len(towardcitymovements) != 0:#updates the armylist with new coordinates if there are armies that have moved
                with open('ArmyInfo\ArmyLocation.txt', 'w') as file:
                    file.write('\n'.join(armyupdatelist))
            if ArmiesStationed == True: #if armies have been stationed in the target city
                armyfile = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split("\n")
                targetcountry = ''
                for cityitem in cityfile: #checks what country is being attacked
                    cityinfoline = cityitem.split()
                    if cityinfoline[0] == CityName:
                        targetcountry = cityinfoline[3]
                if targetcountry != '': #runs the siege calculations
                    outcome, playerscore, enemyscore, playercasualties, enemycasualties = SiegeCalculations(targetcountry, chosencountry, CityName, 'none', 'none', 'none')
                    if outcome == chosencountry: #if they win the city is transferred to them
                        for item in cityfile:
                            items = item.split()
                            if items[0] == CityName:
                                items[3] = chosencountry
                                cityfile.remove(item)
                                cityfile.append(' '.join(items))


        elif atwarstatus == True: #Next priority is enemy armies and enemy cities
            armyfile = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split("\n")
            enemyarmies = []
            for item in armyfile: #checks where all the enemy armies are
                country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = item.split()
                if country in atwarlist:
                    enemyarmies.append(f"{Name} {x} {y} {country}")
            CasualtyFile = []
            armywritefile = []
            armyfile = ((open('ArmyInfo\ArmyLocation.txt', 'r')).read()).split("\n")
            for item in armyfile:
                country, x, y, InfantryDivNo, ArmoredDivNo, MechanizedDivNo, CanMove, Name, stationed, siegestatus, armysize, maxsize, traintime = item.split()
                armysize = int(armysize)
                if len(enemyarmies) != 0: #if there are armies to be attacked
                    if country == chosencountry:
                        standardarmydistancex = 50000
                        standardarmydistancey = 50000
                        standardcitydistancex = 50000
                        standardcitydistancey = 50000
                        x,y = int(x), int(y)
                        playerarmyname = Name
                        for enemyitem in enemyarmies: #for all enemy armies
                            armyname, enemyx, enemyy, enemycountry = enemyitem.split()
                            enemyx, enemyy = int(enemyx), int(enemyy)
                            if ((abs(enemyx-x)**2) + (abs(enemyy-y)**2))**0.5 < ((standardarmydistancex**2) + (standardarmydistancey**2))**0.5: #checks which enemy army is closest to the selected army
                                standardarmydistancex = (abs(enemyx-x))
                                standardarmydistancey = (abs(enemyy-y))
                                armydirectdistance = ((standardarmydistancex**2) + (standardarmydistancey**2))**0.5
                                newarmyx = enemyx
                                newarmyy = enemyy
                                targetarmy = armyname
                                targetarmycountry = enemycountry
                        for enemycity in cityfile: #checks which enemy city is the closest to the selected city
                            enemycityinfo = enemycity.split()
                            if enemycityinfo[3] in atwarlist:
                                enemycityx = int(enemycityinfo[1])
                                enemycityy = int(enemycityinfo[2])
                                if ((abs(enemycityx-x)**2) + (abs(enemycityy -y)**2))**0.5 < ((standardcitydistancex **2) + (standardcitydistancey**2))**0.5:
                                    standardcitydistancex = (abs(enemycityx-x))
                                    standardcitydistancey = (abs(enemycityy-y))
                                    citydirectdistance = ((standardcitydistancex **2) + (standardcitydistancey**2))**0.5
                                    newcityx = enemycityx
                                    newcityy = enemycityy 
                                    targetcity = enemycityinfo[0]
                                    targetcitycountry = enemycityinfo[3]
                        if citydirectdistance <= armydirectdistance: #checks if the city is closer or the army is closer
                            newx = newcityx
                            newy = newcityy
                            target = targetcity
                            targetcountry = targetcitycountry
                            armychosen = False
                        else:
                            newx = newarmyx
                            newy = newarmyy
                            target = targetarmy
                            targetcountry = targetarmycountry
                            armychosen = True
                        
                        if abs(newx-x) <16 and abs(newy-y) <16 and targetcountry != chosencountry: #if close enough to engage in a battle
                            outcome, playercasualties, enemycasualties = 'none', 0, 0
                            if armychosen:
                                outcome, playerscore, enemyscore, playercasualties, enemycasualties = SiegeCalculations(targetcountry, chosencountry, 'NoCity', playerarmyname, target, cityfile)
                            else:
                                executesiege = False
                                for armyitem in armyfile:
                                    armyinfo = armyitem.split()
                                    if armyinfo [8] == target and armyinfo[0] == chosencountry:
                                        executesiege = True
                                        
                                if executesiege:
                                    outcome, playerscore, enemyscore, playercasualties, enemycasualties = SiegeCalculations(targetcountry, chosencountry, target, 'none', 'none', 'none')
                                else:
                                    stationed = target
                            if outcome == chosencountry and armychosen == False:
                                #move towards
                                for cityitem in cityfile:
                                    cityitems = cityitem.split()
                                    if cityitems[0] == targetcity:
                                        cityitems[3] = chosencountry
                                    cityfile.remove(cityitem)
                                    cityfile.append(' '.join(cityitems))
                            casualtytarget = target
                            if armychosen == False:
                                for armyitem in armyfile:
                                    armyitems = armyitem.split()
                                    if armyitems[8] == target and armyitems[0] == targetcountry:
                                        armyitems[10] = int(armyitems[10]) - int(enemycasualties)
                                        casualtytarget = armyitems[7]
                                        CasualtyFile.append(f"{casualtytarget} {enemycasualties}")
                            else:
                                CasualtyFile.append(f"{casualtytarget} {enemycasualties}")
                            armysize -= int(playercasualties)
                            
                        else:# if no armies are close enough
                            if enemyarmies != 'TRUE': #moves towards them
                                if abs(newx - x) >= 16:
                                    if newx > x:
                                        x+= 16 *bonus
                                    else:
                                        x -= 16*bonus
                                elif abs(newx-x) < 16:
                                    x += (newx-x)
                                if abs(newy - y) >= 16:
                                    if newy > y:
                                        y += 16*bonus
                                    else:
                                        y -= 16*bonus
                                elif abs(newy-y) <16:
                                    y += (newy-y)
                x, y = round(float(x), 0), round(float(y),0)
                armywritefile.append(f"{country} {int(x)} {int(y)} {InfantryDivNo} {ArmoredDivNo} {MechanizedDivNo} {CanMove} {Name} {stationed} {siegestatus} {armysize} {maxsize} {traintime}") #updates army file with new changes
            targets = {}
            Finalarmywritefile = []
            for armyitem in CasualtyFile: #adds casualties to the casualty file for future use
                target, enemycasualties = armyitem.split()
                if target in targets:
                    targets[target] = int(targets[target]) + int(enemycasualties)
                else:
                    targets[target] = enemycasualties
            for armyfileitem in armywritefile: #updates army file with casualties
                armyfileitems = armyfileitem.split()
                if armyfileitems[7] in targets.keys():
                    enemycasualties = int(targets[armyfileitems[7]])
                    armyfileitems[10] = str(int(armyfileitems[10])-int(enemycasualties))
                if int(armyfileitems[10]) > 0:
                    Finalarmywritefile.append(' '.join(armyfileitems))
            with open('ArmyInfo\ArmyLocation.txt', 'w') as file:
                file.write('\n'.join(Finalarmywritefile))
        with open('TextFiles\CityNames.txt', 'w') as file:
            file.write('\n'.join(cityfile))
            








                


#main runnner
running = True
gamesetter()
BuildingBonusApplier()
while running:
    global Tutorialdisplayscreen
    mouse = pygame.mouse.get_pos()
    starting_screen()
    GameRunner()
    Options()
    Tutorial()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if Menu_screen == 1:
                if 325 <= mouse[0] <= 675 and 400 <= mouse[1] <= 440: #play button
                    Menu_screen = 0
                    pygame.mixer.music.stop()
                    music_running = False
                elif 325 <= mouse[0] <= 675 and 460 <= mouse[1] <= 500: #options button
                    Menu_screen = 2
                elif 325 <= mouse[0] <= 675 and 520 <= mouse[1] <= 580: #tutorial button
                    Menu_screen = 3
                    Tutorialdisplayscreen = 1
                elif 325 <= mouse[0] <= 675 and 580 <= mouse[1] <= 620:
                    pygame.quit()
            elif Menu_screen == 2:
                if 63 <= mouse[0] <= 173 and 667 <= mouse[1] <= 767: #back_button_options
                    Menu_screen = 1
                elif 850 <= mouse[0] <= 900 and 275 <= mouse[1] <= 325: #music button
                    if run_music == True:
                        pygame.mixer.music.stop()
                        run_music = False
                        music_running = False
                    else:
                        run_music = True
                elif 850 <= mouse[0] <= 900 and 375 <= mouse[1] <= 425:
                    if historicalmode == True:
                        historicalmode = False
                    elif historicalmode == False:
                        historicalmode = True
                elif 675 <= mouse[0] <= 875 and 500 <= mouse[1] <= 560: #restart button, restarts your game
                    country_selected = False
                    open('TextFiles\CasualtyFile.txt', 'w')
                    gamesetter()
                    Month = 0
                    BuildingBonusApplier()
        elif event.type == pygame.KEYDOWN:
            if Menu_screen == 0 or Menu_screen == 2:
                if event.key == pygame.K_ESCAPE: #Return to menu screen
                    Menu_screen = 1


    pygame.display.update()
    clock.tick(30)